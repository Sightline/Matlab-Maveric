clear all; clc; close all;
sys = tf(1,[1 1]);
Ts = 0.01;
sysd = c2d(sys,Ts);
con = tf([10 100],[1 0]);
cond = c2d(con,Ts);
clsysd = feedback(cond*sysd,1);
[num,den] = tfdata(sysd,'v');
pl = diffeqn(num,den,Ts,'TF');
[numc,denc] = tfdata(cond,'v');
PI = diffeqn(numc,denc,Ts,'TF'); 
y = [];uv = [];u=0;
tfin = 5; 
for t = 0:Ts:tfin
    if(~isempty(y))
        err = 1-y(end);
    else
        err = 1;
    end
    u = PI.Update(err);
    y = [y pl.Update(u)];
    uv = [uv u];
end
t = 0:Ts:tfin;
plot(t,y,'r*:');
hold on;
step(clsysd);
% step(sysd);
% [ys,ts] = lsim(clsysd,ones(length(t),1),t);
% plot(ts,ys)
simin = [t' y'];
umin = [t' uv'];
hold off;