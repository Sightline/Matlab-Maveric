n = 4;
a = 100*rand(n,1);
a
for ii = 1:n
    for jj = n:-1:2
        if(a(jj,1) < a(jj-1,1))
            tmp = a(jj-1,1);
            a(jj-1,1) = a(jj,1);
            a(jj,1) = tmp;
        end
    end
end
a