%% Simple latency example function
clear all; clc; close all;
% Define the latency object (500 cycles max)
a = latency(500);
% Set timing paramters
t = 0; dt = 0.001;   % dt = 0.001 - 1000Hz
% Storage variables for plotting
tv = []; yv = []; ylatv = [];
% Loop corresponding to the main global timestep loop
while t < 10;
    % create the input signal
    y = sin(2*t);
    % add this signal to the latency variable
    a.Add(y);
    % collect plotting data
    tv = [tv t];
    yv = [yv y];
    % get the delayed data from the latency object (200ms in this case)
    ylatv = [ylatv a.Get(200)];
    % update time
    t = t+dt;
end
%% Plotting data
% Undelayed signal
plot(tv,yv); hold on;
% delayed signal
plot(tv,ylatv,'r'); hold off;