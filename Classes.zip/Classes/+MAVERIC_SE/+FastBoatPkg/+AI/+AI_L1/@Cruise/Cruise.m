classdef Cruise < handle
    %Cruise Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Cruise(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
            stateobj = stateobj.Enter();
        end
        
        function stateobj = Enter(stateobj)
            % Do initialisation stuff
            stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Cruise';
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'MaintainHeading';
        end
        
        function stateobj = Execute(stateobj)
            % Do execute stuff
        end
        
        function Exit(stateobj)
            % Clean-up the AI state
            delete(stateobj);
        end
     
    end
    
end

