classdef FastBoat < MAVERIC_SE.MultiResObject.Agent
    %FastBoat Summary of this class goes here
    %   Detailed explanation goes here
     
    properties 
        % Blackboard handle
        m_hBB
        % Internal data bus objects
        m_hDataBus
        m_hControlBus
        %
        Tag
    end
    
    
    methods
        function obj = FastBoat(ObjName)
            % Get theSIM simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            import MAVERIC_SE.FastBoatPkg.*
            obj.m_hDataBus = FastBoatDataBus();
            obj.m_hBB = theSIM.m_hScene.m_hBB;
            import MAVERIC_SE.FastBoatPkg.*
            obj.Tag = ObjName;
            obj.m_hDataBus.m_hParent = [];
            obj.m_hDataBus.WPindex = 1;
            obj.m_hDataBus.m_LocalTime = obj.m_hBB.m_GlobalTime;
            obj.m_hDataBus.m_GlobalTimeStep = obj.m_hBB.m_GlobalTimeStep;
            obj.m_hDataBus.m_NextUpdate = obj.m_hDataBus.m_LocalTime;
            obj.m_hDataBus.m_RCS = 50;
            obj.m_hDataBus.m_AgResolution = 1;
            obj.m_hDataBus.m_DynamicResolution = 1;
            obj.m_hDataBus.m_Health = 100;
            obj.m_hDataBus.Area = 6;
            %
%             obj.m_hDataBus.SystemMatrix = [];
%             obj.m_hDataBus.ControlMatrix = [];
%             obj.m_hDataBus.DynamicsResolution = 1;
%             obj.m_hDataBus.LPVmodel = [];
%             obj.m_hDataBus.LineariseFlag = 0;
            %
            obj = CreateAIObj(obj);
            obj = CreateDynamicsObj(obj);
            obj = CreateGeometryObj(obj);
            obj = CreateControlObj(obj);
            obj = CreateGuidanceObj(obj);
            obj = CreateNavigationObj(obj);
            obj = CreateDetectionObj(obj);
            obj = CreateSightlineObj(obj);
            obj = CreateTrackingObj(obj);
        end
    end
    
    methods
%-------------------------------------------------------------------------%
        function ID = AssignID(obj)
%             import MAVERIC_SG.*
%             BB = Black_Board.getInstance;
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            nag = theSIM.m_hScene.m_hBB.m_NumAgents;
            ID = sprintf('AG%d',nag);
            obj.m_hDataBus.m_AgID = ID;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateTime(obj,src,~)
            obj.m_hDataBus.m_GlobalTimeStep = src.m_GlobalTimeStep;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateSensorArrayDetection(obj)
            %
            for sai = 1:obj.m_hDataBus.m_NumSensors
                obj.m_hDataBus.m_hSensorArray{1,sai} = obj.m_hDataBus.m_hSensorArray{1,sai}...
                    .UpdateDetection();
                obj.m_hDataBus.m_hSensorArray{1,sai} = obj.m_hDataBus.m_hSensorArray{1,sai}...
                    .UpdateTracking();
            end
        end
%-------------------------------------------------------------------------%
        function obj = UpdateDynamics(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Dynamics.*
            obj.m_hDataBus.m_hCurrentDynMRState.Execute();
            % Write current context to BB
            WriteDynToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = UpdateGeometry(obj)
            % There are two main phases to the geometry update and these
            % are related to the specific scenario under investigation and
            % the complexity of the agent model. The first is geometric
            % deformation which occurs when the agent mesh is not constant.
            % Examples of this would include flapping wings, damage or
            % morphing wings etc. The second phase is irradiance of the
            % agent either from background or directly by another agent
            % e.g. laser irradiance.
            import MAVERIC_SE.FastBoatPkg.Geometry.*
%             obj.m_hCurrentGeoMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateDynamicsObj(obj)
            % Create the object
            obj.m_hDataBus.dynres = 1;
            import MAVERIC_SE.FastBoatPkg.Dynamics.*
            obj.m_hDataBus.m_hDynamicsMRSM = DynamicsMRSM(obj);
            obj.m_hDataBus.m_hCurrentDynMRState = obj.m_hDataBus.m_hDynamicsMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = CreateGeometryObj(obj)
            %
            import MAVERIC_SE.FastBoatPkg.Geometry.*
            obj.m_hDataBus.m_hGeometryMRSM = GeometryMRSM(obj);
            obj.m_hDataBus.m_hCurrentGeoMRState = obj.m_hDataBus.m_hGeometryMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateSensorArrayDynamics(obj)
            % The purpose of this wrapper method of to update the sensor
            % dynamics of all of the sensors in the array
            for i = 1:length(obj.m_hDataBus.m_hSensorArray)
                obj.m_hDataBus.m_hSensorArray{i} = obj.m_hDataBus.m_hSensorArray{i}...
                    .UpdateSensorDynamics();
            end
        end
%-------------------------------------------------------------------------%
        function obj = CreateSensorArray(obj)
            % The purpose of this method is to create an array of sensor
            % objects specific to the current object type and return this
            % array to the cell array m_hSensorArray
            %
            obj.m_hDataBus.SensorArrayData{1}.xstraj = [];
            % 
%             import EOPkg.*
%             obj.m_hDataBus.m_hSensorArray{1} = EOSystem(obj);
%             obj.m_hDataBus.SensorArrayData{1}.dt = obj.m_hDataBus.m_LocalTimeStep;
%             obj.m_hDataBus.m_hSensorArray{1}.assignSensorID(1);
%             obj.m_hDataBus.m_NumSensors = 1;
        end
%-------------------------------------------------------------------------%
        function obj = CreateAIObj(obj)
            import MAVERIC_SE.FastBoatPkg.AI.*
            obj.m_hDataBus.m_hAIMRSM = AIMRSM(obj);
            obj.m_hDataBus.m_hCurrentAIMRState = obj.m_hDataBus.m_hAIMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateAI(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.AI.*
            obj.m_hDataBus.m_hCurrentAIMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateControlObj(obj)
            import MAVERIC_SE.FastBoatPkg.Control.*
            obj.m_hDataBus.m_hControlMRSM = ControlMRSM(obj);
            obj.m_hDataBus.m_hCurrentControlMRState = ...
                obj.m_hDataBus.m_hControlMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateControl(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Control.*
            obj.m_hDataBus.m_hCurrentControlMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateGuidanceObj(obj)
            import MAVERIC_SE.FastBoatPkg.Guidance.*
            obj.m_hDataBus.m_hGuidanceMRSM = GuidanceMRSM(obj);
            obj.m_hDataBus.m_hCurrentGuidanceMRState = ...
                obj.m_hDataBus.m_hGuidanceMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateGuidance(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Guidance.*
            obj.m_hDataBus.m_hCurrentGuidanceMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateNavigationObj(obj)
            import MAVERIC_SE.FastBoatPkg.Navigation.*
            obj.m_hDataBus.m_hNavigationMRSM = NavigationMRSM(obj);
            obj.m_hDataBus.m_hCurrentNavigationMRState = ...
                obj.m_hDataBus.m_hNavigationMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateNavigation(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Navigation.*
            obj.m_hDataBus.m_hCurrentNavigationMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateDetectionObj(obj)
            import MAVERIC_SE.FastBoatPkg.Detection.*
            obj.m_hDataBus.m_hDetectionMRSM = DetectionMRSM(obj);
            obj.m_hDataBus.m_hCurrentDetectionMRState = ...
                obj.m_hDataBus.m_hDetectionMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateDetection(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Detection.*
            obj.m_hDataBus.m_hCurrentDetectionMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateSightlineObj(obj)
            import MAVERIC_SE.FastBoatPkg.Sightline.*
            obj.m_hDataBus.m_hSightlineMRSM = SightlineMRSM(obj);
            obj.m_hDataBus.m_hCurrentSightlineMRState = ...
                obj.m_hDataBus.m_hSightlineMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateSightline(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Sightline.*
            obj.m_hDataBus.m_hCurrentSightlineMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = CreateTrackingObj(obj)
            import MAVERIC_SE.FastBoatPkg.Tracking.*
            obj.m_hDataBus.m_hTrackingMRSM = TrackingMRSM(obj);
            obj.m_hDataBus.m_hCurrentTrackingMRState = ...
                obj.m_hDataBus.m_hTrackingMRSM.m_hCurrentMRState;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateTracking(obj)
            % 
            import MAVERIC_SE.FastBoatPkg.Tracking.*
            obj.m_hDataBus.m_hCurrentTrackingMRState.Execute();
            % Write current context to BB
            WriteGeoToBB(obj);
        end
%-------------------------------------------------------------------------%
        function obj = LinkToBB(obj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            theSIM.m_hScene.m_hBB.AddAgent(obj);
        end
%-------------------------------------------------------------------------%
        function WriteDynToBB(obj)
            % This function writes the agent context to the blackboard
            % database. First check that the blackboard object has been
            % created and attached to the agent.
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            import MAVERIC_SG.*
            if(isa(theSIM.m_hScene.m_hBB,'Black_Board'))
                % If so, write the context to the blackboard. Note that the
                % blackboard object will control how and where the context
                % is stored.
                theSIM.m_hScene.m_hBB.WriteContext(obj);
            end
        end
%-------------------------------------------------------------------------%
        function WriteGeoToBB(obj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            import MAVERIC_SG.*
            if(isa(theSIM.m_hScene.m_hBB,'Black_Board'))
                % If so, write the context to the blackboard. Note that the
                % blackboard object will control how and where the geometry
                % is stored.
%                 obj.m_hBB.WriteGeometry(obj);
            end
        end
%-------------------------------------------------------------------------%
        function obj = UpdateClock(obj)
            obj.m_hDataBus.m_NextUpdate = obj.m_hDataBus.m_NextUpdate + obj.m_hDataBus.m_LocalTimeStep;
            obj.m_hDataBus.m_NextDynUpdate = obj.m_hDataBus.m_NextDynUpdate...
                + obj.m_hDataBus.m_hCurrentDynMRState.dt;
            obj.m_hDataBus.m_NextGeoUpdate = obj.m_hDataBus.m_NextGeoUpdate...
                + obj.m_hDataBus.m_hCurrentGeoMRState.dt;
            obj.m_hDataBus.m_NextAIUpdate = obj.m_hDataBus.m_NextAIUpdate...
                + obj.m_hDataBus.m_hCurrentAIMRState.dt;
            obj.m_hDataBus.m_NextGNCUpdate = obj.m_hDataBus.m_NextGNCUpdate...
                + obj.m_hDataBus.m_hCurrentGNCMRState.dt;
%             obj.m_hDataBus.m_NextGuidanceUpdate = obj.m_hDataBus.m_NextGuidanceUpdate...
%                 + obj.m_hDataBus.m_hCurrentGuidanceMRState.dt;
%             obj.m_hDataBus.m_NextNavigationUpdate = obj.m_hDataBus.m_NextnavigationUpdate...
%                 + obj.m_hDataBus.m_hCurrentNavigationMRState.dt;
%             obj.m_hDataBus.m_NextControlUpdate = obj.m_hDataBus.m_NextControlUpdate...
%                 + obj.m_hDataBus.m_hCurrentControlMRState.dt;
        end
%-------------------------------------------------------------------------%
        function obj = ChangeResolution(obj,newres)
            % When any module changes resolution or timestep, the agent
            % must change the main timestep accordingly (to ensure the
            % agent is called by the simulation engine at the correct
            % time). The agents local timestep must be the minimum of all
            % the timesteps in it's modules.
            ts = min([obj.m_hDataBus.m_hCurrentDynMRState.dt,...
                obj.m_hDataBus.m_hCurrentGeoMRState.dt,...
                obj.m_hDataBus.m_hCurrentGNCMRState.dt,...
                obj.m_hDataBus.m_hCurrentAIMRState.dt]);
            obj.m_hDataBus.m_AgResolution = newres;
            obj.m_hDataBus.m_LocalTimeStep = ts;
            obj.m_hDataBus.m_hCurrentDynMRState.dt = obj.m_hDataBus.m_LocalTimeStep;
        end
%-------------------------------------------------------------------------%
        function obj = UpdateTimeStep(obj)
            % 
        end
%-------------------------------------------------------------------------%
        function Reset(obj)
            % Reset the object time data
            if(obj.m_hDataBus.m_HasDynamic)
                import MAVERIC_SE.FastBoatPkg.Dynamics.*
                obj.m_hDataBus.m_hCurrentDynMRState.Enter();
                if(~isempty(obj.m_hDataBus.DynStatesTraj))
                    obj.m_hDataBus.setDynStates(obj.m_hDataBus.DynStatesTraj(:,1),1);
                    obj.m_hDataBus.setDynStateDot(obj.m_hDataBus.DynStateDotTraj(:,1),1);
                end
                obj.m_hDataBus.DynStatesTraj = [];
                obj.m_hDataBus.DynStateDotTraj = [];
                obj.m_hDataBus.DynConTraj = [];
            end
            if(obj.m_hDataBus.m_HasControl)
                import MAVERIC_SE.FastBoatPkg.Control.*
                obj.m_hDataBus.m_hCurrentControlMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasGuidance)
                import MAVERIC_SE.FastBoatPkg.Guidance.*
            obj.m_hDataBus.m_hCurrentGuidanceMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasNavigation)
                import MAVERIC_SE.FastBoatPkg.Navigation.*
            obj.m_hDataBus.m_hCurrentNavigationMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasTracking)
                import MAVERIC_SE.FastBoatPkg.Tracking.*
            obj.m_hDataBus.m_hCurrentTrackingMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasSightline)
                import MAVERIC_SE.FastBoatPkg.Sightline.*
            obj.m_hDataBus.m_hCurrentSightlineMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasGeometry)
                import MAVERIC_SE.FastBoatPkg.Geometry.*
%             obj.m_hCurrentGeoMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasDetection)
                import MAVERIC_SE.FastBoatPkg.Detection.*
            obj.m_hDataBus.m_hCurrentDetectionMRState.Enter();
            end
            if(obj.m_hDataBus.m_HasAI)
                import MAVERIC_SE.FastBoatPkg.AI.*
            obj.m_hDataBus.m_hCurrentAIMRState.Enter();
            end
        end
%-------------------------------------------------------------------------%
    end
end

