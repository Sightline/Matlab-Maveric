classdef GuidMRState_L1 < MAVERIC_SE.MultiResObject.MRState
    %GuidMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Guidance MRFSM
        m_LocalTime             % Guidance object local time
        m_LocalTimeStep         % Guidance object sample time
        m_NextTime              % Next time Guidance object should fire
        m_LocalVariables        % Variables local to the guidance state
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = GuidMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_GuidanceResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_GuidanceMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            MRStateobj.m_LocalVariables.prevHeading = 0;
            %
            % Now initialise the guidance trajectory structure
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xe = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ye = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ze = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.yde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.zde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xdde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ydde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.zdde = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.Vf = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.psid = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.gammad = 0;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.t = 0;
        end
        
        function MRStateobj = Execute(MRStateobj)
            % The guidance module has two types of response - waypoint and
            % mission task element. The responsibility of the AI module is
            % to select the appropriate guidance strategy for a particular
            % AI state. This is contained within the m_Guidance State
            % variable on the DataBus
            guidstate = MRStateobj.m_hAgent.m_hDataBus.m_GuidanceState;
            switch guidstate
                case 'Waypoint'
                    MRStateobj = MRStateobj.WaypointGuidance();
                case 'MTE'
                    MRStateobj = MRStateobj.MTEGuidance();    
                case 'Idle'
                    MRStateobj = MRStateobj.IdleGuidance();
                case 'MaintainHeading'
                    MRStateobj = MRStateobj.MaintainHeadingGuidance();
                otherwise
                    MRStateobj = MRStateobj.IdleGuidance();
            end
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
    methods
        
        function MRStateobj = MaintainHeadingGuidance(MRStateobj)
            %
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % get the cruise speed
            Vfc = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.Vf_cruise;
            % Store the commanded rates to the control vector
            MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;0;0],1);
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = IdleGuidance(MRStateobj)
            %
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % Store the commanded rates to the control vector
            MRStateobj.m_hAgent.m_hDataBus.setControls([0;0;0],1);
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        
        function MRStateobj = WaypointGuidance(MRStateobj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.t = MRStateobj.m_LocalTime;
            % Get the current state (L1)
            [xe,ye,ze,~,psi,gamma] = MRStateobj.m_hAgent.m_hDataBus.getDynStates(1);
            % Get the current waypoints
            xw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            zw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw;
            zwmin = 0;
            if(zw > zwmin)
                zw = zwmin;
            end
            % Now calculate the heading error
            psiwp = atan2((yw-ye),(xw-xe));
            if(psiwp < 0)
                psiwp2 = psiwp + 2*pi;
            else
                psiwp2 = psiwp;
            end
            psierr1 = psiwp - psi;
            psierr2 = psiwp2 - psi;
            errv = [psierr1 psierr2];
            [psierr,index] = min(abs(errv));
            psierr = psierr * sign(errv(index));
            % Select the appropriate guidance loop gain
            if(MRStateobj.m_hAgent.m_hDataBus.DynResolution == 1)
                m_Kp = 0.5;
            else
                m_Kp = 0.5;
            end
            psid_dem = m_Kp*psierr;
            psid_max = MRStateobj.m_hAgent.m_hDataBus.ParameterData...
                .L1Dyn.psi_max;
            if(psid_dem > (psid_max*pi/180))
                psid_dem = (psid_max*pi/180);
            end
            if(psid_dem < -(psid_max*pi/180))
                psid_dem = -(psid_max*pi/180);
            end
            %
            % Now the climb angle gamma
            gamwp = atan2(-(zw-ze),sqrt((xw-xe)^2+(yw-ye)^2));
            gamerr = gamwp - gamma;
            gamd_dem = m_Kp*gamerr;
            gamd_max =  MRStateobj.m_hAgent.m_hDataBus.ParameterData...
                .L1Dyn.gamma_max;
            if(gamd_dem > (gamd_max*pi/180))
                gamd_dem = (gamd_max*pi/180);
            end
            if(gamd_dem < -(gamd_max*pi/180))
                gamd_dem = -(gamd_max*pi/180);
            end
            %
            % Store the commanded rates to the control vector
            Vfc = MRStateobj.m_hAgent.m_hDataBus.Vc;
            MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;psid_dem;gamd_dem],1);
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj  = MTEGuidance(MRStateobj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % Desired Traj
            om1 = 1.5;
            phi1 = pi/2;
            MRStateobj.m_hAgent.m_hDataBus.ParameterData.om1 = om1;
            MRStateobj.m_hAgent.m_hDataBus.ParameterData.phi1 = phi1;
            %
            % Define the desired trajectory 
            sp = MRStateobj.m_LocalVariables.GuidanceOffset;
            t = MRStateobj.m_LocalTime;
            tend = 10; t0 = 0;
            tau = t/tend;
            Dt = tend - t0;
            A = [0 0 0 0 0 0 0 1;
                0 0 0 0 0 0 1 0;
                0 0 0 0 0 1 0 0;
                0 0 0 0 1 0 0 0;
                1 1 1 1 1 1 1 1;
                7 6 5 4 3 2 1 0;
                42 30 20 12 6 2 0 0;
                210 120 60 24 6 0 0 0];
            B1 = [0 0 0;0.1*Dt 0 0;0 0 0;0 0 0;5 10 -10;0.5*Dt 0 0;0 0 0;0 0 0];
            alp = A\B1;
            xt = alp(1,1)*tau^7 + alp(2,1)*tau^6 + alp(3,1)*tau^5 ...
                + alp(4,1)*tau^4 + alp(5,1)*tau^3 + alp(6,1)*tau^2 ...
                + alp(7,1)*tau + alp(8,1);
            xdt = (1/Dt)*(7*alp(1,1)*tau^6 + 6*alp(2,1)*tau^5 + 5*alp(3,1)*tau^4 ...
                + 4*alp(4,1)*tau^3 + 3*alp(5,1)*tau^2 + 2*alp(6,1)*tau ...
                + alp(7,1));
            xddt = (1/Dt)^2*(42*alp(1,1)*tau^5 + 30*alp(2,1)*tau^4 + 20*alp(3,1)*tau^3 ...
                + 12*alp(4,1)*tau^2 + 6*alp(5,1)*tau + 2*alp(6,1));
            yt = alp(1,2)*tau^7 + alp(2,2)*tau^6 + alp(3,2)*tau^5 ...
                + alp(4,2)*tau^4 + alp(5,2)*tau^3 + alp(6,2)*tau^2 ...
                + alp(7,2)*tau + alp(8,2);
            ydt = (1/Dt)*(7*alp(1,2)*tau^6 + 6*alp(2,2)*tau^5 + 5*alp(3,2)*tau^4 ...
                + 4*alp(4,2)*tau^3 + 3*alp(5,2)*tau^2 + 2*alp(6,2)*tau ...
                + alp(7,2));
            yddt = (1/Dt)^2*(42*alp(1,2)*tau^5 + 30*alp(2,2)*tau^4 + 20*alp(3,2)*tau^3 ...
                + 12*alp(4,2)*tau^2 + 6*alp(5,2)*tau + 2*alp(6,2));
            zt = (alp(1,3)*tau^7 + alp(2,3)*tau^6 + alp(3,3)*tau^5 ...
                + alp(4,3)*tau^4 + alp(5,3)*tau^3 + alp(6,3)*tau^2 ...
                + alp(7,3)*tau + alp(8,3));
            zdt = (1/Dt)*(7*alp(1,3)*tau^6 + 6*alp(2,3)*tau^5 + 5*alp(3,3)*tau^4 ...
                + 4*alp(4,3)*tau^3 + 3*alp(5,3)*tau^2 + 2*alp(6,3)*tau ...
                + alp(7,3));
            zddt = (1/Dt)^2*(42*alp(1,3)*tau^5 + 30*alp(2,3)*tau^4 + 20*alp(3,3)*tau^3 ...
                + 12*alp(4,3)*tau^2 + 6*alp(5,3)*tau + 2*alp(6,3));
            %
            %
            %
%             xt = (2.0)*cos(om1*(t+sp)+phi1);
%             yt = (1.0)*sin(2*om1*(t+sp));
%             zt = -1.5;
%             xdt = -(2.0)*om1*sin(om1*(t+sp)+phi1);
%             ydt = (1.0)*2*om1*cos(2*om1*(t+sp));
%             zdt = 0.0;
%             xddt = -(2.0)*om1^2*cos(om1*(t+sp)+phi1);
%             yddt = -(1.0)*4*om1^2*sin(2*om1*(t+sp));
%             zddt = 0.0;
            %
            % Store the commanded reference states to the guidance
            % structure.
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.x = xt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.y = yt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.z = zt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.xd = xdt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.yd = ydt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.zd = zdt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.xdd = xddt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.ydd = yddt;
            MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.zdd = zddt;
            %
            % Update the trajectory database
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xe(end+1) = xt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ye(end+1) = yt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ze(end+1) = zt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xde(end+1) = xdt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.yde(end+1) = ydt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.zde(end+1) = zdt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.xdde(end+1) = xddt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.ydde(end+1) = yddt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.zdde(end+1) = zddt;
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.Vf(end+1) = sqrt(xdt^2+ydt^2+zdt^2);
            MRStateobj.m_hAgent.m_hDataBus.GuidanceTraj.t(end+1) = t;
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
    end
end

