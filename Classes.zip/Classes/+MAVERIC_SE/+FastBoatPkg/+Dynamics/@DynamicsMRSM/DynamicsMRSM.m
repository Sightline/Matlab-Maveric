classdef DynamicsMRSM < MAVERIC_SE.MultiResObject.MRStateMachine
    %DYNAMICS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hCurrentMRState
        m_hPreviousMRState
        m_hGlobalMRState
    end
    
    methods
        function MRFSMobj = DynamicsMRSM(hAgent)
            import MAVERIC_SE.FastBoatPkg.Dynamics.*
            MRFSMobj.m_hAgent = hAgent;
            switch hAgent.m_hDataBus.m_DynamicResolution
                case 1
                    MRFSMobj.m_hCurrentMRState = DynMRState_L1(hAgent,MRFSMobj);
                case 2
                    MRFSMobj.m_hCurrentMRState = DynMRState_L2(hAgent,MRFSMobj);
                case 3
                    MRFSMobj.m_hCurrentMRState = DynMRState_L3(hAgent,MRFSMobj);
            end
            MRFSMobj.m_hPreviousMRState = 0;
            MRFSMobj.m_hGlobalMRState = 0;
        end
        
        function obj = SetCurrentMRState(obj,hCurrentMRState)
            obj.m_hCurrentMRState = hCurrentMRState;
        end
        
        function MRFSMobj = ChangeMRState(MRFSMobj,hNextMRState)
            % Change the state
            assert(isa(hNextMRState,'MAVERIC_SE.MultiResObject.MRState'));
            MRFSMobj.m_hPreviousMRState = MRFSMobj.m_hCurrentMRState;
            MRFSMobj.m_hCurrentMRState.Exit();
            MRFSMobj.m_hCurrentMRState = hNextMRState;
            MRFSMobj.m_hAgent.m_hDataBus.m_hCurrentDynMRState = MRFSMobj.m_hCurrentMRState;
            MRFSMobj.m_hAgent.m_hDataBus.m_hCurrentDynMRState.Enter();
%             MRFSMobj.m_hAgent.UpdateTimeStep();
        end
    end
    
end

