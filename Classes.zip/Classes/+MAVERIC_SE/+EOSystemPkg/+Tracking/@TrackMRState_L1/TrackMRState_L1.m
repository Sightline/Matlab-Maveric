classdef TrackMRState_L1 < MAVERIC_SE.MultiResObject.MRState 
    %TrackMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Tracking MRFSM
        m_LocalTime             % Tracking object local time
        m_LocalTimeStep         % Tracking object sample time
        m_NextTime              % next time Tracking object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = TrackMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            %
            MRStateobj.m_hAgent.m_hDataBus.m_hTrackDB = [];
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_TrackingMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Execute(MRStateobj)
            % The sole purpose of an L1 tracker is to populate the tracker
            % database with observations and sort the list, nearest first.
            % First, get the global time.
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % Next, check to see if any observations have been declared
            if(isempty(MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB))
            	% If there are no detections, exit the execute method.
                % remember to update the timing variables.
                MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            	return;
            end
            % If code has reached here, there must be observations that need to
            % be allocated to a track. 
            hDataBus = MRStateobj.m_hAgent.m_hDataBus;
            [n,~] = size(hDataBus.m_hObservationDB);
            % Get the position of the platform agent
            [xa,ya,za,~,~,~] = hDataBus.m_hParent.m_hDataBus.GetPose(1);
            % Get the inertial velocity of the platform agent
            xad = hDataBus.m_hParent.m_hDataBus.DynStateDot.xe;
            yad = hDataBus.m_hParent.m_hDataBus.DynStateDot.ye;
            zad = hDataBus.m_hParent.m_hDataBus.DynStateDot.ze;
            % As we shall be simply assigning each observation as a track,
            % need to reset the track database.
            hDataBus.m_hTrackDB = [];
            % Loop over each observation.
            for i = 1:n
            	[x,y] = pol2cart(hDataBus.m_hObservationDB{i,1}.Bearing,...
                    (hDataBus.m_hObservationDB{i,1}.R*cos(hDataBus.m_hObservationDB{i,1}.SlantAngle)));
                z = hDataBus.m_hObservationDB{i,1}.R*sin(hDataBus.m_hObservationDB{i,1}.SlantAngle);
                % Ordinarily there would be a sequence of track association and
                % filtering at this stage. However, for L1 we simply assign an
                % observation as a track.
                hObs = theSIM.m_hScene.m_hBB.GetAgent(hDataBus.m_hObservationDB{i,1}.ID);
                hDataBus.m_hTrackDB{i,1}.TrackID = hObs.m_hDataBus.m_AgID;
                hDataBus.m_hTrackDB{i,1}.TrackTag = hObs.Tag;
                hDataBus.m_hTrackDB{i,1}.R = hDataBus.m_hObservationDB{i,1}.R;
                hDataBus.m_hTrackDB{i,1}.bearing = hDataBus.m_hObservationDB{i,1}.Bearing;
                hDataBus.m_hTrackDB{i,1}.SlantAngle = hDataBus.m_hObservationDB{i,1}.SlantAngle;
                hDataBus.m_hTrackDB{i,1}.xpos = x + xa;
                hDataBus.m_hTrackDB{i,1}.ypos = y + ya;
                hDataBus.m_hTrackDB{i,1}.zpos = z + za;
%                 disp('***********************');
%                 fprintf('Track declared at %4.2f mins\n',MRStateobj.m_LocalTime/60.0);
%                 fprintf('Target Location of agent %s\n',hDataBus.m_hObservationDB{i,1}.ID);
%                 var = sprintf('%4.1f(km) North, %4.1f(km) East',...
%                     hDataBus.m_hTrackDB{i,1}.xpos/1000,hDataBus.m_hTrackDB{i,1}.ypos/1000);
%                 disp(var);
%                 disp(' ');
            end
            %
            % Now sort the Track DB
%             MRStateobj.sortDB();
            %
%             hDataBus.m_hTrackDB{:,1}.TrackID
            %
            MRStateobj.m_hAgent.m_hDataBus = hDataBus;
            % Update the internal tracking clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

