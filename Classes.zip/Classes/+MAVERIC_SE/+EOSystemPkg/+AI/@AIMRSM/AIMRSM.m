classdef AIMRSM < MAVERIC_SE.MultiResObject.MRStateMachine
    %Geometry Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hCurrentMRState
        m_hPreviousMRState
        m_hGlobalMRState
    end
    
    methods
        function FSMobj = AIMRSM(hAgent)
            import MAVERIC_SE.EOSystemPkg.AI.*
            FSMobj.m_hAgent = hAgent;
            FSMobj.m_hCurrentMRState = AIMRState_L1(hAgent,FSMobj);
            FSMobj.m_hPreviousMRState = 0;
            FSMobj.m_hGlobalMRState = 0;
        end
        
        function FSMobj = SetCurrentMRState(FSMobj,hCurrentMRState)
            FSMobj.m_hCurrentMRState = hCurrentMRState;
        end
        
        function FSMobj = ChangeMRState(FSMobj,hNextMRState)
            FSMobj.m_hCurrentMRState = hNextMRState;
        end
    end
    
end