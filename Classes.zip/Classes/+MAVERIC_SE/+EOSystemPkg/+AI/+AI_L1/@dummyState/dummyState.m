classdef dummyState < handle
    %DUMMYSTATE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = dummyState(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
            stateobj = stateobj.Enter();
        end
        
        function stateobj = Enter(stateobj)
            % Do initialisation stuff
        end
        
        function stateobj = Execute(stateobj)
            % Do execute stuff
        end
        
        function Exit(stateobj)
            % Clean-up the AI state
            delete(stateobj);
        end
     
    end
    
end

