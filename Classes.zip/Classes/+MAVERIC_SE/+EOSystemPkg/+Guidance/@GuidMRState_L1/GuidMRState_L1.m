classdef GuidMRState_L1 < MAVERIC_SE.MultiResObject.MRState
    %GuidMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Guidance MRFSM
        m_LocalTime             % Guidance object local time
        m_LocalTimeStep         % Guidance object sample time
        m_NextTime              % Next time Guidance object should fire
        m_LocalVariables        % Variables local to the guidance state
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = GuidMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_GuidanceResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_GuidanceMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            MRStateobj.m_LocalVariables.prevHeading = 0;
        end
        
        function MRStateobj = Execute(MRStateobj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime; 
            Vfc = MRStateobj.m_hAgent.m_hDataBus.Vc;
            MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;0;0],1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

