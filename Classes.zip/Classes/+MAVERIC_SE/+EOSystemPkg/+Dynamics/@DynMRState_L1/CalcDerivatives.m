function obj = CalcDerivatives(obj)
%****************************************************************
% Date: 4/2/2014
% Author: D.Anderson
% Description: This is the basic L1 dynamics module that is common to all 
% agent platform types.
%****************************************************************
%% Extract the control and state vectors
% First the state vector
[xe,ye,ze,Vf,psi,gamma] = obj.m_hAgent.m_hDataBus.getDynStates(1);
% now the control vector
[Vfc,psic,gammac] = obj.m_hAgent.m_hDataBus.getControls(1);
Vfcs = sqrt(Vfc'*Vfc);
% finally the dynamics parameters
Vf_tau = obj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.Vf_tau;
%% Equations of Motion
% The equations of motion for an L1 platform are simple point-mass models.
%
obj.m_hAgent.m_hDataBus.DynStateDot.xe = Vf*cos(psi)*cos(gamma);
obj.m_hAgent.m_hDataBus.DynStateDot.ye = Vf*sin(psi)*cos(gamma);
obj.m_hAgent.m_hDataBus.DynStateDot.ze = -Vf*sin(gamma);
obj.m_hAgent.m_hDataBus.DynStateDot.Vf = (Vfcs-Vf)/Vf_tau;
obj.m_hAgent.m_hDataBus.DynStateDot.psi = psic;
obj.m_hAgent.m_hDataBus.DynStateDot.gamma = gammac;
% Derivative of the local time variable
obj.m_hAgent.m_hDataBus.DynStateDot.t = 1;
end

