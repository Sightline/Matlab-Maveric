classdef Viper_QuadrotorDataBus < handle
    %DATABUS This class contains the properties internal to the agent
    %class.
    %
    
    properties
        % These properties relate to the Multi-Resolution properties of the
        % object
        m_AgID                          % Agent ID
        m_AgentType                     % Agent Type.
        m_ClassName                     % Object Class
        m_DataFile                      % String containing the name of the 
                                        % object datafile
        m_SimStatus                     % Agent simulation status, either 
                                        % 'Active' or 'Dormant'
        m_IsDocked                      % Flag to determine if agent is 
                                        % docked to another agent
        m_MRObjectID
        m_MRObjectType
        m_ObjectName                    % Name of the object instance
        m_hParent                       % handle of the parent object
        m_hChildren
        m_hChildrenArray
        m_AgResolution                  % The main agent resolution
        % Dynamics properties
        m_hDynamicsMRSM
        m_hCurrentDynMRState
        m_DynamicResolution
        m_DynamicMRStatesTimeSteps
        m_HasDynamic
        % Sensor array properties
        m_hSensorArray
        m_hCurrentSAMRStates            % Current sensor array MR states
        % Control properties
        m_hControlMRSM
        m_hCurrentControlMRState
        m_ControlResolution
        m_ControlMRStatesTimeSteps
        m_HasControl
        % Guidance properties
        m_hGuidanceMRSM
        m_hCurrentGuidanceMRState
        m_GuidanceResolution
        m_GuidanceMRStatesTimeSteps
        m_HasGuidance
        % Navigation properties
        m_hNavigationMRSM
        m_hCurrentNavigationMRState
        m_NavigationResolution
        m_NavigationMRStatesTimeSteps
        m_HasNavigation
        % Detection properties
        m_hDetectionMRSM
        m_hCurrentDetectionMRState
        m_DetectionResolution
        m_DetectionMRStatesTimeSteps
        m_HasDetection
        % Sightline properties
        m_hSightlineMRSM
        m_hCurrentSightlineMRState
        m_SightlineResolution
        m_SightlineMRStatesTimeSteps
        m_HasSightline
        % Tracking properties
        m_hTrackingMRSM
        m_hCurrentTrackingMRState
        m_TrackingResolution
        m_TrackingMRStatesTimeSteps
        m_HasTracking
        % AI properties
        m_hAIMRSM
        m_hCurrentAIMRState
        m_AIResolution
        m_AIMRStatesTimeSteps
        m_HasAI
        m_CurrentWP
        m_AIGNCMode
        % Geometric Properties
        m_hGeometryMRSM
        m_hCurrentGeoMRState
        m_GeometryResolution
        m_GeometryMRStatesTimeSteps
        m_HasGeometry
        % Simulation Engine properties
        m_GlobalTimeStep
        m_LocalTimeStep
        m_GlobalTime
        m_LocalTime
        m_NextUpdate
        % Listener handles
        lh_ChangeDT
        %
        m_RCS
        % Handle to the current axes for displaying agent plot data
        m_hCurrentAxes
        m_hCurrentFigure
        m_hGraphicsHandles
        m_hZoom
        m_hLines
        % Listener Handles
    end
    
    properties
        % Core Data
        DynStates                   % Dynamic states structure
        DynStateDot                 % Dynamic state derivatives structure
        PrevDynStates               % Previous dynamic states structure
        PrevDynStateDot             % Previous dynamic state derivatives structure
        DynControlSignals           % Control signals vector
        DynControlTrim              % Trim control vector values
        DynStatesTraj               % Dynamic states timeseries
        DynStateDotTraj             % Dynamic states derivative timeseries
        DynConTraj                  % Control vector timeseries
        TransformationMatrices      % Structure containing transformation matrices
        m_NumSensors
        m_SensorRes
        m_hTrackDB
        m_hObservationDB
        m_hTargetQueue
        m_hTargetsInspected
        NavMeasurements             % Structure containing navigation measurements
        NavTraj                     % Structure containing navigation solutions
        GuidanceFilterEstimates     % Structure containing sightline filter estimates
        GFTraj                      % Sightline filter timeseries
        Guidance                    % Structure contaiing guidance data
        EOMeasurements              % Structure containing EO measurements
        ParameterData               % Agent parameter data (constants)
        InertialData
        AerodynamicData
        %  Linearisation (DEBUG) data ------------------------------
        LineariseFlag               %
        SystemMatrix
        ControlMatrix
        LPVmodel
        iModel
        xbase
        xdbase
        % ----------------------------------------------------------
    end
    
    properties
        % Legacy properties. These properties will be replaced by the Core
        % Data properties above.
        m_Health                        % Agent Health (%)
        m_hInitialConditions
        xe
        ye
        ze
        psi
        theta
        phi
        WPindex
        WayPoints
        NumWayPoints
        Vc
        V_Cruise
        x
        xd
        xtraj
        y
        u
        t
        dt
        DynResolution
        dynres
        Colour
        L1RadarDynFlag
        Rd
        Rc
        Ri
        IsLanded
    end
    
    properties
        % These properties are specific to the DSTO (military)
        % implementation
        Area
        m_hWeaponsArray
        m_ForceDesignation
    end
    
    properties
        % These properties are an alteration to the state vector properties
        % approach used in version 2 i.e. vector array. Need to keep the
        % states in a structure.
        state                   % This is a structure that has all of the
        % dynamic states named in the fields. This
        % consists, at a minimum, of the pose -
        % position and orientation in inertial
        % space.
        % states.xe,ye,ze,phi,theta,psi
        statedot
        statetraj
    end
    
    properties (Constant)
        kt2ms = 0.5144;
        d2r = pi/180;
    end
    
    % methods for accessing and storing data on the bus
    methods
        % Bus constructor
        function bus = Viper_QuadrotorDataBus()
            bus.DynStatesTraj = [];
            bus.DynConTraj = [];
            bus.NavTraj = [];
            bus.GFTraj = [];
        end
        
        function setPosition(this,xn)
            this.DynStates.xe = xn(1,1);
            this.DynStates.ye = xn(2,1);
            this.DynStates.ze = xn(3,1);
        end
        
        function [x] = getPositionVec(this)
            x = [this.DynStates.xe;...
                this.DynStates.ye;...
                this.DynStates.ze];
        end
        
        function setDynStates(this,xn,resolution)
            %
            switch resolution
                case 1
                    % The state vector for an L1 agent
                    this.DynStates.xe = xn(1,1);
                    this.DynStates.ye = xn(2,1);
                    this.DynStates.ze = xn(3,1);
                    this.DynStates.Vf = xn(4,1);
                    this.DynStates.psi = xn(5,1);
                    this.DynStates.gamma = xn(6,1);
                case 2
                    % The state vector for an L2 quadrotor
                    this.DynStates.u = xn(1,1);
                    this.DynStates.v = xn(2,1);
                    this.DynStates.w = xn(3,1);
                    this.DynStates.p = xn(4,1);
                    this.DynStates.q = xn(5,1);
                    this.DynStates.r = xn(6,1);
                    this.DynStates.phi = xn(7,1);
                    this.DynStates.theta = xn(8,1);
                    this.DynStates.psi = xn(9,1);
                    this.DynStates.xe = xn(10,1);
                    this.DynStates.ye = xn(11,1);
                    this.DynStates.ze = xn(12,1);
                case 3
                    % The state vector for an L3 quadrotor
                    this.DynStates.u = xn(1,1);
                    this.DynStates.v = xn(2,1);
                    this.DynStates.w = xn(3,1);
                    this.DynStates.p = xn(4,1);
                    this.DynStates.q = xn(5,1);
                    this.DynStates.r = xn(6,1);
                    this.DynStates.phi = xn(7,1);
                    this.DynStates.theta = xn(8,1);
                    this.DynStates.psi = xn(9,1);
                    this.DynStates.xe = xn(10,1);
                    this.DynStates.ye = xn(11,1);
                    this.DynStates.ze = xn(12,1);
                    this.DynStates.q0 = xn(13,1);
                    this.DynStates.q1 = xn(14,1);
                    this.DynStates.q2 = xn(15,1);
                    this.DynStates.q3 = xn(16,1);
            end
        end
        
        function setControls(this,un,resolution)
            % The control vector returned by this method will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The control vector for an L1 agent
                    this.DynControlSignals.u(1,1) = un(1,1);
                    this.DynControlSignals.u(2,1) = un(2,1);
                    this.DynControlSignals.u(3,1) = un(3,1);
                case 2
                    % The control vector for an L2 quadrotor
                    this.DynControlSignals.u(1,1) = un(1,1);
                    this.DynControlSignals.u(2,1) = un(2,1);
                    this.DynControlSignals.u(3,1) = un(3,1);
                    this.DynControlSignals.u(4,1) = un(4,1);
                case 3
                    % The control vector for an L3 quadrotor
                    this.DynControlSignals.u(1,1) = un(1,1);
                    this.DynControlSignals.u(2,1) = un(2,1);
                    this.DynControlSignals.u(3,1) = un(3,1);
                    this.DynControlSignals.u(4,1) = un(4,1);
            end
        end
        
        function [varargout] = getDynStates(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for an L1 agent
                    varargout{1} = this.DynStates.xe;
                    varargout{2} = this.DynStates.ye;
                    varargout{3} = this.DynStates.ze;
                    varargout{4} = this.DynStates.Vf;
                    varargout{5} = this.DynStates.psi;
                    varargout{6} = this.DynStates.gamma;
                case 2
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.DynStates.u;
                    varargout{2} = this.DynStates.v;
                    varargout{3} = this.DynStates.w;
                    varargout{4} = this.DynStates.p;
                    varargout{5} = this.DynStates.q;
                    varargout{6} = this.DynStates.r;
                    varargout{7} = this.DynStates.phi;
                    varargout{8} = this.DynStates.theta;
                    varargout{9} = this.DynStates.psi;
                    varargout{10} = this.DynStates.xe;
                    varargout{11} = this.DynStates.ye;
                    varargout{12} = this.DynStates.ze;
%                     varargout{13} = this.DynStates.q0;
%                     varargout{14} = this.DynStates.q1;
%                     varargout{15} = this.DynStates.q2;
%                     varargout{16} = this.DynStates.q3;
                case 3
                    % The state vector for an L3 quadrotor
                    varargout{1} = this.DynStates.u;
                    varargout{2} = this.DynStates.v;
                    varargout{3} = this.DynStates.w;
                    varargout{4} = this.DynStates.p;
                    varargout{5} = this.DynStates.q;
                    varargout{6} = this.DynStates.r;
                    varargout{7} = this.DynStates.phi;
                    varargout{8} = this.DynStates.theta;
                    varargout{9} = this.DynStates.psi;
                    varargout{10} = this.DynStates.xe;
                    varargout{11} = this.DynStates.ye;
                    varargout{12} = this.DynStates.ze;
                    varargout{13} = this.DynStates.q0;
                    varargout{14} = this.DynStates.q1;
                    varargout{15} = this.DynStates.q2;
                    varargout{16} = this.DynStates.q3;
            end
        end
        
        function [varargout] = getPrevDynStates(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for an L1 agent
                    varargout{1} = this.PrevDynStates.xe;
                    varargout{2} = this.PrevDynStates.ye;
                    varargout{3} = this.PrevDynStates.ze;
                    varargout{4} = this.PrevDynStates.Vf;
                    varargout{5} = this.PrevDynStates.psi;
                    varargout{6} = this.PrevDynStates.gamma;
                case 2
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.PrevDynStates.u;
                    varargout{2} = this.PrevDynStates.v;
                    varargout{3} = this.PrevDynStates.w;
                    varargout{4} = this.PrevDynStates.p;
                    varargout{5} = this.PrevDynStates.q;
                    varargout{6} = this.PrevDynStates.r;
                    varargout{7} = this.PrevDynStates.phi;
                    varargout{8} = this.PrevDynStates.theta;
                    varargout{9} = this.PrevDynStates.psi;
                    varargout{10} = this.PrevDynStates.xe;
                    varargout{11} = this.PrevDynStates.ye;
                    varargout{12} = this.PrevDynStates.ze;
                    varargout{9} = this.PrevDynStates.psi;
                    varargout{10} = this.PrevDynStates.xe;
                    varargout{11} = this.PrevDynStates.ye;
                    varargout{12} = this.PrevDynStates.ze;
%                     varargout{13} = this.PrevDynStates.q0;
%                     varargout{14} = this.PrevDynStates.q1;
%                     varargout{15} = this.PrevDynStates.q2;
%                     varargout{16} = this.PrevDynStates.q3;
                case 3
                    % The state vector for an L3 quadrotor
                    varargout{1} = this.PrevDynStates.u;
                    varargout{2} = this.PrevDynStates.v;
                    varargout{3} = this.PrevDynStates.w;
                    varargout{4} = this.PrevDynStates.p;
                    varargout{5} = this.PrevDynStates.q;
                    varargout{6} = this.PrevDynStates.r;
                    varargout{7} = this.PrevDynStates.phi;
                    varargout{8} = this.PrevDynStates.theta;
                    varargout{9} = this.PrevDynStates.psi;
                    varargout{10} = this.PrevDynStates.xe;
                    varargout{11} = this.PrevDynStates.ye;
                    varargout{12} = this.PrevDynStates.ze;
                    varargout{9} = this.PrevDynStates.psi;
                    varargout{10} = this.PrevDynStates.xe;
                    varargout{11} = this.PrevDynStates.ye;
                    varargout{12} = this.PrevDynStates.ze;
                    varargout{13} = this.PrevDynStates.q0;
                    varargout{14} = this.PrevDynStates.q1;
                    varargout{15} = this.PrevDynStates.q2;
                    varargout{16} = this.PrevDynStates.q3;
            end
        end
        
        function [x] = getDynStatesVec(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    x = [this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze;...
                        this.DynStates.Vf;...
                        this.DynStates.psi;...
                        this.DynStates.gamma];
                case 2
                    % The state vector for an L2 quadrotor
                    x = [this.DynStates.u;...
                        this.DynStates.v;...
                        this.DynStates.w;...
                        this.DynStates.p;...
                        this.DynStates.q;...
                        this.DynStates.r;...
                        this.DynStates.phi;...
                        this.DynStates.theta;...
                        this.DynStates.psi;...
                        this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze];
                case 3
                    % The state vector for an L3 quadrotor
                    x = [this.DynStates.u;...
                        this.DynStates.v;...
                        this.DynStates.w;...
                        this.DynStates.p;...
                        this.DynStates.q;...
                        this.DynStates.r;...
                        this.DynStates.phi;...
                        this.DynStates.theta;...
                        this.DynStates.psi;...
                        this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze;...
                        this.DynStates.q0;...
                        this.DynStates.q1;...
                        this.DynStates.q2;...
                        this.DynStates.q3];
            end
        end
        
        function [varargout] = getDynStateDot(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    varargout{1} = this.DynStateDot.xe;
                    varargout{2} = this.DynStateDot.ye;
                    varargout{3} = this.DynStateDot.ze;
                    varargout{4} = this.DynStateDot.Vf;
                    varargout{5} = this.DynStateDot.psi;
                    varargout{6} = this.DynStateDot.gamma;
                case 2
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.DynStateDot.u;
                    varargout{2} = this.DynStateDot.v;
                    varargout{3} = this.DynStateDot.w;
                    varargout{4} = this.DynStateDot.p;
                    varargout{5} = this.DynStateDot.q;
                    varargout{6} = this.DynStateDot.r;
                    varargout{7} = this.DynStateDot.phi;
                    varargout{8} = this.DynStateDot.theta;
                    varargout{9} = this.DynStateDot.psi;
                    varargout{10} = this.DynStateDot.xe;
                    varargout{11} = this.DynStateDot.ye;
                    varargout{12} = this.DynStateDot.ze;
                case 3
                    % The state vector for an L3 quadrotor
                    varargout{1} = this.DynStateDot.u;
                    varargout{2} = this.DynStateDot.v;
                    varargout{3} = this.DynStateDot.w;
                    varargout{4} = this.DynStateDot.p;
                    varargout{5} = this.DynStateDot.q;
                    varargout{6} = this.DynStateDot.r;
                    varargout{7} = this.DynStateDot.phi;
                    varargout{8} = this.DynStateDot.theta;
                    varargout{9} = this.DynStateDot.psi;
                    varargout{10} = this.DynStateDot.xe;
                    varargout{11} = this.DynStateDot.ye;
                    varargout{12} = this.DynStateDot.ze;
                    varargout{13} = this.DynStateDot.q0;
                    varargout{14} = this.DynStateDot.q1;
                    varargout{15} = this.DynStateDot.q2;
                    varargout{16} = this.DynStateDot.q3;
            end
        end
        
        function [varargout] = getPrevDynStateDot(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    varargout{1} = this.PrevDynStateDot.xe;
                    varargout{2} = this.PrevDynStateDot.ye;
                    varargout{3} = this.PrevDynStateDot.ze;
                    varargout{4} = this.PrevDynStateDot.Vf;
                    varargout{5} = this.PrevDynStateDot.psi;
                    varargout{6} = this.PrevDynStateDot.gamma;
                case 2
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.PrevDynStateDot.u;
                    varargout{2} = this.PrevDynStateDot.v;
                    varargout{3} = this.PrevDynStateDot.w;
                    varargout{4} = this.PrevDynStateDot.p;
                    varargout{5} = this.PrevDynStateDot.q;
                    varargout{6} = this.PrevDynStateDot.r;
                    varargout{7} = this.PrevDynStateDot.phi;
                    varargout{8} = this.PrevDynStateDot.theta;
                    varargout{9} = this.PrevDynStateDot.psi;
                    varargout{10} = this.PrevDynStateDot.xe;
                    varargout{11} = this.PrevDynStateDot.ye;
                    varargout{12} = this.PrevDynStateDot.ze;
                case 3
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.PrevDynStateDot.u;
                    varargout{2} = this.PrevDynStateDot.v;
                    varargout{3} = this.PrevDynStateDot.w;
                    varargout{4} = this.PrevDynStateDot.p;
                    varargout{5} = this.PrevDynStateDot.q;
                    varargout{6} = this.PrevDynStateDot.r;
                    varargout{7} = this.PrevDynStateDot.phi;
                    varargout{8} = this.PrevDynStateDot.theta;
                    varargout{9} = this.PrevDynStateDot.psi;
                    varargout{10} = this.PrevDynStateDot.xe;
                    varargout{11} = this.PrevDynStateDot.ye;
                    varargout{12} = this.PrevDynStateDot.ze;
                    varargout{13} = this.PrevDynStateDot.q0;
                    varargout{14} = this.PrevDynStateDot.q1;
                    varargout{15} = this.PrevDynStateDot.q2;
                    varargout{16} = this.PrevDynStateDot.q3;
            end
        end
        
        function [xd] = getDynStateDotVec(this,resolution)
            % The dynamic state vector returned by this methods will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    xd = [this.DynStateDot.xe;...
                        this.DynStateDot.ye;...
                        this.DynStateDot.ze;...
                        this.DynStateDot.Vf;...
                        this.DynStateDot.psi;...
                        this.DynStateDot.gamma];
                case 2
                    % The state vector for an L2 quadrotor
                    xd = [this.DynStateDot.u;...
                        this.DynStateDot.v;...
                        this.DynStateDot.w;...
                        this.DynStateDot.p;...
                        this.DynStateDot.q;...
                        this.DynStateDot.r;...
                        this.DynStateDot.phi;...
                        this.DynStateDot.theta;...
                        this.DynStateDot.psi;...
                        this.DynStateDot.xe;...
                        this.DynStateDot.ye;...
                        this.DynStateDot.ze];
                case 3
                    % The state vector for an L2 quadrotor
                    xd = [this.DynStateDot.u;...
                        this.DynStateDot.v;...
                        this.DynStateDot.w;...
                        this.DynStateDot.p;...
                        this.DynStateDot.q;...
                        this.DynStateDot.r;...
                        this.DynStateDot.phi;...
                        this.DynStateDot.theta;...
                        this.DynStateDot.psi;...
                        this.DynStateDot.xe;...
                        this.DynStateDot.ye;...
                        this.DynStateDot.ze;...
                        this.DynStateDot.q0;...
                        this.DynStateDot.q1;...
                        this.DynStateDot.q2;...
                        this.DynStateDot.q3];
            end
        end
        
        function setDynStateDot(this,xn,resolution)
            %
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    this.DynStateDot.xe = xn(1,1);
                    this.DynStateDot.ye = xn(2,1);
                    this.DynStateDot.ze = xn(3,1);
                    this.DynStateDot.Vf = xn(4,1);
                    this.DynStateDot.psi = xn(5,1);
                    this.DynStateDot.gamma = xn(6,1);
                case 2
                    % The state vector for an L2 quadrotor
                    this.DynStateDot.u = xn(1,1);
                    this.DynStateDot.v = xn(2,1);
                    this.DynStateDot.w = xn(3,1);
                    this.DynStateDot.p = xn(4,1);
                    this.DynStateDot.q = xn(5,1);
                    this.DynStateDot.r = xn(6,1);
                    this.DynStateDot.phi = xn(7,1);
                    this.DynStateDot.theta = xn(8,1);
                    this.DynStateDot.psi = xn(9,1);
                    this.DynStateDot.xe = xn(10,1);
                    this.DynStateDot.ye = xn(11,1);
                    this.DynStateDot.ze = xn(12,1);
                case 3
                    % The state vector for an L3 quadrotor
                    this.DynStateDot.u = xn(1,1);
                    this.DynStateDot.v = xn(2,1);
                    this.DynStateDot.w = xn(3,1);
                    this.DynStateDot.p = xn(4,1);
                    this.DynStateDot.q = xn(5,1);
                    this.DynStateDot.r = xn(6,1);
                    this.DynStateDot.phi = xn(7,1);
                    this.DynStateDot.theta = xn(8,1);
                    this.DynStateDot.psi = xn(9,1);
                    this.DynStateDot.xe = xn(10,1);
                    this.DynStateDot.ye = xn(11,1);
                    this.DynStateDot.ze = xn(12,1);
                    this.DynStateDot.q0 = xn(13,1);
                    this.DynStateDot.q1 = xn(14,1);
                    this.DynStateDot.q2 = xn(15,1);
                    this.DynStateDot.q3 = xn(16,1);
            end
        end
        
        function dc = getControlVec(this,resolution)
            % The control vector returned by this method will
            % differ depending upon the resolution of dynamic model
            % requesting the data
            switch resolution
                case 1
                    % The control vector for a L1 agent
                    dc = [this.DynControlSignals.u(1,1);...
                        this.DynControlSignals.u(2,1);...
                        this.DynControlSignals.u(3,1)];
                case 2
                    % The control vector for an L2 quadrotor
                    dc = [this.DynControlSignals.u(1,1);...
                        this.DynControlSignals.u(2,1);...
                        this.DynControlSignals.u(3,1);...
                        this.DynControlSignals.u(4,1)];
                case 3
                    % The control vector for an L3 quadrotor
                    dc = [this.DynControlSignals.u(1,1);...
                        this.DynControlSignals.u(2,1);...
                        this.DynControlSignals.u(3,1);...
                        this.DynControlSignals.u(4,1)];
            end
        end
        
        function [varargout] = getControls(this,resolution)
            % The control vector returned by this methods will
            % differ depending upon the resolution of the model
            % requesting the data
            switch resolution
                case 1
                    % The state vector for a L1 agent
                    varargout{1} = this.DynControlSignals.u(1,1);
                    varargout{2} = this.DynControlSignals.u(2,1);
                    varargout{3} = this.DynControlSignals.u(3,1);
                case 2
                    % The state vector for an L2 quadrotor
                    varargout{1} = this.DynControlSignals.u(1,1);
                    varargout{2} = this.DynControlSignals.u(2,1);
                    varargout{3} = this.DynControlSignals.u(3,1);
                    varargout{4} = this.DynControlSignals.u(4,1);
                case 3
                    % The state vector for an L3 quadrotor
                    varargout{1} = this.DynControlSignals.u(1,1);
                    varargout{2} = this.DynControlSignals.u(2,1);
                    varargout{3} = this.DynControlSignals.u(3,1);
                    varargout{4} = this.DynControlSignals.u(4,1);
            end
        end
        
        function [x] = GetPoseVec(this,resolution)
            % The control vector returned by this methods will
            % differ depending upon the resolution of the model
            % requesting the data
            switch resolution
                case 1
                    x = [this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze;...
                        this.DynStates.Vf;...
                        this.DynStates.psi;...
                        this.DynStates.gamma];
                case 2
                    x = [this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze;...
                        this.DynStates.phi;...
                        this.DynStates.theta;...
                        this.DynStates.psi];
                case 3
                    x = [this.DynStates.xe;...
                        this.DynStates.ye;...
                        this.DynStates.ze;...
                        this.DynStates.phi;...
                        this.DynStates.theta;...
                        this.DynStates.psi];
            end
        end
        
        function [varargout] = GetPose(this,resolution)
            % The control vector returned by this methods will
            % differ depending upon the resolution of the model
            % requesting the data
            switch resolution
                case 1
                    varargout{1} = this.DynStates.xe;
                    varargout{2} = this.DynStates.ye;
                    varargout{3} = this.DynStates.ze;
                    varargout{4} = this.DynStates.Vf;
                    varargout{5} = this.DynStates.psi;
                    varargout{6} = this.DynStates.gamma;
                case 2
                    varargout{1} = this.DynStates.xe;
                    varargout{2} = this.DynStates.ye;
                    varargout{3} = this.DynStates.ze;
                    varargout{4} = this.DynStates.phi;
                    varargout{5} = this.DynStates.theta;
                    varargout{6} = this.DynStates.psi;
                case 3
                    varargout{1} = this.DynStates.xe;
                    varargout{2} = this.DynStates.ye;
                    varargout{3} = this.DynStates.ze;
                    varargout{4} = this.DynStates.phi;
                    varargout{5} = this.DynStates.theta;
                    varargout{6} = this.DynStates.psi;
            end
        end
        
    end
    
end

