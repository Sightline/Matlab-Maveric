function obj = IntegrateSL(obj)
% The integration function can, in the general case, implement a variety of
% different integration algorithms. Algorithms more complex that simple
% euler integration require multiple evaluations of the derivatives.
% Therefore the call to calculate the derivatives has been incorporated
% into the integration function.
%
inttype = 'Euler';
switch inttype
    case 'Euler'
        % Euler Integration
        % ***************************************************
        % This is the simplest integration scheme . 
        % The derivative statedot vector has now been updated on the main DataBus.
        % Set an alias for the DataBus path
        hDataBus = obj.m_hAgent.m_hDataBus;
        res = hDataBus.m_DynamicResolution;
        % Using bus variables
        x = hDataBus.getDynStatesVec(res);
        xd = hDataBus.getDynStateDotVec(res);
        u = hDataBus.getControlVec(res);
        xn = x + xd.*obj.m_LocalTimeStep;
        hDataBus.setDynStates(xn,res);
        % ...and update the local time (agent time is the responsibility of the
        % dynamic model to keep correct).
        obj.m_LocalTime = obj.m_LocalTime...
            + obj.m_LocalTimeStep;
        % remove extra decimal places from the time calculations
        obj.m_LocalTime = round(obj.m_LocalTime/obj.m_LocalTimeStep)*...
            obj.m_LocalTimeStep;
        % Augment the agent trajectory data. First add in the local time
        xn = [xn;obj.m_LocalTime];
        hDataBus.DynStatesTraj = [hDataBus.DynStatesTraj xn];
        hDataBus.DynConTraj = [hDataBus.DynConTraj u];
        hDataBus.dynres = [hDataBus.dynres hDataBus.DynResolution];
        % Lastly, calculate the derivatives for the current time point.
        obj = obj.CalcDerivatives();
        % Finally, update the DataBus
        obj.m_hAgent.m_hDataBus = hDataBus;
        %
    case 'RK4'
        %******************************************************************
        % 4th ORDER RUNGE-KUTTA
        % The 4th order Runge-Kutta integration algorithm is considered to
        % be sufficiently accurate for dynamic simulation of most aerospace
        % vehicles. It uses 4 evaluations of the derivative function per
        % time-step update, yielding integration errors of the order dt^5.
        % ----------------------
        % Set an alias for the DataBus path
        hDataBus = obj.m_hAgent.m_hDataBus;
        res = hDataBus.m_DynamicResolution;
        h = obj.m_LocalTimeStep;           % step size
        % STEP 1...
        xdstore = hDataBus.getDynStateDotVec(res);
        % First RK data point
        k_1 = hDataBus.getDynStateDotVec(res);
        x = hDataBus.getDynStatesVec(res);
        obj.m_LocalTime = obj.m_LocalTime...
            + 0.5*obj.m_LocalTimeStep;
        % Move the current trajectory estimate to the mid-point of the
        % integration step.
        xn = x+0.5*h*k_1;
        hDataBus.setDynStates(xn,res);
        % STEP 2...
        obj = obj.CalcDerivatives();
        % Second RK data point
        k_2 = hDataBus.getDynStateDotVec(res);
        xn = x+0.5*h*k_2;
        hDataBus.setDynStates(xn,res);
        % STEP 3...
        obj = obj.CalcDerivatives();
        % Third RK data point
        k_3 = hDataBus.getDynStateDotVec(res);
        obj.m_LocalTime = obj.m_LocalTime...
            + 0.5*obj.m_LocalTimeStep;
        xn = x+h*k_3;
        hDataBus.setDynStates(xn,res);
        % STEP 4...
        obj = obj.CalcDerivatives();
        % Final RK data point
        k_4 = hDataBus.getDynStateDotVec(res);
        % Now use the RK integration equation to combine all of the
        % derivative evaluations
        xn = x + (1/6)*(k_1+2*k_2+2*k_3+k_4)*h;  % main equation
        % Write the state and derivative trajectory data to the bus
        hDataBus.setDynStates(xn,res);
        hDataBus.setDynStateDot(xdstore,res);
        % Augment the agent trajectory data. First add in the local time
        obj.m_LocalTime = round(obj.m_LocalTime/obj.m_LocalTimeStep)*...
            obj.m_LocalTimeStep;
        xn = [xn;obj.m_LocalTime];
        hDataBus.DynStatesTraj = [hDataBus.DynStatesTraj xn];
        un = hDataBus.getControlVec(res);
        un = [un;obj.m_LocalTime];
        hDataBus.DynConTraj = [hDataBus.DynConTraj un];
        % Update the state derivative vector to the current time step.
        obj = obj.CalcDerivatives();
        % Finally, update the DataBus
        obj.m_hAgent.m_hDataBus = hDataBus;
end
end

