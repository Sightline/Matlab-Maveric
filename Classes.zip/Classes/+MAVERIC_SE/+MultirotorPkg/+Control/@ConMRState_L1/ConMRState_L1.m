classdef ConMRState_L1 < MAVERIC_SE.MultiResObject.MRState
    %ConMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Control MRFSM
        m_LocalTime             % Control object local time
        m_LocalTimeStep         % Control object sample time
        m_NextTime              % next time Control object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = ConMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_ControlResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_ControlMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Execute(MRStateobj)
            guidstate = MRStateobj.m_hAgent.m_hDataBus.m_GuidanceState;
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            if(strcmp(guidstate,'MTE'))
%                 disp(['Control called at ',num2str(MRStateobj.m_LocalTime)]);
                % In here we put the tracking controller for the generic L1
                % dynamics model
                % Get current position
                [xe,ye,ze,Vf,psi,gamma] = MRStateobj.m_hAgent.m_hDataBus.GetPose(1);
                y = [xe;ye;ze];
                % Get the necessary model data
                tauV = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.Vf_tau;
                %             tauP = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.psi_tau;
                %             tauG = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.gamma_tau;
                % Now compute the tangent manifold
                F(1,1) = Vf*cos(gamma)*cos(psi);
                F(2,1) = Vf*cos(gamma)*sin(psi);
                F(3,1) = -Vf*sin(gamma);
                F(4,1) = -Vf/tauV;
                F(5,1) = 0;
                F(6,1) = 0;
                yd = [F(1,1);F(2,1);F(3,1)];
                % Prevent singularities from appearing in the solution
                if(Vf == 0), Vf = 0.1; end
                if(Vf == 0), Vf = 0.1; end
                if(gamma == pi/2), gamma = pi/2-1e-2; end
                if(gamma == -pi/2), gamma = pi/2+1e-2; end
                % Get the guidance trajectory commands
                xc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.x;
                yc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.y;
                zc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.z;
                ydem = [xc;yc;zc];
                xdc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.xd;
                ydc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.yd;
                zdc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.zd;
                yddem = [xdc;ydc;zdc];
                xddc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.xdd;
                yddc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.ydd;
                zddc = MRStateobj.m_hAgent.m_hDataBus.Guidance.pos.zdd;
                ydddem = [xddc;yddc;zddc];
                % Define the tracking controller linear element matrices
                A = [0 0 0 cos(gamma)*cos(psi) -Vf*cos(gamma)*sin(psi) -Vf*cos(psi)*sin(gamma);...
                    0 0 0 cos(gamma)*sin(psi) Vf*cos(gamma)*cos(psi) -Vf*sin(gamma)*sin(psi);...
                    0 0 0 -sin(gamma) 0 -Vf*cos(gamma);...
                    0 0 0 -1/tauV 0 0;...
                    0 0 0 0 0 0;...
                    0 0 0 0 0 0];
                B = [0 0 0;...
                    0 0 0;...
                    0 0 0;...
                    1/tauV 0 0;...
                    0 1 0;...
                    0 0 1];
                C = [1 0 0 0 0 0;0 1 0 0 0 0;0 0 1 0 0 0];
                % Trackng error dynamics
                H = 4*[1 0 0;0 1 0;0 0 1];
                G = 4*[1 0 0;0 1 0;0 0 1];
                %
                % With all the necessary components now available, compute the
                % control vector. Case 1 is for teh feedback linearisation
                % controller. Case 2 is a controller derived using the
                % defferential flatness properties of the L1 dynaimc model.
                switch 2
                    case 1
                        uc = (C*A*B)\(ydddem-C*A*F+H*(ydem-y)+G*(yddem-yd));
                    case 2
                        tau = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.Vf_tau;
                        Vfc = (xdc*(xdc+tau*xddc)+ydc*(ydc+tau*yddc)+zdc*(zdc+tau*zddc))/(sqrt(xdc^2+ydc^2+zdc^2));
                        sv = sqrt(xdc^2+ydc^2);
                        gamd = (zdc*(xdc*xddc+ydc*yddc)/sv-zddc*sv)/(xdc^2+ydc^2+zdc^2);
                        psid = (xdc*yddc-xddc*ydc)/(xdc^2+ydc^2);
                        uc = [Vfc;psid;gamd]+(C*A*B)\(H*(ydem-y)+G*(yddem-yd));
                end
                % Saturate the controls
                u_max = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.Vf_max;
                if(uc(1,1) > u_max)
                    uc(1,1) = u_max;
                end
                if(uc(1,1) < -u_max)
                    uc(1,1) = -u_max*pi/180;
                end
                u_max = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.psid_max;
                if(uc(2,1) > (u_max*pi/180))
                    uc(2,1) = (u_max*pi/180);
                end
                if(uc(2,1) < -(u_max*pi/180))
                    uc(2,1) = -(u_max*pi/180);
                end
                u_max = MRStateobj.m_hAgent.m_hDataBus.ParameterData.L1Dyn.gammad_max;
                if(uc(3,1) > (u_max*pi/180))
                    uc(3,1) = (u_max*pi/180);
                end
                if(uc(3,1) < -(u_max*pi/180))
                    uc(3,1) = -(u_max*pi/180);
                end
                MRStateobj.m_hAgent.m_hDataBus.setControls(uc,1);
            end
            
            % Update the internal control clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
end

