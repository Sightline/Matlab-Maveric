classdef AIMRState_L1 < MAVERIC_SE.MultiResObject.MRState
    %AIL1MRState - 
    %   Detailed explanation goes here
    
    % This properties block satisfies the AI state interface
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the AI MRFSM
        m_LocalTime             % AI object local time
        m_LocalTimeStep         % AI object sample time
        m_NextTime              % next time AI object should fire
    end
    
    % This properties block contains properties local to this specific
    % implementation.
    properties
        m_hAIFSM                % Handle to the AI FSM
    end
    
    % This block of methods satisfies the MRState interface.
    methods
        function obj = AIMRState_L1(hAgent,hMRFSM)
            obj.m_hAgent = hAgent;
            obj.m_hMRFSM = hMRFSM;
            obj.m_hAIFSM = getFSM(obj);
        end
        
        function FSM = getFSM(obj)
            import MAVERIC_SE.MultirotorPkg.AI.*
            FSM = AI_L1.FSM(obj);
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Method called when the state is entered. 
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_AIMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            % Create the AI FSM 
            import MAVERIC_SE.MultirotorPkg.AI.*
            MRStateobj.m_hAIFSM = AI_L1.FSM(MRStateobj);
        end
        
        function MRStateobj = Execute(MRStateobj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            
            % Method called when the state is active. Update the AIFSM.
            MRStateobj.m_hAIFSM.Update();
            
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
            % Method called when exiting the state
        end
    end
    
    % This block of methods contains functionality local to the specific
    % state implementation.
    methods
    end
end

