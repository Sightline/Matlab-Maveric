function UpdateQueue(targetDBobj,trackDB)
%UPDATEQUEUE Method to update and sort the target queue list
%-------------------------------------------------------------------
%
% Author: David Anderson
% Date: 12/06/2014
%
%-------------------------------------------------------------------
%
[ntracks,~] = size(trackDB);
% Now, compare the ID's in the track database with those in the
% target queue. The target queue contains those agents that have fallen within the detection range of
% the agents tracking system.
for i=1:ntracks
    newtargetflag = 1;
    if(targetDBobj.m_NumTargetsQueue == 0)
        newtargetflag = 1;
        m = 0;
    else
        m = targetDBobj.m_NumTargetsQueue;
        for j=1:m
            % In the queue, only the Track ID's are used for comparison. If
            % the trackID of the current trackDB track is already in the
            % target queue, set the newtargetflag to zero.
            if(strcmp(trackDB{i,1}.TrackID,targetDBobj.m_TargetQueue{j,1}.TrackID))
                newtargetflag = 0;
                % If this track belongs to an existing target, need to update the
                % target position.
                targetDBobj.m_TargetQueue{j,1}.R = trackDB{i,1}.R;
                targetDBobj.m_TargetQueue{j,1}.xpos = trackDB{i,1}.xpos;
                targetDBobj.m_TargetQueue{j,1}.ypos = trackDB{i,1}.ypos;
            end
        end
    end
    %        
    % Now check if the current track corresponds to a target that has
    % already been identified.
    if(newtargetflag)
        % Now check the list of Identified targets.
        visitedflag = 0;
        for j=1:targetDBobj.m_NumIdentified;
            %
            if(strcmp(trackDB{i,1}.TrackID,targetDBobj...
                    .m_TargetsIdentified{j,1}.TrackID))
                visitedflag = 1;
                break;
            end
        end
        % If the current track corresponds to a target already inspected,
        % move on to the next track.
        if(visitedflag)
            continue;
        end
        % Now check if the track belongs to a destroyed target.
        destroyedflag = 0;
        for j=1:targetDBobj.m_NumDestroyed;
            %
            if(strcmp(trackDB{i,1}.TrackID,targetDBobj...
                    .m_ThreatsDestroyed{j,1}.TrackID))
                destroyedflag = 1;
                break;
            end
        end
        % If the current track corresponds to a target already destroyed,
        % move on to the next track.
        if(destroyedflag)
            continue;
        end
        % If the current track corresponds to a weapon launched by the
        % base platform, ignore
        weaponflag = 0;
        n = length(targetDBobj.m_hAgent.m_hDataBus.m_hWeaponsArray);
        for j=1:n
            if(strcmp(trackDB{i,1}.TrackID,targetDBobj...
                    .m_hAgent.m_hDataBus.m_hWeaponsArray{j}.m_hDataBus.m_AgID))
                weaponflag = 1;
                break;
            end
        end
        if(weaponflag)
            continue;
        end
        %
        %
        % Finally, if the track has passed all these tests, add it to the
        % trackqueue
        if(m==0)
            targetDBobj.m_TargetQueue{1,1} = trackDB{i,1};
        else
            targetDBobj.m_TargetQueue{end+1,1} = trackDB{i,1};
        end
        targetDBobj.m_NumTargetsQueue = targetDBobj.m_NumTargetsQueue + 1;
    end
end


%% Prioritise targets
% Method used to sort the TargetQueue using whatever logic is
% demanded by the vignette. Most simple case is
% nearest-neighbour.
n = 0;
if(targetDBobj.m_NumTargetsQueue > 1) % only sort if more than 1 target
    n = targetDBobj.m_NumTargetsQueue;
for ii = 1:n
    for jj = n:-1:2
        % Here we define the condition for sorting the target list. For the
        % nearest neighbour inspection pattern, comparison of the relative
        % ranges should be used.
        if(targetDBobj.m_TargetQueue{jj,1}.R < ...
                targetDBobj.m_TargetQueue{jj-1,1}.R)
            tmp = targetDBobj.m_TargetQueue{jj-1,1};
            targetDBobj.m_TargetQueue{jj-1,1} = ...
                targetDBobj.m_TargetQueue{jj,1};
            targetDBobj.m_TargetQueue{jj,1} = tmp;
        end
    end
end
end
end

