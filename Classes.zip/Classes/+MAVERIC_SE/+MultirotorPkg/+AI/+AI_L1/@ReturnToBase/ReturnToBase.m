classdef ReturnToBase < handle
    %RETURNTOBASE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
        m_hBase
    end
    
    methods
        function stateobj = ReturnToBase(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
            stateobj.m_hBase = [];
        end
        
        function stateobj = Enter(stateobj)
            %
            stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'ReturnToBase';
            for ag = 1:stateobj.m_hAgent.m_hBB.m_NumAgents
                if(strcmp(stateobj.m_hAgent.m_hBB.m_AgentList{ag}.Tag,'Base'))
                    stateobj.m_hBase = stateobj.m_hAgent.m_hBB.m_AgentList{ag};
                    break;
                end
            end
        end
        
        function stateobj = Execute(stateobj)
            % Test whether we have reached the base. First, get the current
            % position of the platform
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            % Now get the position of the base
            rbase(1,1) = stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.xe;
            rbase(2,1) = stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ye;
            rbase(3,1) = stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ze;
            xe = r(1,1); ye = r(2,1); ze = r(3,1);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = rbase(1,1);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = rbase(2,1);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = rbase(3,1);
            d = sqrt((rbase(1,1)-xe)^2+(rbase(2,1)-ye)^2+(rbase(3,1)-ze)^2);
            if (d < 100)
                import MAVERIC_SE.MultirotorPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(Land(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
            %
        end
        
        function Exit(stateobj)
            % 
            delete(stateobj);
        end
        
    end
    
end

