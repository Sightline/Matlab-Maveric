classdef Attack < handle
    %ATTACK Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
        m_memory
    end
    
    methods
        function AIStateobj = Attack(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
        end
        
        function AIStateobj = Enter(AIStateobj)
            % Set the current waypoint to the initial location of the
            % target (this can be updated in future iterations)
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Attack';
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            % Bring the helicopter to hover.
            AIStateobj.m_memory.Vc = AIStateobj.m_hAgent.m_hDataBus.Vc;
            AIStateobj.m_hAgent.m_hDataBus.Vc = 0;
            %First, get the handle to the target object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            hTarget = theSIM.m_hScene.m_hBB.GetAgent(AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.TrackID);
            % Now, activate the next missile in the list
            hMissile = AIStateobj.m_hAgent.m_hDataBus.m_hChildren...
                .Missiles{AIStateobj.m_hAgent.m_hDataBus.ParameterData...
                .m_CurrentMissile};
            % Designate the target
            hMissile.m_hDataBus.m_hTarget = hTarget;
            % Activate the missile EO sensor
            hMissile.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_SimStatus = 'Active';
            AIStateobj.m_memory.hMissile = hMissile;
        end
        
        function AIStateobj = Execute(AIStateobj)
            % Update the target queue
            import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
            AIStateobj.m_hAIFSM.m_hTargetDB.UpdateQueue(AIStateobj.m_hAgent...
                .m_hDataBus.m_hChildren.Radar.m_hDataBus.m_hTrackDB);
            
            % Need to account for the case where there are no targets...
            if(isempty(AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue))
                AIStateobj.m_hAIFSM.ChangeState(Search(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                return;
            end
            
            % Update the target position
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.zpos;
            
            % Check current airspeed
            [~,~,~,Vf,~,~] = AIStateobj.m_hAgent.m_hDataBus.getDynStates(1);
            if(Vf < 0.5)
                % Issue launch command
                AIStateobj.m_memory.hMissile.m_hDataBus.m_LaunchCommand = true;
                % now transition to cruise speed once the missile has
                % detonated.
                if(strcmp(AIStateobj.m_memory.hMissile.m_hDataBus.m_SimStatus,'Destroyed'))
                    AIStateobj.m_hAgent.m_hDataBus.Vc = AIStateobj.m_memory.Vc;
                    % and back to inspect
                    AIStateobj.m_hAIFSM.ChangeState...
                        (BDI(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                end
            end
            
        end
        
        
        function AIStateobj = OldExecute(AIStateobj)
            % Calculate the distance to current target
            d = Distance2Target(AIStateobj);
            % Get the handle to the current target agent object
            hTarget = AIStateobj.m_hAgent.m_hBB.GetAgent(...
                AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ID);
            % Simulate the firefight
            UpdateFirefight(AIStateobj,hTarget,d);
            % Test the health of target and helicopter
            if(hTarget.m_hDataBus.m_Health < 0)
                % Designate the target as dead.
                KillTarget(AIStateobj);
                % Move on to the next target
                import HeliPkg.AI.AIL1.*
                AIStateobj.m_hAgent.m_hDataBus.m_hTargetsInspected{end+1} = AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1};
                % Remove the current target from the list
                [~,n] = size(AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue);
                if(n==1)
                    AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                end
                if(n > 1)
                    tmpq = AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue;
                    AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                    for i=2:n
                        AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue{i-1} = tmpq{i};
                    end
                end
                AIStateobj.m_hAIFSM.ChangeState(Search(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                return;
            end
            %
            if(AIStateobj.m_hAgent.m_hDataBus.m_Health < 50)
                % Too much damage - return to base
                import HeliPkg.AI.AIL1.*
                disp('Taken too much damage - returning to base...');
                AIStateobj.m_hAIFSM.ChangeState(ReturnToBase(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
            end
        end
        
        function Exit(AIStateobj)
            %
%             delete(AIStateobj);
        end
        
        function dist = Distance2Target(AIStateobj)
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ypos;
            % Test whether we have reached the current waypoint.
            xh = AIStateobj.m_hAgent.m_hDataBus.x(1,1);
            yh = AIStateobj.m_hAgent.m_hDataBus.x(2,1);
            xw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            dist = sqrt((xw-xh)^2+(yw-yh)^2);
        end
        
        function KillTarget(obj)
            %
            target = obj.m_hAgent.m_hBB.GetAgent(...
                obj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ID);
            target.m_hDataBus.m_Health = 0;
            disp('Target eliminated...');
        end
        
        function UpdateFirefight(AIStateobj,hTarget,d)
            %
            hHeliDB = AIStateobj.m_hAgent.m_hDataBus;
            hTargetDB = hTarget.m_hDataBus;
            Ah = hHeliDB.Area;
            Ai = hTargetDB.Area;
            % Loop over each weapon in each agents arsenal
            for iw = 1:length(hHeliDB.m_hWeaponsArray)
            sig = (hHeliDB.m_hWeaponsArray{iw}.CEP/1.177)*(d/100);
            Ph = 1 - exp(-Ai/(2*pi*(sig)^2));
            hitCounter = 0;
            for iround = 1:(hHeliDB.m_hWeaponsArray{iw}.RoF...
                    *hHeliDB.m_LocalTimeStep)
                if(abs(randn(1)) < Ph)
                    hitCounter = hitCounter + 1;
                end
            end
            % Update the target health (NOTE: this needs to be the real
            % target in the blackboard, not the alias).
            hTargetDB.m_Health = hTargetDB.m_Health - hitCounter...
                * hHeliDB.m_hWeaponsArray{iw}.RoundDamage;
            AIStateobj.m_hAgent.m_hBB.GetAgent(hTargetDB.m_AgID).m_hDataBus.m_Health = hTargetDB.m_Health;
            end
            % and the targets...
            for iw = 1:length(hTargetDB.m_hWeaponsArray)
            sig = (hTargetDB.m_hWeaponsArray{iw}.CEP/1.177)*(d/100);
            Ph = 1 - exp(-Ah/(2*pi*(sig)^2));
            hitCounter = 0;
            for iround = 1:(hTargetDB.m_hWeaponsArray{iw}.RoF...
                    *hHeliDB.m_LocalTimeStep)
                if(abs(randn(1)) < Ph)
                    hitCounter = hitCounter + 1;
                end
            end
            % Update the target health (NOTE: this needs to be the real
            % target in the blackboard, not the alias).
            hHeliDB.m_Health = hHeliDB.m_Health - hitCounter...
                * hTargetDB.m_hWeaponsArray{iw}.RoundDamage...
                * hTargetDB.m_hWeaponsArray{iw}.NumThreats;
            AIStateobj.m_hAgent.m_hDataBus.m_Health = hHeliDB.m_Health;
            end
            fprintf('Range = %4.0f, Helicopter Health = %3.0f%%, Infantry Health = %3.0f%%\n',d,hHeliDB.m_Health,hTargetDB.m_Health);
        end
        
    end
    
end

