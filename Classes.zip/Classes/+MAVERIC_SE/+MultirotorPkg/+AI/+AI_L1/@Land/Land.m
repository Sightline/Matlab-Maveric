classdef Land < handle
    %LAND Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Land(hAgent, hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            %
            stateobj.m_hAgent.m_hDataBus.Vc = 0;
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
            disp('Entered landing mode');
        end
        
        function stateobj = Execute(stateobj)
            %
            [~,~,~,Vf,~,~] = stateobj.m_hAgent.m_hDataBus.getDynStates(1);
            if(Vf < 0.1)
                stateobj.m_hAgent.m_hDataBus.IsLanded = 'y';
%                 disp('Helicopter RTB - Mission Success......');
                import MAVERIC_SE.MultirotorPkg.AI.AI_L1.*
%                 stateobj.m_hAIFSM.ChangeState(Idle(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
        end
        
        function Exit(stateobj)
            %
            delete(stateobj);
        end
    end
    
end

