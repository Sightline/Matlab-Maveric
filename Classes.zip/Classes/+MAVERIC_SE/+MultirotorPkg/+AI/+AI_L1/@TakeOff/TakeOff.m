classdef TakeOff < handle
    %TAKEOFF Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = TakeOff(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            % Define the Waypoint vector and store in the agent databus.
%             stateobj.m_hAgent.m_hDataBus.WPindex = 1;
%             stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected = [];
%             stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
%             stateobj.m_hAgent.m_hDataBus.m_hTargetDB = cell(4,1);
%             stateobj.m_hAgent.m_hDataBus.IsLanded = 'n';
%             r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
%             xe = r(1,1); ye = r(2,1);ze = r(3,1);
%             stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.xe = xe;
%             stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ye = ye;
%             stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ze = ze;
            stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Take-Off';
            stateobj.m_hAgent.m_hDataBus.Vc = stateobj.m_hAgent...
                .m_hDataBus.ParameterData.L1Dyn.Vf_cruise;
            %
        end
        
        function stateobj = Execute(stateobj)
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
            % Test whether we have reached the current waypoint.
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xh = r(1,1); yh = r(2,1);zh = r(3,1);
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            nwp = stateobj.m_hAgent.m_hDataBus.NumWayPoints;
            xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            d = sqrt((xw-xh)^2+(yw-yh)^2+(zw-zh)^2);
%             if (d < 0.1 && wpind < nwp)
                wpind = wpind + 1;
                stateobj.m_hAgent.m_hDataBus.WPindex = wpind;
                % Upon reaching the first waypoint, transition to the
                % follow state.
                disp(['Transition to Follow mode triggered at ',num2str(stateobj.m_hAIFSM.m_hCurrentMRAIState.m_LocalTime),'s']);
                import MAVERIC_SE.MultirotorPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(Follow(stateobj.m_hAgent,stateobj.m_hAIFSM));
                
%             end            
        end
        
        function Exit(stateobj)
            % 
            delete(stateobj);
        end
     
    end
    
end

