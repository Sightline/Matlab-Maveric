classdef BDI < handle
    %BDI Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function AIStateobj = BDI(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
        end
        
        function AIStateobj = Enter(AIStateobj)
            % Set the current waypoint to the initial location of the
            % target (this can be updated in future iterations)
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'BDI';
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            AIStateobj.m_hAgent.m_hDataBus.ParameterData...
                .m_CurrentMissile = AIStateobj.m_hAgent.m_hDataBus.ParameterData...
                .m_CurrentMissile + 1;
        end
        
        function AIStateobj = Execute(AIStateobj)
            % Update the target queue
            import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
            AIStateobj.m_hAIFSM.m_hTargetDB.UpdateQueue(AIStateobj.m_hAgent...
                .m_hDataBus.m_hChildren.Radar.m_hDataBus.m_hTrackDB);
            
            % Need to account for the case where there are no targets...
            if(isempty(AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue))
                AIStateobj.m_hAIFSM.ChangeState(Search(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                return;
            end
            % Update the target position
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            % Calculate the overflight distance to current target
            d = Distance2Target(AIStateobj);
            % When close enough, perform battle damage inspection
            if (d < 100)
                % Once target is confirmed as destroyed, update queue
                import MAVERIC_SE.RotorcraftPkg.AI.AIL1.*
                AIStateobj.m_hAIFSM.m_hTargetDB.ThreatDestroyed(AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1});
                % Now return to the search state if there are no more
                % targets in the target queue.
                if(AIStateobj.m_hAIFSM.m_hTargetDB.m_NumTargetsQueue == 0)
                    AIStateobj.m_hAIFSM.ChangeState(Search(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                end
            end
        end
        
        function Exit(AIStateobj)
            %
            delete(AIStateobj);
        end
        
        function dist = Distance2Target(AIStateobj)
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            % Test whether we have reached the current waypoint.
            [xh,yh,~,~,~,~] = AIStateobj.m_hAgent.m_hDataBus.GetPose(1);
            xw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            dist = sqrt((xw-xh)^2+(yw-yh)^2);
        end
        
    end
    
end

