classdef Follow < handle
    %Follow Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Follow(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            % Upon entering the Follow mode, you should always set the
            % next waypoint as the closest in the directory (especially
            % important when re-entering Follow mode following inspect).
            if(strcmp(stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode,'Inspect'))
                % Get waypoint vectors
                xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe;
                yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye;
                zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze;
                % Get helicopter pose
                [xh,yh,zh,~,~,~] = stateobj.m_hAgent.m_hDataBus.GetPose(1);
                % Calculate current distance to each waypoint
                Rwp = [];
                for ii = 1:stateobj.m_hAgent.m_hDataBus.NumWayPoints;
                    Rwp(ii) = sqrt((xw(ii)-xh)^2+(yw(ii)-yh)^2+(zw(ii)-zh)^2);
                end
                [~,indx] = min(Rwp);
                stateobj.m_hAgent.m_hDataBus.WPindex = indx;
            end
            % Set the current AI mode
            stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Follow';
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'MTE';
        end
        
        function stateobj = Execute(stateobj)
            
            % Test whether we have reached the current waypoint.
%             r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
%             xe = r(1,1); ye = r(2,1); ze = r(3,1);
%             wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
%             nwp = stateobj.m_hAgent.m_hDataBus.NumWayPoints;
%             xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
%             yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
%             zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
%             stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
%             stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
%             stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
%             d = sqrt((xw-xe)^2+(yw-ye)^2+(zw-ze)^2);
%             if (d < 0.1)
%                 wpind = wpind + 1;
%             end
%             stateobj.m_hAgent.m_hDataBus.WPindex = wpind;
%             % Now, the code governing state transition to RTB.
%             % Transition event will be when the helicopter on the final waypoint
%             wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
%             if (wpind > nwp)
%                 import MAVERIC_SE.MultirotorPkg.AI.AI_L1.*
%                 stateobj.m_hAIFSM.ChangeState(ReturnToBase(stateobj.m_hAgent,stateobj.m_hAIFSM));
%             end
            %
        end
        
        function Exit(stateobj)
            % 
            delete(stateobj);
        end
        
    end
    
end

