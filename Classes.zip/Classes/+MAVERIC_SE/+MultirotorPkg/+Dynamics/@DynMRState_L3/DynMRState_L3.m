classdef DynMRState_L3 < MAVERIC_SE.MultiResObject.MRState
    %DynMRState_L3 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Dynamics MRFSM
        m_LocalTime             % Dynamics object local time
        m_LocalTimeStep         % Dynamics object sample time
        m_NextTime              % next time Dynamics object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = DynMRState_L3(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_DynamicResolution = 3;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_DynamicMRStatesTimeSteps(3);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            % Augment the agent trajectory data. First add in the local time
%             x = MRStateobj.m_hAgent.m_hDataBus.getDynStatesVec(MRStateobj.m_hAgent.m_hDataBus.m_DynamicResolution);
%             xn = [x;MRStateobj.m_hAgent.m_hDataBus.m_LocalTime];
%             MRStateobj.m_hAgent.m_hDataBus.DynStatesTraj = xn;
%             xd = MRStateobj.m_hAgent.m_hDataBus.getDynStateDotVec(MRStateobj.m_hAgent.m_hDataBus.m_DynamicResolution);
%             xd = [xd;MRStateobj.m_hAgent.m_hDataBus.m_LocalTime];
%             MRStateobj.m_hAgent.m_hDataBus.DynStateDotTraj = xd;
        end
        
        function MRStateobj = Execute(MRStateobj)
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_DynamicMRStatesTimeSteps(3);
            MRStateobj = MRStateobj.CalcDerivatives();
            MRStateobj = MRStateobj.IntegrateDyn();
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
    methods
        % These methods are implemented in seperate files - need to define
        % their calling signature in the main class file.
        MRStateobj = IntegrateDyn(MRStateobj);
        MRStateobj = CalcDerivatives(MRStateobj);
    end
    
end

