classdef DetMRState_L1 < MAVERIC_SE.MultiResObject.MRState 
    %DetMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Detection MRFSM
        m_LocalTime             % Detection object local time
        m_LocalTimeStep         % Detection object sample time
        m_NextTime              % next time Detection object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = DetMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
        end
        
        function MRStateobj = Execute(MRStateobj)
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

