function [SystemMatrix,ControlMatrix] = Linearise(MRDynStateobj,DiffMethod)
%LINEARISE Code to linearise the nonlinear model in CalcDerivatives
%   
%
%% Get operating point
% we need to retrive and store the baseline configuration for the state and
% control vectors.  
%
% Set an alias for the databus
hDataBus = MRDynStateobj.m_hAgent.m_hDataBus;
Res = hDataBus.m_DynamicResolution;
%% Extract the control and state vectors
% First the state vector
State = hDataBus.getDynStatesVec(Res);
% now the control vector
Con = hDataBus.getControlVec(Res);
%% Calculate Jacobian
switch DiffMethod
    case 'Forward'
        %**************************************************************
        % Forward Difference method
        %**************************************************************
        nstates = max(size(States)); ncontrols = max(size(Con));
        nx = nstates+ncontrols;
        DF = zeros(nstates,nstates+ncontrols+1);
        DX = zeros(nstates+ncontrols,nstates+ncontrols+1);
        % Store baseline states
        MRDynStateobj.m_hDataBus.xbase = State;
        MRDynStateobj = MRDynStateobj.CalcDerivatives();
        MRDynStateobj.m_hAgent.m_hDataBus.xdbase = MRDynStateobj.m_hAgent.m_hDataBus.getDynStateDotVec(Res);
        % Now create the perturbation matrix (forward difference)
        DX(:,1) = [States;Con];
        for j = 1:nx
            if(DX(j,1) > 0.01)
                pert = DX(j,1)*1.01;
            else
                pert = 0.01;
            end
            DX(:,j+1) = DX(:,1);
            DX(j,j+1) = pert;
        end
        %
        for ipert = 1:nstates+ncontrols+1
            % Get baseline derivatives. First, set the state vector
            MRDynStateobj.m_hDataBus.setDynStates(DX(1:nstates,ipert),Res);
            % and the control vector
            MRDynStateobj.m_hDataBus.DynControlSignals.u = DX(nstates+1:nx,ipert);
            % Now call the derivative function
            MRDynStateobj = MRDynStateobj.CalcDerivatives();
            % ... and get the derivatives
            tmp = MRDynStateobj.m_hAgent.m_hDataBus.getDynStateDotVec(Res);
            DF(:,ipert) = tmp(1:nstates,1);
        end
        % The final stage is to form the systems and control matrices
        systems_mat = zeros(nstates);
        control_mat = zeros(nstates,ncontrols);
        for i = 1:nstates
            for j = 1:nstates
                systems_mat(i,j) = (DF(i,j+1)-DF(i,1))/(DX(j,j+1)-DX(j,1));
            end
        end
        for i = 1:nstates
            for j = 1:ncontrols
                control_mat(i,j) = (DF(i,j+nstates+1)-DF(i,1))/(DX(j+nstates,j+1+nstates)-DX(j+nstates,1));
            end
        end
        %
    case 'Central'
        %**************************************************************
        % Central Difference method
        %**************************************************************
        nstates = max(size(States)); ncontrols = max(size(Con)); 
        npert = 2*(nstates+ncontrols);
        nx = nstates+ncontrols;
        DF = zeros(nstates,npert+1);
        DX = zeros(nx,npert+1);
        % Store baseline states
        MRDynStateobj.m_hDataBus.xbase = State;
        MRDynStateobj = MRDynStateobj.CalcDerivatives();
        MRDynStateobj.m_hAgent.m_hDataBus.xdbase = MRDynStateobj.m_hAgent.m_hDataBus.getDynStateDotVec(Res);
        % Now create the perturbation matrix (central difference)
        DX(:,1) = [States;Con];
        for j = 1:nx
            % First the positive perturbations
            if(DX(j,1) > 0.01)
                pert = DX(j,1)*0.01;
            else
                pert = 0.01;
            end
            DX(:,j+1) = DX(:,1);
            DX(j,j+1) = DX(j,1)+pert;
            % now the negative
            if(DX(j,1) > 0.01)
                pert = DX(j,1)*0.01;
            else
                pert = 0.01;
            end
            DX(:,j+nx+1) = DX(:,1);
            DX(j,j+nx+1) = DX(j,1)-pert;
        end
        %
        for ipert = 1:npert+1
            % Get baseline derivatives. First, set the state vector
            MRDynStateobj.m_hAgent.m_hDataBus.setDynStates(DX(1:nstates,ipert),Res);
            % and the control vector
            MRDynStateobj.m_hAgent.m_hDataBus.DynControlSignals.u = DX(nstates+1:nx,ipert);
            % Now call the derivative function
            MRDynStateobj = MRDynStateobj.CalcDerivatives();
            % ... and get the derivatives
            tmp = MRDynStateobj.m_hAgent.m_hDataBus.getDynStateDotVec(Res);
            DF(:,ipert) = tmp(1:nstates,1);
        end
        % The final stage is to form the systems and control matrices
        systems_mat = zeros(nstates);
        control_mat = zeros(nstates,ncontrols);
        for i = 1:nstates
            for j = 1:nstates
                systems_mat(i,j) = (DF(i,j+1)-DF(i,j+nx+1))/(2*(DX(j,j+1)-DX(j,1)));
            end
        end
        for i = 1:nstates
            for j = 1:ncontrols
                control_mat(i,j) = (DF(i,j+nstates+1)-DF(i,j+nx+nstates+1))/(2*(DX(j+nstates,j+nstates+1)-DX(j+nstates,1)));
            end
        end
end
% Finally, write the linearised matrices to the databus
SystemMatrix = systems_mat;
ControlMatrix = control_mat;

end

