function [trimState,trimCon,trimDeriv,Resid] = Trim(MRDynState,DesiredTrim,Options)
% Trim.m - Takes a dynamic object and finds the values of the control
% inputs such that the body axes accelerations are zero.
% This function uses an implementation of the Newton-Rhapson algorithm.
%% Obtain the baseline states.
% Set alias for the databus
hDataBus = MRDynState.m_hAgent.m_hDataBus;
% Get the current resolution of the dynamics module
Res = hDataBus.m_DynamicResolution;
% First get the state vector
State = hDataBus.getDynStatesVec(Res);
% now the control vector
Con = hDataBus.getControlVec(Res);
% To get the current state derivative vector, run the relevant derivative
% calculation code
MRDynState = MRDynState.CalcDerivatives();
StateDot = MRDynState.m_hAgent.m_hDataBus.getDynStateDotVec(Res);
%% 



% First the state vector
[u,v,w,p,q,r,phi,theta,psi,xe,ye,ze] = hDataBus.getDynStates(2);
m = 225; g = 9.81;
MRDynState.m_hAirframe = MRDynState.m_hAirframe.CalcDerivatives();
xdb = [-m*g*sin(theta);0;m*g*cos(theta);0;0;0];
% now the control vector
del_c = hDataBus.getControlVec(2);
dnorm = 1e6; tol = 0.01; iloop = 1;
% Start the NR iteration
while( dnorm > tol && iloop < 3 )
    % Calculate the Jacobian
    %**************************************************************
    % Forward Difference method
    %**************************************************************
    import MissilePkg.Airframe.*
    nstates = 6; ncontrols = 4;
    nx = nstates+ncontrols;
    DF = zeros(nstates,nstates+ncontrols+1);
    DX = zeros(nstates+ncontrols,nstates+ncontrols+1);
    % Store baseline states
    MRDynState.m_hAirframe = MRDynState.m_hAirframe.CalcDerivatives();
    xd = MRDynState.m_hDataBus.getDynStateDotVec(2);
    x = xd(1:6,1);
    % Now create the perturbation matrix (forward difference)
    DX(:,1) = [u;v;w;p;q;r;del_c(1,1);del_c(2,1);del_c(3,1);del_c(4,1)];
    for j = 1:nx
        if(DX(j,1) > 0.01)
            pert = DX(j,1)*1.01;
        else
            pert = 0.01;
        end
        DX(:,j+1) = DX(:,1);
        DX(j,j+1) = pert;
    end
    %
    for ipert = 1:nstates+ncontrols+1
        % Get baseline derivatives. First, set the state vector
        MRDynState.m_hDataBus.setDynStates([DX(1:nstates,ipert);phi;theta;psi;xe;ye;ze],2);
        % and the control vector
        MRDynState.m_hDataBus.DynControlSignals.u = DX(nstates+1:nx,ipert);
        % Now call the derivative function
        MRDynState.m_hAirframe = MRDynState.m_hAirframe.CalcDerivatives();
        % ... and get the derivatives
        tmp = MRDynState.m_hDataBus.getDynStateDotVec(2);
        DF(:,ipert) = tmp(1:nstates,1);
    end
    % The next stage is to form the Jacobian
    J = zeros(nstates,ncontrols);
    for i = 1:nstates
        for j = 1:ncontrols
            J(i,j) = (DF(i,j+nstates+1)-DF(i,1))/(DX(j+nstates,j+1+nstates)-DX(j+nstates,1));
        end
    end
    %
    % Newton-Raphson method
    %
    uerr = (J'*J)\J'*(x)
    del_c = del_c - uerr;
    %
    % Check the convergence
    MRDynState.m_hDataBus.setDynStates([u;v;w;p;q;r;phi;theta;psi;xe;ye;ze],2);
    hDataBus.setControls(del_c,2);
    MRDynState.m_hAirframe = MRDynState.m_hAirframe.CalcDerivatives();
    xd = MRDynState.m_hDataBus.getDynStateDotVec(2);
    x = xd(1:6,1);
    dnorm = sqrt((x-xdb)'*(x-xdb));
    iloop = iloop+1;
end
%% Set the controls
hDataBus.setControls(del_c,2);
hDataBus.DynControlTrim = del_c;