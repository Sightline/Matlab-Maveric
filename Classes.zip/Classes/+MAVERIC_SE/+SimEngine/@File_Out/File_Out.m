classdef File_Out < handle
    properties
        dpath; % Path to the directory that the output wants to be placed
        fname; % Filename to be placed in the above directory
        
        BB;    % Handle to the blackboard
    end
    properties (SetAccess = private)
        opath; % Combining the dpath and fname for faster access during output calls
        ovar;  % List of the output variables
    end
    methods
        function obj = File_Out(directory,filename,BB)
            % If the file exists then generate a new filename
            count = 1;
            ftemp = filename;
            while true
                if exist([directory,ftemp,'.csv'],'file') == 2
                    ftemp = [filename,sprintf('[%i]',count)];
                else
                    break;
                end
                count = count + 1;
            end
            
            % Assign the filename and directory
            obj.dpath = directory;
            obj.fname = ftemp;
            obj.opath = [directory,ftemp,'.csv'];
            
            % Assign the link to the blackboard
            obj.BB = BB;
        end
        
        function createFileHeader(obj)
            % Method to create the first line of the csv output file
            try
                f = fopen(obj.opath,'w');
                % First column is time-stamp
                fprintf(f,'Time(s)');
                
                % Loop through the agents and set-up their headings
                for ii = 1:obj.BB.m_NumAgents
                    % Currently using the order of agents to link data
                    % from each update. If the order were to change, use
                    % the agent ID instead:
                    % agentID = obj.BB.m_AgentList{ii}.m_hDataBus.m_AgID;
                    fprintf(f,'%s',obj.getAgentHeaderString(ii)); 
                end
                
                % Finish with returning to a new line
                fprintf(f,'\r\n');
                fclose(f);
            catch ME
                fclose(f);
                error('Writing to the file failed. Header was not created and closing connection to file')
            end
            
        end
        
        function writeToFile(obj)
            % Method to append to the csv output file during the simulation
            f = fopen(obj.opath,'a');
            
            % Output the time-stamp
            fprintf(f,'%d',obj.BB.m_AgentList{1}.m_hDataBus.x(7,1));
            
            % Loop through the agents getting the relavent data from each
            for ii = 1:obj.BB.m_NumAgents
                % Currently using the order of agents to link data
                % from each update. If the order were to change, use
                % the agent ID instead:
                % agentID = obj.BB.m_AgentList{ii}.m_hDataBus.m_AgID;
                fprintf(f,'%s',obj.getAgentOutputString(ii));
            end
            fprintf(f,'\r\n');
            fclose(f);
        end
        
        function out = getAgentHeaderString(obj,agentNum)
            % Getting the agent to work with
            agent = obj.BB.m_AgentList{agentNum};
            agentID = agent.m_hDataBus.m_AgID;
            out = '';
            
            % State Vector
            out = [out,[',',agentID,'.Xe (m)']];
            out = [out,[',',agentID,'.Ye (m)']];
            out = [out,[',',agentID,'.Ze (m)']];
            out = [out,[',',agentID,'.V (m/s)']];
            out = [out,[',',agentID,'.PSI (rad)']];
            out = [out,[',',agentID,'.GAMMA (rad)']];
            obj.ovar = {'x',6};
            
            % State Derivatives
            out = [out,[',',agentID,'.Xdot (m/s)']];
            out = [out,[',',agentID,'.Ydot (m/s)']];
            out = [out,[',',agentID,'.Zdot (m/s)']];
            out = [out,[',',agentID,'.Vdot (m/s^2)']];
            out = [out,[',',agentID,'.PSIdot (rad/s)']];
            out = [out,[',',agentID,'.GAMMAdot (rad/s)']];
            endIDX = size(obj.ovar,1);
            obj.ovar(endIDX+1,1) = {'xd'};
            obj.ovar(endIDX+1,2) = {6};
            
            % Control Vector
            out = [out,[',',agentID,'.Vdesired (m/s)']];
            out = [out,[',',agentID,'.PSIdot (rad/s)']];
            out = [out,[',',agentID,'.GAMMAdot (rad/s)']];
            endIDX = size(obj.ovar,1);
            obj.ovar(endIDX+1,1) = {'u'};
            obj.ovar(endIDX+1,2) = {3};
            
            if strcmp(class(agent),'HeliPkg.Helicopter')
                out = [out,[',',agentID,'.AIState']];
                out = [out,[',',agentID,'.Tracks']];
                out = [out,[',',agentID,'.TargetsInspected']];
            end
            
        end
        
        function out = getAgentOutputString(obj,agentNum)
            % Getting the agent to work with
            agent = obj.BB.m_AgentList{agentNum};
            agentDB = agent.m_hDataBus;
            out = '';
            
            % Scan through the variables and sequentially print out their
            % values
            for ii = 1:length(obj.ovar)
                % Scan through the state, state derivative and control
                % vectors
                for jj = 1:obj.ovar{ii,2}
                    out = [out,sprintf(',%d',agentDB.(obj.ovar{ii})(jj))];
                end
            end
            
            if strcmp(class(agent),'HeliPkg.Helicopter')
                aiclass = class(agentDB.m_hCurrentAIMRState.m_AIFSM.m_hCurrentState);
                aisplit = strread(aiclass,'%s','delimiter','.');
                
                out = [out,sprintf(',%s',aisplit{end})];
                out = [out,sprintf(',%d',length(agentDB.m_hTrackDB))];
                out = [out,sprintf(',%d',length(agentDB.m_hTargetsInspected))];
            end
            
        end

    end
end