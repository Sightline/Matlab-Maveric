function obj = CleanUpObject(obj)
%CLEANUPOBJECT Summary of this function goes here
%   Detailed explanation goes here


end

