function newobj = CreateObject(ObjectName,ClassName,hDataFile)
%CREATEOBJECT This function creates an object of the type ClassName and
%populates the databus of this object with the data contained in the file
%DataFile.
%
%-------------------------------------------------------------------------%
%  Author: David Anderson
%  Date: 4/2/2014
%  Version:v001
%-------------------------------------------------------------------------%
%  Modification Record....................
%
%
%-------------------------------------------------------------------------%
%
%% Create the instance
% First, check that ClassName is a valid name
% Check if the class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,ClassName)))
    error('The supplied class name is not valid....');
end
addpath(genpath('./'));
% Now create the object instance
try
    obj = eval(['MAVERIC_SE.',ClassName,'Pkg.',ClassName,'(''',ObjectName,''')']);
catch err
    error(err.identifier,err.message);
end
%% Populate the databus.
% With the object instance created, it is now necessary to populate the
% data in the object from that contained in the function handle hDataFile.
try
    status = 'create';
    obj = hDataFile(obj,status);
catch err
    errordlg(err.identifier,err.message);
end
%
newobj = obj;
%% Link to the Blackboard
newobj = newobj.LinkToBB;
end

