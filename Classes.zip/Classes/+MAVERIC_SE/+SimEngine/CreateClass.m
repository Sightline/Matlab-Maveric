function CreateClass(data,baseClass)
%CREATECLASS This method creates the files and namespaces for a new class.
%   Detailed explanation goes here
%
%--------------------------------------------------------------------------
%
%  Author: Dr David Anderson
%  Date: 26/01/2014
%  Version_001
%
%--------------------------------------------------------------------------
%
%
%% Extract the class name, type and base class
name = data.ClassName;
base = baseClass;
%
% Check that the baseClass type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = '';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,base)))
    error('Base class does not exist');
end
% Make the class directory
% Define the home-directory string
dirstr = ['./Classes/+MAVERIC_SE/+',name,'Pkg'];
%% Create the directories and files
% Copy all the files from the baseClassPkg directory
try
    status = copyfile(['./Classes/+MAVERIC_SE/+',base,'Pkg'],dirstr);
catch err
end
% Create the main class files from the templates
    copyfile([dirstr,'/@',base],[dirstr,'/@',name]);
    copyfile([dirstr,'/@',base,'/',base,'.m'],...
        [dirstr,'/@',name,'/',name,'.m']);
    try
        rmdir([dirstr,'/@',base],'s');
        delete([dirstr,'/@',name,'/',base,'.m']);
    catch err
        pause(1);
        rmdir([dirstr,'/@',base],'s');
        delete([dirstr,'/@',name,'/',base,'.m']);
    end
% and the DataBus
copyfile([dirstr,'/@',base,'DataBus'],[dirstr,'/@',name,'DataBus']);
copyfile([dirstr,'/@',base,'DataBus','/',base,'DataBus.m'],...
    [dirstr,'/@',name,'DataBus','/',name,'DataBus.m']);
try
    rmdir([dirstr,'/@',base,'DataBus'],'s');
    delete([dirstr,'/@',name,'DataBus/',base,'DataBus.m']);
catch err
    pause(1);
    rmdir([dirstr,'/@',base,'DataBus'],'s');
    delete([dirstr,'/@',name,'DataBus/',base,'DataBus.m']);
end
%
%% Change the file text
% Within each class package there are sub-directories and eventually leaf
% nodes which are the files we need to alter.
% First, get the first level directory names of the package folders
tmp = dir(dirstr);
[n,~] = size(tmp);
k = 1;
for i = 1:n
    if(~(strcmp(tmp(i).name,'.') || strcmp(tmp(i).name,'..')) &&...
            ~isempty(strfind(tmp(i).name,'+')));% && isempty(strfind(tmp(i).name,'AI')));
        list_L1{k} = tmp(i);
        k = k+1;
    end
end
for i = 1:k-1
    tmp = dir([dirstr,'/',list_L1{i}.name]);
    [n2,~] = size(tmp);
    kk = 1;
    for ii = 1:n2
        if(~(strcmp(tmp(ii).name,'.') || strcmp(tmp(ii).name,'..')) &&...
                isempty(strfind(tmp(ii).name,'+AI_L1')));
            list_L2{kk} = tmp(ii);
            kk = kk+1;
        end
    end
    for j=1:kk-1
        tmp = dir([dirstr,'/',list_L1{i}.name,'/',list_L2{j}.name]);
        [n3,~] = size(tmp);
        for iii = 1:n3
            if(~(strcmp(tmp(iii).name,'.') || strcmp(tmp(iii).name,'..')))
                list_L3 = tmp(iii);
            end
        end
        str = fileread([dirstr,'/',list_L1{i}.name,'/',...
            list_L2{j}.name,'/',list_L3.name]);   %# read contents of file into string
        str = strrep(str, base, name); %# Replace wordA with wordB
        fid = fopen([dirstr,'/',list_L1{i}.name,'/',...
            list_L2{j}.name,'/',list_L3.name], 'w');
        fwrite(fid, str, '*char');              %# write characters (bytes)
        fclose(fid);
    end
end
%
% Now the AI module FSM
str = fileread([dirstr,'/+AI/+AI_L1/@FSM/FSM.m']);   %# read contents of file into string
str = strrep(str, base, name); %# Replace wordA with wordB
fid = fopen([dirstr,'/+AI/+AI_L1/@FSM/FSM.m'], 'w');
fwrite(fid, str, '*char');              %# write characters (bytes)
fclose(fid);
%
% Next, get the first level directory names of the class folders
tmp = dir(dirstr);
[n,~] = size(tmp);
k = 1;
for i = 1:n
    if(~(strcmp(tmp(i).name,'.') || strcmp(tmp(i).name,'..')) &&...
            ~isempty(strfind(tmp(i).name,'@')))
        list_L1{k} = tmp(i);
        k = k+1;
    end
end
for i = 1:k-1
    tmp = dir([dirstr,'/',list_L1{i}.name]);
    [n2,~] = size(tmp);
    for ii = 1:n2
        if(~(strcmp(tmp(ii).name,'.') || strcmp(tmp(ii).name,'..')))
            list_L2 = tmp(ii);
            str = fileread([dirstr,'/',list_L1{i}.name,'/',...
                list_L2.name]);   %# read contents of file into string
            str = strrep(str, base, name); %# Replace wordA with wordB
            fid = fopen([dirstr,'/',list_L1{i}.name,'/',...
                list_L2.name], 'w');
            fwrite(fid, str, '*char');              %# write characters (bytes)
            fclose(fid);
        end
    end
end
%% Finally, add to path,
addpath(genpath('./Classes/'));
end

