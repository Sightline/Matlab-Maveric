function CallReset(this, Agent)
%% Reset the agent data

datafile = str2func(Agent.m_hDataBus.m_DataFile);
Agent = datafile(Agent,'update');
Agent.Reset();

if(~strcmp(Agent.m_hDataBus.m_AgentType,'Sensor'))
    if(isempty(Agent.m_hDataBus.m_hParent))
        Agent.m_hDataBus.setPosition(Agent.m_hDataBus.ParameterData...
            .UserDefinedPos);
        Agent.m_hDataBus.DynStates.psi = Agent.m_hDataBus.ParameterData...
            .UserDefinedHeading;
        Agent.m_hDataBus.DynStatesTraj(:,1) = [Agent.m_hDataBus.getDynStatesVec(1);0];
        Agent.m_hDataBus.DynStateDotTraj(:,1) = [Agent.m_hDataBus.getDynStateDotVec(1);0];
    else
        Agent.m_hDataBus.setPosition(GetUserPos(Agent));
        Agent.m_hDataBus.DynStates.psi = GetUserHeading(Agent);
        Agent.m_hDataBus.DynStatesTraj(:,1) = [Agent.m_hDataBus.m_hParent.m_hDataBus.getDynStatesVec(1);0];
        Agent.m_hDataBus.DynStateDotTraj(:,1) = [Agent.m_hDataBus.m_hParent.m_hDataBus.getDynStateDotVec(1);0];
    end
else
    Agent.m_hDataBus.setPosition(GetUserPos(Agent));
end
%% Check if the agent has any children
if(~isempty(Agent.m_hDataBus.m_hChildrenArray))
    [~,n] = size(Agent.m_hDataBus.m_hChildrenArray);
    for ii = 1:n
        this.CallReset(Agent.m_hDataBus.m_hChildrenArray{ii});
    end
end
end

function pos = GetUserPos(Agent)
% Check parent
parent = Agent.m_hDataBus.m_hParent;
if(~isempty(parent.m_hDataBus.ParameterData.UserDefinedPos))
    pos = parent.m_hDataBus.ParameterData.UserDefinedPos;
    return;
else
    pos = GetUserPos(parent);
end
end

function head = GetUserHeading(Agent)
% Check parent
parent = Agent.m_hDataBus.m_hParent;
if(isfield(parent.m_hDataBus.ParameterData,'UserDefinedHeading') && ~isempty(parent.m_hDataBus.ParameterData.UserDefinedHeading))
    head = parent.m_hDataBus.ParameterData.UserDefinedHeading;
    return;
else
    head = GetUserHeading(parent);
end
end