classdef Simulation < handle
    %SIMULATION The simulation class object is the base object for all
    %aspects of the MAVERIC simulation
    %   Detailed explanation goes here
    
    properties
        m_hScene
        m_hGUI
    end
    
    methods
        function this  = Simulation()
        % Create the Scene object
            import MAVERIC_SG.*
            this.m_hScene = Scene(this);
        % Create the main GUI object
            import MAVERIC_GUI.*
            this.m_hGUI = MainGUI(this);
        end
        %
        function this  = CreateGUI(this)
            this.m_hGUI = this.m_hGUI.CreateGUI();
        end
    end
    
    methods (Static)
        function singleObj = getInstance
            persistent localObj
            if isempty(localObj) || ~isvalid(localObj)
                import MAVERIC_SE.SimEngine.*
                localObj = Simulation;
            end
            singleObj = localObj;
        end
    end
    
    methods
        function this = SetSceneObj(this,Sceneobj)
            this.m_hScene = Sceneobj;
        end
    end
        
    methods
        % These methods are defined in external functions
        this = SingleRun(this);
        this = MonteCarlo(this);
        CallReset(this,Agent);
        
    end
    
end

