function [ output_args ] = MonteCarlo( input_args )
%MONTECARLO Summary of this function goes here
%   Detailed explanation goes here


end

