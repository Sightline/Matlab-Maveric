classdef Agent < handle
    %AGENT Summary of this class goes here
    %   Detailed explanation goes here
     
    properties (Abstract)
        % Blackboard handle
        m_hBB
        % Internal data bus objects
        m_hDataBus
        m_hControlBus
    end
    
    methods (Abstract)
        obj = UpdateDynamics(obj)
        obj = UpdateGeometry(obj)
        obj = UpdateSensorArrayDynamics(obj)
        obj = UpdateSensorArrayDetection(obj)
        obj = UpdateAI(obj)
        obj = UpdateControl(obj)
        obj = UpdateGuidance(obj)
        obj = UpdateNavigation(obj)
        obj = UpdateDetection(obj)
        obj = UpdateSightline(obj)
        obj = UpdateTracking(obj)
        obj = CreateDynamicsObj(obj)
        obj = CreateGeometryObj(obj)
        obj = CreateSensorArray(obj)
        obj = CreateAIObj(obj)
        obj = CreateControlObj(obj)
        obj = CreateGuidanceObj(obj)
        obj = CreateNavigationObj(obj)
        obj = CreateDetectionObj(obj)
        obj = CreateSightlineObj(obj)
        obj = CreateTrackingObj(obj)
        obj = LinkToBB(obj)
        WriteDynToBB(obj)
        WriteGeoToBB(obj)
        ID = AssignID(obj)
        obj = UpdateClock(obj)
        obj = ChangeResolution(obj,newres)
        %
        % Callbacks for listener handles
        obj = UpdateTime(obj,src,evt)
    end
end

