classdef MRState < handle
    %MRSTATE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Abstract)
        m_hAgent
        m_hMRFSM
    end
    
    methods (Abstract)
        out = Enter(MRStateobj);
        out = Execute(MRStateobj);
        out = Exit(MRStateobj);
    end
    
end

