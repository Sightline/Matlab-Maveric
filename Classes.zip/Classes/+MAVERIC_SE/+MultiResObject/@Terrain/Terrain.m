classdef Terrain < handle
    %TERRAIN Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
    end
    
end

