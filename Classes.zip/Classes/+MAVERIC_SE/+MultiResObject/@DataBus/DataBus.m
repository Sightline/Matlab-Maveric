classdef DataBus < handle
    %DATABUS This class contains the properties internal to the agent
    %class.
    %   Detailed explanation goes here
    
    properties (Abstract)
        m_AgID                          % Agent ID
        m_AgentType                     % Agent Type.
        m_ClassName                     % Object Class
        m_DataFile                      % String containing the name of the 
                                        % object datafile
        m_SimStatus                     % Agent simulation status, either 
                                        % 'Active' or 'Dormant'
        m_MRObjectID
        m_MRObjectType
        m_ObjectName                    % Name of the object instance
        m_hParent                       % handle of the parent object
        m_hChildren
        m_AgResolution                  % The main agent resolution
        % Dynamics properties
        m_hDynamicsMRSM
        m_hCurrentDynMRState
        m_DynamicResolution
        m_DynamicMRStatesTimeSteps
        m_HasDynamic
        % Sensor array properties
        m_hSensorArray
        m_hCurrentSAMRStates            % Current sensor array MR states
        % Control properties
        m_hControlMRSM
        m_hCurrentControlMRState
        m_ControlResolution
        m_ControlMRStatesTimeSteps
        m_HasControl
        % Guidance properties
        m_hGuidanceMRSM
        m_hCurrentGuidanceMRState
        m_GuidanceResolution
        m_GuidanceMRStatesTimeSteps
        m_HasGuidance
        m_GuidanceState
        % Navigation properties
        m_hNavigationMRSM
        m_hCurrentNavigationMRState
        m_NavigationResolution
        m_NavigationMRStatesTimeSteps
        m_HasNavigation
        % Detection properties
        m_hDetectionMRSM
        m_hCurrentDetectionMRState
        m_DetectionResolution
        m_DetectionMRStatesTimeSteps
        m_HasDetection
        % Sightline properties
        m_hSightlineMRSM
        m_hCurrentSightlineMRState
        m_SightlineResolution
        m_SightlineMRStatesTimeSteps
        m_HasSightline
        % Tracking properties
        m_hTrackingMRSM
        m_hCurrentTrackingMRState
        m_TrackingResolution
        m_TrackingMRStatesTimeSteps
        m_HasTracking
        % AI properties
        m_hAIMRSM
        m_hCurrentAIMRState
        m_AIResolution
        m_AIMRStatesTimeSteps
        m_HasAI
        m_CurrentWP
        m_AIGNCMode
        m_CurrentAIMode
        % Geometric Properties
        m_hGeometryMRSM
        m_hCurrentGeoMRState
        m_GeometryResolution
        m_GeometryMRStatesTimeSteps
        m_HasGeometry
        % Simulation Engine properties
        m_GlobalTimeStep
        m_LocalTimeStep
        m_GlobalTime
        m_LocalTime
        m_NextUpdate
        % Listener handles
        lh_ChangeDT
        %
        m_RCS
        % Handle to the current axes for displaying agent plot data
        m_hCurrentAxes
        m_hCurrentFigure
        m_hGraphicsHandles
        m_hZoom
        m_hLines
        % Listener Handles
    end
    
    properties (Abstract)
       % Core Data
        DynStates                   % Dynamic states structure
        DynStateDot                 % Dynamic state derivatives structure
        PrevDynStates               % Previous dynamic states structure
        PrevDynStateDot             % Previous dynamic state derivatives structure
        DynControlSignals           % Control signals vector
        DynControlTrim              % Trim control vector values
        DynStatesTraj               % Dynamic states timeseries
        DynConTraj                  % Control vector timeseries
        TransformationMatrices      % Structure containing transformation matrices
        m_NumSensors
        m_SensorRes
        m_hTrackDB
        m_hObservationDB
        m_hTargetDB
        m_hTargetQueue
        m_hTargetsInspected
        NavMeasurements             % Structure containing navigation measurements
        NavTraj                     % Structure containing navigation solutions
        GuidanceFilterEstimates     % Structure containing sightline filter estimates
        GuidanceTraj                % Guidance commands timeseries
        Guidance                    % Structure contaiing guidance data
        EOMeasurements              % Structure containing EO measurements
        ParameterData               % Agent parameter data (constants)
        InertialData
        AerodynamicData
        %  Linearisation (DEBUG) data ------------------------------
        LineariseFlag               %
        SystemMatrix
        ControlMatrix
        LPVmodel
        iModel
        xbase
        xdbase
        % ----------------------------------------------------------
    end
    
    properties (Abstract)
        % These properties are specific to the DSTO (military)
        % implementation
        Area
        m_hWeaponsArray
    end
    
    properties (Abstract)
        % These properties are an alteration to the state vector properties
        % approach used in version 2 i.e. vector array. Need to keep the
        % states in a structure.
        state                   % This is a structure that has all of the 
                                % dynamic states named in the fields. This
                                % consists, at a minimum, of the pose -
                                % position and orientation in inertial
                                % space.
                                % states.xe,ye,ze,phi,theta,psi
        statedot
        statetraj
    end
        
    
%     properties 
%         kt2ms = 0.5144;
%     end
    
    methods
        function obj = DataBus()
            %
        end
        
        function x = getDynStates(this,resolution)
            x.xe = this.xe;
            x.ye = this.ye;
            x.ze = this.ze;
        end
    end
    
end

