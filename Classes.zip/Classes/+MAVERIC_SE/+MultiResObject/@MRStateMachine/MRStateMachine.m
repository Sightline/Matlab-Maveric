classdef MRStateMachine < handle
    %MRSTATEMACHINE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = private)
        m_hAgent
        m_hCurrentMRState
        m_hPreviousMRState
        m_hGlobalMRState
    end
    
    methods 
        function MRFSMobj = MRStateMachine()
            %
        end
        
        function MRFSMobj = Update(MRFSMobj)
            % This function is called by the agent to instruct the MRSM to
            % fire
            MRFSMobj = MRFSMobj.m_hCurrentMRState.Execute(MRFSMobj);
        end
        
        function MRFSMobj = SetCurrentMRState(MRFSMobj,hCurrentMRState)
            %
            MRFSMobj.m_hCurrentMRState = hCurrentMRState;
        end
        
        function MRFSMobj = ChangeMRState(MRFSMobj,hNextMRState)
            % Check that the new state is valid
            assert(isa(hNextMRState,'AgentPkg.MRState'));
            % Exit the current state
            MRFSMobj.m_CurrentMRState.Exit();
            % Replace the current state with the new one
            MRFSMobj.m_hCurrentMRState = hNextMRState;
            % Call the entry method of the new state
            MRFSMobj.m_hCurrentMRState.Enter();
        end
    end
    
end

