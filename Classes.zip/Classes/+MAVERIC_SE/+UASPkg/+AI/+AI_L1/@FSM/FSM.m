classdef FSM < handle
    %FSM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hCurrentState
        m_hPreviousState
        m_hGlobalState
        m_hCurrentMRAIState
        m_hTargetDB
    end
    
    
    methods
        function FSMobj = FSM(hMRAIState)
            FSMobj.m_hCurrentMRAIState = hMRAIState;
            import MAVERIC_SE.UASPkg.AI.AI_L1.*
            FSMobj.m_hTargetDB = TargetDB(hMRAIState.m_hAgent);
            FSMobj.m_hCurrentState = TakeOff(hMRAIState.m_hAgent,FSMobj);
            FSMobj.m_hPreviousState = FSMobj.m_hCurrentState;
        end
        
        function Update(FSMobj)
            if(~isempty(FSMobj.m_hCurrentState))
                % Execute the current AI state
                FSMobj.m_hCurrentState.Execute();
                % Write the targetDB entry
            end
            %
        end
        
        function FSMobj = ChangeState(FSMobj,hNewState)
            % Change the state
            FSMobj.m_hPreviousState = FSMobj.m_hCurrentState;
            FSMobj.m_hCurrentState.Exit();
            FSMobj.m_hCurrentState = hNewState;
            FSMobj.m_hCurrentState.Enter();
        end
        
    end
    
end

