classdef DetMRState_L1 < MAVERIC_SE.MultiResObject.MRState
    %DetMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Detection MRFSM
        m_LocalTime             % Detection object local time
        m_LocalTimeStep         % Detection object sample time
        m_NextTime              % next time Detection object should fire
    end
    
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = DetMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_DetectionResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_DetectionMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Execute(MRStateobj)
            % The primary function of the detection module is to declare an
            % observation if any entity of the scene is within the
            % detection range of the radar. For simplicity (L1 model), we
            % assume an isotropic antenna. A consequence of this assumption
            % is that every entity on the row of the Entity Adjacency
            % Matrix (EntityAM) corresponding to the radar platform is
            % within the angle space of the radar antenna.
            % Observation declaration logic is then a simple matter of
            % using the relative range between sensor and entity and the
            % RCS of the entity.
            %
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % First, re-initialise the observation Database
            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB = [];
            % Get the EntityAM.
            EntityAM = MRStateobj.m_hAgent.m_hBB.m_EntityAM;
            % Get the Agent ID for the platform
            PlatformID = MRStateobj.m_hAgent.m_hDataBus.m_hParent...
                .m_hDataBus.m_AgID;
            % Identify the appropriate row in the EntityAM (indx).
            ne = MRStateobj.m_hAgent.m_hBB.m_NumEntities;
            r = ne+1; c = ne+1; indx = 0;
            for ii = 2:r
                if(strcmp(EntityAM{ii,1,1},PlatformID))
                    indx = ii;
                end
            end
            % Now we must loop over all entities in the agent row. First,
            % reset the observation counter
            obscount = 0;
            % and clear the existing observation database
            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB = [];
            for jj = 2:c
                % First, check if the entity is active. Get the entity
                % handle.
                hEnt = MRStateobj.m_hAgent.m_hBB...
                    .RequestEntityHandle(EntityAM{1,jj,1});
                if(strcmp(hEnt.m_hDataBus.m_SimStatus,'Active'))
                    % Now exclude self-declaration
                    if(~isequal(jj,indx))
                        % Get the range to the entity from the adjacency
                        % matrix.
                        R = EntityAM{indx,jj,1};
                        % Test if this range exceeds the maximum unambiguous
                        % range of the radar (L1 approximation).
                        if( R > MRStateobj.m_hAgent.m_hDataBus.ParameterData.RMaxUnamL1)
                            continue; % Skip to next entity on the row
                        end
                        %
                        % Now condition the range on the agent geometry
                        pos = MRStateobj.m_hAgent.m_hDataBus.m_hParent.m_hDataBus.getPositionVec;
                        lookdown = -MRStateobj.m_hAgent.m_hDataBus.ParameterData.LookDownAngle;
                        beamwidth = MRStateobj.m_hAgent.m_hDataBus.ParameterData.ElBeamwidth;
                        Rmax = pos(3,1)/sin(lookdown+beamwidth/2);
                        if( R > Rmax)
                            continue; % Skip to next entity on the row
                        end
                        % Get RCS parameters
                        RCS_Mean = hEnt.m_hDataBus.ParameterData.RCS_Mean;
                        RCS_Var = hEnt.m_hDataBus.ParameterData.RCS_Var;
                        % Calculate the random instance value of the entity
                        % RCS.
                        sig = RCS_Mean + RCS_Var*randn(1);
                        % Now, this is the detection logic for a L1 radar.
                        % The actual detection range is conditioned on the RCS
                        % of the target.
                        Rlower = MRStateobj.m_hAgent.m_hDataBus.ParameterData.RMinDetection;
                        RNominal = MRStateobj.m_hAgent.m_hDataBus.ParameterData.RDetection;
                        RCSlower = MRStateobj.m_hAgent.m_hDataBus.ParameterData.RCSMinDetection;
                        RCSNominal = MRStateobj.m_hAgent.m_hDataBus.ParameterData.RCSDetection;
                        Rcond = Rlower + (RNominal-Rlower)*(sig - RCSlower)/(RCSNominal-RCSlower);
                        % We now have the max detection range conditioned on
                        % the entity RCS. A detection may then be declared if
                        % the actual range is less than the max conditioned
                        % range, i.e.
                        if( R > Rlower && R < Rcond && sig > 0) % trap to ensure only realistic RCS used.
                            % If the previous condition has been satisfied, a
                            % detection is possible and an observation can be
                            % declared. Observations are stored in the
                            % m_hObservationDB property of the Radar DataBus.
                            obscount = obscount + 1;
                            % Declare an observation.
                            %
                            %  What about the bearing?
                            %  - zero error or beamwidth random?
                            %  Zero error option
                            Bearing = atan2(EntityAM{indx,jj,2}(2,1),EntityAM{indx,jj,2}(1,1));
                            SlantAngle = asin(EntityAM{indx,jj,2}(3,1)/R);
                            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB{obscount,1}.R = R;
                            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB{obscount,1}.Bearing = Bearing;
                            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB{obscount,1}.SlantAngle = SlantAngle;
                            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB{obscount,1}.ID = EntityAM{1,jj,1};
                            % Now the rates. Get range rate from Dopppler shift
                            % in the signal return. Therefore, to calculate
                            % range rate need relative velocity between
                            % platform and entity (in UpdateEntity).
                            MRStateobj.m_hAgent.m_hDataBus.m_hObservationDB{obscount,1}.Rdot = EntityAM{indx,jj,3};
                        end
                    end
                end
            end
            % Update the internal detection clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

