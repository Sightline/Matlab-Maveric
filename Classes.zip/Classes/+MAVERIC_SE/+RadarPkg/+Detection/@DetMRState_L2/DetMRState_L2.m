classdef DetMRState_L2 < MAVERIC_SE.MultiResObject.MRState 
    %DetMRState_L2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Detection MRFSM
        m_LocalTime             % Detection object local time
        m_LocalTimeStep         % Detection object sample time
        m_NextTime              % next time Detection object should fire
    end
    
    properties
        m_Detection
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = DetMRState_L2(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
            MRStateobj = Enter(MRStateobj);
        end
        
        function MRStateobj = Enter(MRStateobj)
            MRStateobj.m_Detection = [];
        end
        
        function MRStateobj = Execute(MRStateobj)
            R2T = MRStateobj.m_hSensorOwner.m_hRangeIndex;
            host = MRStateobj.m_hSensorOwner.m_hHostPlatform;
            if(host.m_hDataBus.L1RadarDynFlag == 1)
                    obj.m_hSensorOwner.m_DetectionFlag = 'm';
            end
            obscount = 0;
            host.m_hDataBus.m_hObservationDB = [];
            if(~isempty(R2T)) % Test if there are any potential targets 
                              % within range the nominal detection range
                for agi = 1:length(R2T)
                    if(~isempty(R2T{agi}))
                    % The first step is to get the handle to the target
                    % agent from the blackboard
                    hagt = obj.m_hSensorOwner.m_hHostPlatform.m_hBB...
                        .GetAgent(R2T{agi});
                    sig = hagt.m_hDataBus.m_RCS;
                    % Calculate the true range between the current agent
                    % and the target agent.
                    R = sqrt((hagt.m_hDataBus.x(1,1)...
                        - host.m_hDataBus.x(1,1))^2 +...
                        (hagt.m_hDataBus.x(2,1)...
                        - host.m_hDataBus.x(2,1))^2);
                    % get the bearing angle (relative)
                    ang = atan2((hagt.m_hDataBus.x(2,1)...
                        - host.m_hDataBus.x(2,1)),...
                        (hagt.m_hDataBus.x(1,1)...
                        - host.m_hDataBus.x(1,1)));
                    %
                    % Now, this is the detection logic for a L1 radar.
                    % Assume that the nominal detection range for a 100m2
                    % RCS target is 50km. Further assume that the minimum
                    % RCS is 1m2 at 10km. Then, the actual detection range
                    % conditioned on the RCS of the target is
                    Rlower = 10000; Rupper = 50000; RCSlower = 1; RCSupper = 100;
                    Rcond = Rlower + (Rupper-Rlower)*(sig - RCSlower)/(RCSupper-RCSlower);
                    %
                    if(host.m_hDataBus.L1RadarDynFlag == 1)
                        if(R < Rcond && sig > 0 )
                            % If the actual range is less than the conditioned
                            % range, declare a detection.
                            obj.m_Detection = [obj.m_Detection 1];
                            obj.m_hSensorOwner.m_DetectionFlag = 'y';
                            obscount = obscount + 1;
                            % Declare an observation.
                            host.m_hDataBus.m_hObservationDB{1,obscount}.R = R;
                            host.m_hDataBus.m_hObservationDB{1,obscount}.Rcond = Rcond;
                            host.m_hDataBus.m_hObservationDB{1,obscount}.ang = ang; 
                            host.m_hDataBus.m_hObservationDB{1,obscount}.ID = R2T{agi};
                            disp('***********************');
                            fprintf('Observation declared at %4.1f mins\n',host.m_hDataBus.m_LocalTime/60);
                            fprintf('Target Location of agent %s\n',R2T{agi});
                            [xr,yr] = pol2cart(ang,R);
                            xh = host.m_hDataBus.x(1,1);
                            yh = host.m_hDataBus.x(2,1);
                            var = sprintf('%4.1f(km) North, %4.1f(km) East',...
                                (xr+xh)/1000,(yr+yh)/1000);
                            disp(var);
                            disp(' ');
                        else
                            obj.m_Detection = [obj.m_Detection 0];
                        end
                    end
                    end
                end
            end
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

