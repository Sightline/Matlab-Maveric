classdef SightMRState_L1 < MAVERIC_SE.MultiResObject.MRState 
    %SightMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Sightline MRFSM
        m_LocalTime             % Sightline object local time
        m_LocalTimeStep         % Sightline object sample time
        m_NextTime              % next time Sightline object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = SightMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
            MRStateobj = Enter(MRStateobj);
        end
        
        function MRStateobj = Enter(MRStateobj)
            
        end
        
        function MRStateobj = Execute(MRStateobj)
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

