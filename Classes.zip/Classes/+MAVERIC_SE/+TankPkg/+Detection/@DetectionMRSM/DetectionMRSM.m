classdef DetectionMRSM < MAVERIC_SE.MultiResObject.MRStateMachine
    %DYNAMICS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hCurrentMRState
        m_hPreviousMRState
        m_hGlobalMRState
    end
    
    methods
        function MRFSMobj = DetectionMRSM(hAgent)
            import MAVERIC_SE.TankPkg.Detection.*
            MRFSMobj.m_hAgent = hAgent;
            MRFSMobj.m_hCurrentMRState = DetMRState_L1(hAgent,MRFSMobj);
            MRFSMobj.m_hPreviousMRState = 0;
            MRFSMobj.m_hGlobalMRState = 0;
        end
        
        function obj = SetCurrentMRState(obj,hCurrentMRState)
            obj.m_hCurrentMRState = hCurrentMRState;
        end
        
        function obj = ChangeMRState(obj,hNextMRState)
            obj.m_hCurrentMRState = hNextMRState;
        end
    end
    
end

