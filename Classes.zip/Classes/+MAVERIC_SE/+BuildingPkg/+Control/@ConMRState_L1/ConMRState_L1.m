classdef ConMRState_L1 < MAVERIC_SE.MultiResObject.MRState 
    %DynMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Control MRFSM
        m_LocalTime             % Control object local time
        m_LocalTimeStep         % Control object sample time
        m_NextTime              % next time Control object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = ConMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
            MRStateobj = Enter(MRStateobj);
        end
        
        function MRStateobj = Enter(MRStateobj)
        end
        
        function MRStateobj = Execute(MRStateobj)
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

