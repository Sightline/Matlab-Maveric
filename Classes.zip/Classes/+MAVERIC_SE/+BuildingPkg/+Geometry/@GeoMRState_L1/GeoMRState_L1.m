classdef GeoMRState_L1 < MAVERIC_SE.MultiResObject.MRState 
    %GEOMRState_L1 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Geometry MRFSM
        m_LocalTime             % Geometry object local time
        m_LocalTimeStep         % Geometry object sample time
        m_NextTime              % next time Geometry object should fire
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = GeoMRState_L1(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_GeometryResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_GeometryMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        function MRStateobj = Execute(MRStateobj)
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
end

