classdef GuidMRState_L2 < MAVERIC_SE.MultiResObject.MRState
    %GuidMRState_L2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent                % Handle to the Agent object
        m_hMRFSM                % Handle to the Guidance MRFSM
        m_LocalTime             % Guidance object local time
        m_LocalTimeStep         % Guidance object sample time
        m_NextTime              % Next time Guidance object should fire
        m_LocalVariables        % Variables local to the guidance state
    end
    
    methods
        % This block of methods satisfies the MRState interface.
        function MRStateobj = GuidMRState_L2(hAgent,hMRFSM)
            MRStateobj.m_hAgent = hAgent;
            MRStateobj.m_hMRFSM = hMRFSM;
        end
        
        function MRStateobj = Enter(MRStateobj)
            % Set the module resolution
            MRStateobj.m_hAgent.m_hDataBus.m_GuidanceResolution = 1;
            % Align the local time with the global simulation time. First,
            % get the global time from the simulation object
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            MRStateobj.m_LocalTimeStep = MRStateobj.m_hAgent.m_hDataBus...
                .m_GuidanceMRStatesTimeSteps(1);
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
            MRStateobj.m_LocalVariables.prevHeading = 0;
        end
        
        function MRStateobj = Execute(MRStateobj)
            % The guidance module has two types of response - waypoint and
            % mission task element. The responsibility of the AI module is
            % to select the appropriate guidance strategy for a particular
            % AI state. This is contained within the m_Guidance State
            % variable on the DataBus
            guidstate = MRStateobj.m_hAgent.m_hDataBus.m_GuidanceState;
            switch guidstate
                case 'Waypoint'
                    MRStateobj = MRStateobj.WaypointGuidance();
                case 'MTE'
                    MRStateobj = MRStateobj.MTEGuidance();    
            end
        end
        
        function MRStateobj = Exit(MRStateobj)
        end
    end
    
    methods
        function MRStateobj = WaypointGuidance(MRStateobj)
            theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
            MRStateobj.m_LocalTime = theSIM.m_hScene.m_hBB.m_GlobalTime;
            % Get the current state (L1)
            [xe,ye,ze,~,psi,gamma] = MRStateobj.m_hAgent.m_hDataBus.getDynStates(1);
            % Get the current waypoints
            xw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            zw = MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw;
            if(isnan(xw))
                % Store the commanded rates to the control vector
                Vfc = MRStateobj.m_hAgent.m_hDataBus.Vc;
                MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;0;0],1);
                % Update the internal guidance clock
                MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                    MRStateobj.m_LocalTimeStep;
                return;
            end
            % Now calculate the heading error
            psiwp = atan2((yw-ye),(xw-xe));
            if(psiwp < 0)
                psiwp2 = psiwp + 2*pi;
            else
                psiwp2 = psiwp;
            end
            psierr1 = psiwp - psi;
            psierr2 = psiwp2 - psi;
            errv = [psierr1 psierr2];
            [psierr,index] = min(abs(errv));
            psierr = psierr * sign(errv(index));
            % Select the appropriate guidance loop gain
            if(MRStateobj.m_hAgent.m_hDataBus.DynResolution == 1)
                m_Kp = 0.5;
            else
                m_Kp = 0.5;
            end
            psid_dem = m_Kp*psierr;
            psid_max = 20;
            if(psid_dem > (psid_max*pi/180)) 
                psid_dem = (psid_max*pi/180); 
            end
            if(psid_dem < -(psid_max*pi/180)) 
                psid_dem = -(psid_max*pi/180); 
            end
            %
            % Now the climb angle gamma
            gamwp = atan2(-(zw-ze),sqrt((xw-xe)^2+(yw-ye)^2));
            gamerr = gamwp - gamma;
            gamd_dem = m_Kp*gamerr;
            gamd_max = 20;
            if(gamd_dem > (gamd_max*pi/180)) 
                gamd_dem = (gamd_max*pi/180); 
            end
            if(gamd_dem < -(gamd_max*pi/180)) 
                gamd_dem = -(gamd_max*pi/180); 
            end
            %
            % Store the commanded rates to the control vector
            Vfc = MRStateobj.m_hAgent.m_hDataBus.Vc;
            MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;psid_dem;gamd_dem],1);
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
        
        
        function MRStateobj  = MTEGuidance(MRStateobj)
            % Store the commanded rates to the control vector
            Vfc = MRStateobj.m_hAgent.m_hDataBus.Vc;
            MRStateobj.m_hAgent.m_hDataBus.setControls([Vfc;0;0],1);
            % Update the internal guidance clock
            MRStateobj.m_NextTime = MRStateobj.m_LocalTime + ...
                MRStateobj.m_LocalTimeStep;
        end
    end
    
end

