function obj = CalcDerivatives(obj)
%****************************************************************
% Date: 30/09/2013
% Author: D.Anderson
% Description: The airframe dynamics model will have the standard 12-state,
% 6-DoF state vector and will calculate dynamic response in all 6DoF. 
%****************************************************************
%
% -------------------------------------------------------
% Modification May 2014:    Two major modifications were made to the code
%                           at this revision. First, terms for body
%                           aerodynamics were added to the calculations.
%                           Second, the equations of motion have been
%                           altered to accomodate quaternion calculations
%                           in the missile attitude equations.
%
% Author: Dave Anderson
%
% ------------------------------------------------------
%
%% Define constants
%-------------------------------------------------------------------------
%  Note: The definition of these constants may be better moved to a tab
%  within the main GUI, to enable easier changes to be made to the
%  aerodynamic and inertial properties of the missile.
%-------------------------------------------------------------------------
%
rho = 1.225;        % air density (kg/m^3)
S = 0.2;            % Wetted area (total guess)
Sc = 0.15;          % Wetted area for canards (another total guess)
m = 225;            % mass (kg)
g = 9.81;           % gravitational acceleration (m/s^2)
Lm = 3.1;           % Missile length (m)
r = 0.21;           % Missile cross-sectional radius
Sb = pi*r^2;
Iyy = (m/2)*(3*r^2+Lm^2);         % Pitch axis inertia (kg-m^2);
Ixx = (m*r^2)/2;                  % Roll axis inertia (kg-m^2);
Izz = (m/2)*(3*r^2+Lm^2);         % Yaw axis inertia (kg-m^2);
lw = -1.3;          % wing assembly cp position (x-axis)
ow = 0.5;           % wing assembly cp position offset
lc = 0.9;           % canard assembly cp position (x-axis)
oc = 0.45;          % canard assembly cp position offset
angmax = 20;        % maximum aerodynamic angle (stall)
d2r = pi/180;
% Set an alias for the databus
hDataBus = obj.m_hAgent.m_hDataBus;
%% Extract the control and state vectors
% First the state vector
[u,v,w,p,q,r,phi,theta,psi,~,~,~,q0,q1,q2,q3,uc1,uc2,uc3,uc4] = hDataBus.getDynStates(2);
% now the control vector
u_c = hDataBus.getControlVec(2);
del_c = [uc1;uc2;uc3;uc4];
% 
% -------------------------------------
% Modification 18/5/14
% Addition of a thrust control term. The thrust has been added as a
% seperate term in the databus rather than augmenting the control vector to
% limit the changes necessary to implement this into the code.
Thrust = hDataBus.Thrust;
%
% -------------------------------------
%
%
%% Equations of Motion
% The equations of motion are simple rigid-body models. There are two 
% aerodynamic lifting surface groups - the rear wing and the forward 
% canards for steering. A fuselage model is also included for completeness
% but is deactivated at this time as the errors in guessing the fuselage
% aerodynamics would remove any benefit to their inclusion. However, if
% accurate missile data is available, then they can be included.
%
%% Fuselage Aerodynamic Force
uv = [u,v,w]';
Vf2 = uv'*uv;                    % local velocity
ang1 = atan2(uv(3,1),uv(1,1));   % body angle of attack
if(abs(ang1)>angmax*d2r)
    ang1 = angmax*d2r*sign(ang1);
end
ang2 = asin(uv(2,1)/Vf2);   % sideslip angle
if(abs(ang2)>angmax*d2r)
    ang2 = angmax*d2r*sign(ang2);
end
CL0 = 0.0; CLa = 2.5; CD0 = 0.01; CDa = 8; CS0 = 0.0; CSa = 2.5; 
CL = CL0 + CLa*ang1; L = 0.5*rho*Vf2*Sb*CL;
CD = CD0 + CDa*ang1; D = 0.5*rho*Vf2*Sb*CD;
CS = CS0 + CSa*ang2; Sf = 0.5*rho*Vf2*Sb*CS;
% Resolve forces into body axes
Fb(1,1) = Sf*cos(ang1)*sin(ang2) + L*sin(ang1) - D*cos(ang1)*cos(ang2);
Fb(1,2) = -D*sin(ang2) - Sf*cos(ang2);
Fb(1,3) = D*sin(ang1)*sin(ang2) - Sf*sin(ang1)*sin(ang2) - L*cos(ang1);
%
%% Fin aerodynamic forces
% -----------------Fin 1-------------------------------
rw = [lw,0,-ow]';           % position of the fin in body axes
om = [p,q,r]';              % missile angular rates
uv = [u,v,w]';              % missile translational velocities (body axes)
uwb = uv+cross(om,rw);       % local velocity at fin in body axes
phiw = 90*d2r;              % orientation of fin wrt body axes
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uw = C*uwb;                  % velocity vector is now in lifting surface axes.
Vf2 = uw'*uw;               % local velocity
ang = atan2(uw(3,1),uw(1,1));   % incidence angle to fin 1 (vertical surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang); % limit aerodynamic angle to angmax degrees
end
% Aerodynamic coefficients. It should be noted that these coefficients are
% guesses for the AASM system as no data is available in the public domain.
% They are the steady lift and drag coefficients and the angle of attack
% derivatives.
CL0 = 0.0; CLa = 3; CD0 = 0.005; CDa = 0.03; 
% Now calculate the aerodynamic forces...
CL = CL0 + CLa*ang; L = 0.5*rho*Vf2*S*CL;
CD = CD0 + CDa*ang; D = 0.5*rho*Vf2*S*CD;
% Resolve forces into lifting surface axes
Fwl(1,1) = L*sin(ang)-D*cos(ang);
Fwl(1,2) = 0;
Fwl(1,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fwl(1,:)';
Fw(1,:) = tmp';
% ...and finally calculate the moments
Tw(1,:) = cross(rw,Fw(1,:)); 
% -----------------Fin 2-------------------------------
% See previous section for comments
rw = [lw,ow,0]';
om = [p,q,r]';
uv = [u,v,w]';
uw = uv+cross(om,rw);       % local velocity in body axes
phiw = 180*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uw = C*uw;                  % velocity vector is now in lifting surface axes.
Vf2 = uw'*uw;
ang = atan2(uw(3,1),uw(1,1));   % incidence angle to fin 2 (horizontal surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL = CL0 + CLa*ang; L = 0.5*rho*Vf2*S*CL;
CD = CD0 + CDa*ang; D = 0.5*rho*Vf2*S*CD;
% Resolve forces into lifting surface axes
Fw(2,1) = L*sin(ang)-D*cos(ang);
Fw(2,2) = 0;
Fw(2,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fw(2,:)';
Fw(2,:) = tmp';
% ...and finally calculate the moments
Tw(2,:) = cross(rw,Fw(2,:)); 
% -----------------Fin 3-------------------------------
% See first section for comments
rw = [lw,0,ow]';
om = [p,q,r]';
uv = [u,v,w]';
uw = uv+cross(om,rw);       % local velocity in body axes
phiw = 270*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uw = C*uw;                  % velocity vector is now in lifting surface axes.
Vf2 = uw'*uw;
ang = atan2(uw(3,1),uw(1,1));   % incidence angle to Fin 3 (vertical surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL = CL0 + CLa*ang; L = 0.5*rho*Vf2*S*CL;
CD = CD0 + CDa*ang; D = 0.5*rho*Vf2*S*CD;
% Resolve forces into lifting surface axes
Fw(3,1) = L*sin(ang)-D*cos(ang);
Fw(3,2) = 0;
Fw(3,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fw(3,:)';
Fw(3,:) = tmp';
% ...and finally calculate the moments
Tw(3,:) = cross(rw,Fw(3,:)); 
% -----------------Fin 4-------------------------------
% See previous section for comments
rw = [lw,-ow,0]';
om = [p,q,r]';
uv = [u,v,w]';
uw = uv+cross(om,rw);       % local velocity in body axes
phiw = 0*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uw = C*uw;                  % velocity vector is now in lifting surface axes.
Vf2 = uw'*uw;
ang = atan2(uw(3,1),uw(1,1));   % incidence angle to fin 4 (horizontal surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL = CL0 + CLa*ang; L = 0.5*rho*Vf2*S*CL;
CD = CD0 + CDa*ang; D = 0.5*rho*Vf2*S*CD;
% Resolve forces into lifting surface axes
Fw(4,1) = L*sin(ang)-D*cos(ang);
Fw(4,2) = 0;
Fw(4,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fw(4,:)';
Fw(4,:) = tmp';
% ...and finally calculate the moments
Tw(4,:) = cross(rw,Fw(4,:)); 
%
% Canard aerodynamics forces
% -----------------Canard 1-------------------------------
rw = [lc,0,-oc]';
om = [p,q,r]';
uv = [u,v,w]';
uc = uv+cross(om,rw);       % local velocity in body axes
phiw = 90*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uc = C*uc;                  % velocity vector is now in lifting surface axes.
Vf2 = uc'*uc;
ang = atan2(uc(3,1),uc(1,1));
ang_c=ang+del_c(1,1);   % incidence angle to canard 1 (vertical surface).
                        % Note the aerodynamic angle now includes control
                        % deflection as well as aerodynamic flowfield.
if(abs(ang_c)>angmax*d2r)
    ang_c = angmax*d2r*sign(ang);
end
CL0 = 0.0; CLa = 4; CL_delc = 0; CD0 = 0.005; CDa = 0.04;
CL = CL0 + CLa*ang_c + CL_delc*del_c(1); L = 0.5*rho*Vf2*Sc*CL;
CD = CD0 + CDa*ang_c; D = 0.5*rho*Vf2*Sc*CD;
% Resolve forces into lifting surface axes
Fc(1,1) = L*sin(ang)-D*cos(ang);
Fc(1,2) = 0;
Fc(1,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fc(1,:)';
Fc(1,:) = tmp';
% ...and finally calculate the moments
Tc(1,:) = cross(rw,Fc(1,:)); 
% -----------------Canard 2-------------------------------
rw = [lc,oc,0]';
om = [p,q,r]';
uv = [u,v,w]';
uc = uv+cross(om,rw);       % local velocity in body axes
phiw = 180*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uc = C*uc;                  % velocity vector is now in lifting surface axes.
Vf2 = uc'*uc;
ang = atan2(uc(3,1),uc(1,1));
ang_c=ang+del_c(2,1);   % incidence angle to canard 1 (vertical surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL0 = 0.0; CLa = 3; CL_delc = 0; CD0 = 0.05; CDa = 0.5;
CL = CL0 + CLa*ang_c + CL_delc*del_c(1); L = 0.5*rho*Vf2*Sc*CL;
CD = CD0 + CDa*ang_c; D = 0.5*rho*Vf2*Sc*CD;
% Resolve forces into lifting surface axes
Fc(2,1) = L*sin(ang)-D*cos(ang);
Fc(2,2) = 0;
Fc(2,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fc(2,:)';
Fc(2,:) = tmp';
% ...and finally calculate the moments
Tc(2,:) = cross(rw,Fc(2,:));
% -----------------Canard 3-------------------------------
rw = [lc,0,oc]';
om = [p,q,r]';
uv = [u,v,w]';
uc = uv+cross(om,rw);       % local velocity in body axes
phiw = 270*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uc = C*uc;                  % velocity vector is now in lifting surface axes.
Vf2 = uc'*uc;
ang = atan2(uc(3,1),uc(1,1));
ang_c=ang+del_c(3,1);   % incidence angle to canard 1 (vertical surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL = CL0 + CLa*ang_c + CL_delc*del_c(3); L = 0.5*rho*Vf2*Sc*CL;
CD = CD0 + CDa*ang_c; D = 0.5*rho*Vf2*Sc*CD;
% Resolve forces into lifting surface axes
Fc(3,1) = L*sin(ang)-D*cos(ang);
Fc(3,2) = 0;
Fc(3,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fc(3,:)';
Fc(3,:) = tmp';
% ...and finally calculate the moments
Tc(3,:) = cross(rw,Fc(3,:));
% -----------------Canard 4-------------------------------
rw = [lc,-oc,0]';
om = [p,q,r]';
uv = [u,v,w]';
uc = uv+cross(om,rw);       % local velocity in body axes
phiw = 0*d2r;
C = [1 0 0;0 cos(phiw) sin(phiw);0 -sin(phiw) cos(phiw)];
uc = C*uc;                  % velocity vector is now in lifting surface axes.
Vf2 = uc'*uc;
ang = atan2(uc(3,1),uc(1,1));
ang_c=ang+del_c(4,1);   % incidence angle to canard 1 (vertical surface)
if(abs(ang)>angmax*d2r)
    ang = angmax*d2r*sign(ang);
end
CL = CL0 + CLa*ang_c + CL_delc*del_c(4); L = 0.5*rho*Vf2*Sc*CL;
CD = CD0 + CDa*ang_c; D = 0.5*rho*Vf2*Sc*CD;
% Resolve forces into lifting surface axes
Fc(4,1) = L*sin(ang)-D*cos(ang);
Fc(4,2) = 0;
Fc(4,3) = -L*cos(ang)-D*sin(ang);
% then back into body axes
tmp = C'*Fc(4,:)';
Fc(4,:) = tmp';
% ...and finally calculate the moments
Tc(4,:) = cross(rw,Fc(4,:));
%% Rigid-Body Equations of Motion
% Direction cosines...
C_tht = [cos(theta) 0 -sin(theta);0 1 0;sin(theta) 0 cos(theta)];
C_psi = [cos(psi) sin(psi) 0;-sin(psi) cos(psi) 0; 0 0 1];
C_phi = [1 0 0;0 cos(phi) sin(phi);0 -sin(phi) cos(phi)];
% Giving the Euler matrix,...
C_E2B = C_phi*C_tht*C_psi;
hDataBus.TransformationMatrices.C_E2B = C_E2B;
nv = C_E2B'*[u;v;w];        % navigation vector (xed,yed,zed)
gv = C_E2B*[0;0;m*g];       % gravity vector in body axes
FwT = sum(Fw,1); FcT = sum(Fc,1);   % Total forces - fin & canard
TwT = sum(Tw,1); TcT = sum(Tc,1);   % Total moments - fin & canard
% Body axes translational accelerations (X,Y,Z)
%
% -----------------------------
% Modification 18/5/14
% Thrust term added to udot.
%
hDataBus.DynStateDot.u = v*r-q*w +(Fb(1,1)+FwT(1,1)+FcT(1,1)+gv(1,1)+Thrust)/m;
%
% ----------------------------
%
hDataBus.DynStateDot.v = p*w-u*r +(Fb(1,2)+FwT(1,2)+FcT(1,2)+gv(2,1))/m;
hDataBus.DynStateDot.w = q*u-v*p +(Fb(1,3)+FwT(1,3)+FcT(1,3)+gv(3,1))/m;
% Body axes rotational accelerations (X,Y,Z)
hDataBus.DynStateDot.p = ((Iyy-Izz)*q*r + TwT(1,1) + TcT(1,1))/Ixx;
hDataBus.DynStateDot.q = ((Izz-Ixx)*p*r + TwT(1,2) + TcT(1,2))/Iyy;
hDataBus.DynStateDot.r = ((Ixx-Iyy)*q*p + TwT(1,3) + TcT(1,3))/Izz;
% Euler angle rates
% As the quaternion will be integrated, no need to calculate the Euler
% angle rates explicitly.
hDataBus.DynStateDot.phi = 0;
hDataBus.DynStateDot.theta = 0;
hDataBus.DynStateDot.psi = 0;
% Quaternion 
hDataBus.DynStateDot.q0 = -0.5*(p*q1 + q*q2 + r*q3);
hDataBus.DynStateDot.q1 = 0.5*(p*q0 +r*q2 - q*q3);
hDataBus.DynStateDot.q2 = 0.5*(q*q0 -r*q1 +p*q3);
hDataBus.DynStateDot.q3 = 0.5*(r*q0 +q*q1 -p*q2);
% True missile position (NED coordiantes)
hDataBus.DynStateDot.xe = nv(1,1);
hDataBus.DynStateDot.ye = nv(2,1);
hDataBus.DynStateDot.ze = nv(3,1);
% Canard actuator dynamics
can_tau = 100;
hDataBus.DynStateDot.uc1 = can_tau*(u_c(1,1) - hDataBus.DynStates.uc1);
hDataBus.DynStateDot.uc2 = can_tau*(u_c(2,1) - hDataBus.DynStates.uc2);
hDataBus.DynStateDot.uc3 = can_tau*(u_c(3,1) - hDataBus.DynStates.uc3);
hDataBus.DynStateDot.uc4 = can_tau*(u_c(4,1) - hDataBus.DynStates.uc4);
% Derivative of the local time variable
hDataBus.DynStateDot.t = 1;
%% Heirarchy States
% It is imperitive that all higher-level state vectors contain the state
% vectors of lower resolution models as a subset of them. Recall L1 alos
% contains airspeed (Vf) and flight path angle (gamma). These should be
% included.
% Missile speed
hDataBus.DynStates.Vf = [u,v,w]*[u,v,w]';
% Flight path angle
hDataBus.DynStates.gamma = atan2(hDataBus.DynStateDot.ze,hDataBus.DynStateDot.xe);
% Finally, update the databus with the changes made to the alias...
obj.m_hAgent.m_hDataBus = hDataBus;
end

