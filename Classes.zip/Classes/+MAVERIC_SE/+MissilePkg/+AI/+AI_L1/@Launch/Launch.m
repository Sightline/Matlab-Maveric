classdef Launch < handle
    %Launch Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function AIStateobj = Launch(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
        end
        
        function AIStateobj = Enter(AIStateobj)
            % Do initialisation stuff
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Launch';
            % Change the timestep of the L1 missile agent
            AIStateobj.m_hAgent.m_hDataBus.m_AIMRStatesTimeSteps(1) = 0.01;
            AIStateobj.m_hAgent.m_hDataBus.m_DynamicMRStatesTimeSteps(1) = 0.01;
            AIStateobj.m_hAgent.m_hDataBus.m_GuidanceMRStatesTimeSteps(1) = 0.01;
            AIStateobj.m_hAgent.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_DetectionMRStatesTimeSteps(1) = 0.01;
            AIStateobj.m_hAgent.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_TrackingMRStatesTimeSteps(1) = 0.01;
            % Now call the enter functions on each current MRState
            AIStateobj.m_hAgent.m_hDataBus.m_hCurrentDynMRState.Enter();
            AIStateobj.m_hAgent.m_hDataBus.m_hCurrentGuidanceMRState.Enter();
            % and activate the sensors
            AIStateobj.m_hAgent.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_SimStatus = 'Active';
            AIStateobj.m_hAgent.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_hCurrentDetectionMRState.Enter();
            AIStateobj.m_hAgent.m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_hCurrentTrackingMRState.Enter();
        end
        
        function AIStateobj = Execute(AIStateobj)
            % Should be a seperate mode to clear the aircraft. Just
            % transition to cruise in L1.
            
            % First, update the weapons store on the host platform.
            
            
            
            
            import MAVERIC_SE.MissilePkg.AI.AI_L1.*
            AIStateobj.m_hAIFSM.ChangeState...
                        (Cruise(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
        end
        
        function Exit(AIStateobj)
            % Clean-up the AI state
            delete(AIStateobj);
        end
     
    end
    
end

