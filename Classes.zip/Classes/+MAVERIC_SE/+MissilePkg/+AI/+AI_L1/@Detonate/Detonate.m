classdef Detonate < handle
    %Detonate Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function AIStateobj = Detonate(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
        end
        
        function AIStateobj = Enter(AIStateobj)
            % In the detonation state, the kill probabilities are applied
            % to the target and the missile simulation state changed.
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Detonate';
            AIStateobj.m_hAgent.m_hDataBus.m_SimStatus = 'Destroyed';
            
            % In here put a damage assessment code segment. For now, assume
            % missile success.
            AIStateobj.m_hAgent.m_hDataBus.m_hTarget.m_hDataBus.m_SimStatus = 'Destroyed';
            
            
            % Change the timestep
            AIStateobj.m_hAgent.m_hDataBus.m_AIResolution = 2;
            
            
            Exit(AIStateobj);
        end
        
        function AIStateobj = Execute(AIStateobj)
            % Do execute stuff
        end
        
        function Exit(AIStateobj)
            % Clean-up the AI state
            delete(AIStateobj);
        end
     
    end
    
end

