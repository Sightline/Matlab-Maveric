classdef Cruise < handle
    %Cruise Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function AIStateobj = Cruise(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
        end
        
        function AIStateobj = Enter(AIStateobj)
            % Do initialisation stuff
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Cruise';
        end
        
        function AIStateobj = Execute(AIStateobj)
            % Update the target queue
            import MAVERIC_SE.MissilePkg.AI.AI_L1.*
            AIStateobj.m_hAIFSM.m_hTargetDB.UpdateQueue(AIStateobj.m_hAgent...
                .m_hDataBus.m_hChildren.EOSystem.m_hDataBus.m_hTrackDB);
            % Update the target position
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.zpos;
            % Calculate the distance to current target
            d = Distance2Target(AIStateobj);
            if(d < 500)
                % Update the threat model to match missile
                AIStateobj.m_hAgent.m_hDataBus.m_hTarget.m_hDataBus.m_AIMRStatesTimeSteps(1) = 0.01;
                AIStateobj.m_hAgent.m_hDataBus.m_hTarget.m_hDataBus.m_DynamicMRStatesTimeSteps(1) = 0.01;
                AIStateobj.m_hAgent.m_hDataBus.m_hTarget.m_hDataBus.m_GuidanceMRStatesTimeSteps(1) = 0.01;
                %            
                % If range rate starts increasing, detonate.
                % Identify the appropriate row in the EntityAM (indx).
                ne = AIStateobj.m_hAgent.m_hBB.m_NumEntities;
                EntityAM = AIStateobj.m_hAgent.m_hBB.m_EntityAM;
                r = ne+1; indx = 0;
                for ii = 2:r
                    if(strcmp(EntityAM{ii,1,1},AIStateobj.m_hAgent.m_hDataBus.m_AgID))
                        indx = ii;
                    end
                    if(strcmp(EntityAM{ii,1,1},AIStateobj.m_hAgent.m_hDataBus.m_hTarget.m_hDataBus.m_AgID))
                        tarindx = ii;
                    end
                end
                Rdot = EntityAM{indx,tarindx,3};
                if(Rdot > 0)
                    AIStateobj.m_hAIFSM.ChangeState...
                        (Detonate(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                end
                %            
            end
        end
        
        function Exit(AIStateobj)
            % Clean-up the AI state
            delete(AIStateobj);
        end
        
        function dist = Distance2Target(AIStateobj)
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.xpos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.ypos;
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = AIStateobj.m_hAIFSM.m_hTargetDB.m_TargetQueue{1,1}.zpos;
            % Test whether we have reached the current waypoint.
            [xh,yh,zh,~,~,~] = AIStateobj.m_hAgent.m_hDataBus.GetPose(1);
            xw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            zw = AIStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw;
            dist = sqrt((xw-xh)^2+(yw-yh)^2+(zw-zh)^2);
        end
     
    end
    
end

