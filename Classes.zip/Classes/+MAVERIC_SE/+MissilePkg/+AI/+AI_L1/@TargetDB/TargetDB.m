classdef TargetDB < handle
%
properties
	m_TargetQueue
	m_TargetsIdentified
	m_TargetsClassified
	m_ThreatsDeclared
	m_ThreatsDestroyed
	m_NumTargetsQueue
	m_NumIdentified
    m_NumThreats
    m_NumDestroyed
end

methods
	function this = TargetDB()
	% initialise the lists
	this.m_TargetQueue = [];
	this.m_TargetsIdentified = [];
	this.m_TargetsClassified = [];
	this.m_ThreatsDeclared = [];
	this.m_ThreatsDestroyed = [];
	this.m_NumTargetsQueue = 0;
	this.m_NumIdentified = 0;
    this.m_NumThreats = 0;
    this.m_NumDestroyed = 0;
	end
	
	UpdateQueue(this,trackDB)
	
	function ClassifyTarget(this,Ag)
	% Classify the target
	end
	
	function IdentifyTarget(this,Ag)
	% Perform the database cleanup if the target has been identified.
	% First, add the agent (entity?) to the m_TargetsIdentified list.
    this.m_TargetsIdentified{this.m_NumIdentified+1,1} = Ag;
    this.m_NumIdentified = this.m_NumIdentified + 1;
    % Next, store the time of identification
    theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
    timeofID = theSIM.m_hScene.m_hBB.m_GlobalTime;
    this.m_TargetsIdentified{this.m_NumIdentified,2} = timeofID;
    % Finally, remove the target from the TargetQueue.
    tmp = this.m_TargetQueue;
    this.m_TargetQueue = [];
    if(this.m_NumTargetsQueue > 1)
        for ii = 1:this.m_NumTargetsQueue-1
            this.m_TargetQueue{ii,1} = tmp{ii+1,1};
        end
    end
    this.m_NumTargetsQueue = this.m_NumTargetsQueue - 1;
	end
	
	function DeclareThreat(this,Ag)
	% Declare this agent as a threat
	end
	
	function ThreatDestroyed(this,Ag)
	% Destroy this threat
    % Perform the database cleanup if the target has been identified.
	% First, add the agent (entity?) to the m_TargetsIdentified list.
    this.m_ThreatsDestroyed{this.m_NumDestroyed+1,1} = Ag;
    this.m_NumDestroyed = this.m_NumDestroyed + 1;
    % Next, store the time of identification
    theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
    timeofDestroy = theSIM.m_hScene.m_hBB.m_GlobalTime;
    this.m_TargetsIdentified{this.m_NumIdentified,2} = timeofDestroy;
    % Finally, remove the target from the TargetQueue.
    tmp = this.m_TargetQueue;
    this.m_TargetQueue = [];
    if(this.m_NumTargetsQueue > 1)
        for ii = 1:this.m_NumTargetsQueue-1
            this.m_TargetQueue{ii,1} = tmp{ii+1,1};
        end
    end
    this.m_NumTargetsQueue = this.m_NumTargetsQueue - 1;
	end
end

end