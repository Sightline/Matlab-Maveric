classdef Armed < handle
    % Armed - A Missile AI state where round is still attached to the
    % launch platform
    %   Detailed explanation goes here
    
    properties
        m_hAgent        % Handle to the missile agent object
        m_hAIFSM        % handle to the AI FSM
    end
    
    methods
        function AIStateobj = Armed(hAgent,hFSM)
            AIStateobj.m_hAgent = hAgent;
            AIStateobj.m_hAIFSM = hFSM;
            AIStateobj = AIStateobj.Enter();
        end
        
        function AIStateobj = Enter(AIStateobj)
            % In here, want to ensure that all the missile parameters are
            % correct i.e. links to platform etc.
            AIStateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Armed';
            AIStateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
        end
        
        function AIStateobj = Execute(AIStateobj)
            % This method can only be called after the launch command has
            % been given. Ordinarily,pre-launch commands would be performed
            % here, but as this is a simple AI model at this point transfer
            % to the launch state.
            % To prevent any problematic timing issues from occuring, set
            % the waypoint commands to NaN.
            MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = NaN;
            MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = NaN;
            MRStateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = NaN;
            %
            % Check if the host platform has issued a launch command.
            if(AIStateobj.m_hAgent.m_hDataBus.m_LaunchCommand)
                import MAVERIC_SE.MissilePkg.AI.AI_L1.*
                AIStateobj.m_hAIFSM.ChangeState...
                    (Launch(AIStateobj.m_hAgent,AIStateobj.m_hAIFSM));
                disp('Transition to launch...');
            end
        end
        
        function Exit(AIStateobj)
            % Clean-up the AI state
            delete(AIStateobj);
        end
     
    end
    
end

