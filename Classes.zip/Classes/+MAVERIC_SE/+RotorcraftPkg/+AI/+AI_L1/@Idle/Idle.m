classdef Idle < handle
    %Idle Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Idle(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
        end
        
        function stateobj = Enter(stateobj)
            % Define the Waypoint vector and store in the agent databus.
            stateobj.m_hAgent.m_hDataBus.WPindex = 1;
            stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected = [];
            stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
            stateobj.m_hAgent.m_hDataBus.IsLanded = 'n';
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xe = r(1,1); ye = r(2,1);ze = r(3,1);
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.xe = xe;
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ye = ye;
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ze = ze;
            disp('Entered Idle mode');
            stateobj.m_hAgent.m_hDataBus.Vc = stateobj.m_hAgent...
                .m_hDataBus.ParameterData.L1Dyn.Vf_cruise;
        end
        
        function stateobj = Execute(stateobj)
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            % Dummy transition
%             if(stateobj.m_hAgent.m_hDataBus.m_hCurrentDynMRState.m_LocalTime > 1)
%                 disp('Transition to Take-Off mode triggered');
%                 import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
%                 stateobj.m_hAIFSM.ChangeState(TakeOff(stateobj.m_hAgent,stateobj.m_hAIFSM));
%             end
            
        end
        
        function Exit(stateobj)
            % Clean-up the AI state
            delete(stateobj);
        end
     
    end
    
end

