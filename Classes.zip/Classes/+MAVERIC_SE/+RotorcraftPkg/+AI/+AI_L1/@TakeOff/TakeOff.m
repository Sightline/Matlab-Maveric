classdef TakeOff < handle
    %TAKEOFF Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = TakeOff(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
%             stateobj = stateobj.Enter();
        end
        
        function stateobj = Enter(stateobj)
            % Define the Waypoint vector and store in the agent databus.
            stateobj.m_hAgent.m_hDataBus.WPindex = 1;
            stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected = [];
            stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
            stateobj.m_hAgent.m_hDataBus.m_hTargetDB = cell(4,1);
            stateobj.m_hAgent.m_hDataBus.IsLanded = 'n';
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xe = r(1,1); ye = r(2,1);ze = r(3,1);
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.xe = xe;
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ye = ye;
            stateobj.m_hAgent.m_hDataBus.m_hInitialConditions.ze = ze;
            stateobj.m_hAgent.m_hDataBus.m_CurrentAIMode = 'Take-Off';
            stateobj.m_hAgent.m_hDataBus.Vc = stateobj.m_hAgent...
                .m_hDataBus.ParameterData.L1Dyn.Vf_cruise;
            %
        end
        
        function stateobj = Execute(stateobj)
            stateobj.m_hAgent.m_hDataBus.m_GuidanceState = 'Waypoint';
            % Test whether we have reached the current waypoint.
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xh = r(1,1); yh = r(2,1);zh = r(3,1);
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            nwp = stateobj.m_hAgent.m_hDataBus.NumWayPoints;
            xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            d = sqrt((xw-xh)^2+(yw-yh)^2+(zw-zh)^2);
            if (d < 50 && wpind < nwp)
                wpind = wpind + 1;
            end
            stateobj.m_hAgent.m_hDataBus.WPindex = wpind;
            % Now, the code governing state transition to cruise/search.
            % Transition event will be when the airspeed is within 5% of
            % the desired airspeed.
            [~,~,~,Vf,~,~] = stateobj.m_hAgent.m_hDataBus.getDynStates(1);
            Vc = stateobj.m_hAgent.m_hDataBus.Vc;
            if(abs((Vc-Vf)/Vc) < 0.05)
                import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(Search(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
        end
        
        function Exit(stateobj)
            % 
            delete(stateobj);
        end
     
    end
    
end

