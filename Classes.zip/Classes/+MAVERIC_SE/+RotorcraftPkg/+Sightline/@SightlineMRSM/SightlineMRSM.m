classdef SightlineMRSM < MAVERIC_SE.MultiResObject.MRStateMachine
    %Sightline Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hCurrentMRState
        m_hPreviousMRState
        m_hGlobalMRState
    end
    
    methods
        function MRFSMobj = SightlineMRSM(hAgent)
            import MAVERIC_SE.RotorcraftPkg.Sightline.*
            MRFSMobj.m_hAgent = hAgent;
            MRFSMobj.m_hCurrentMRState = SightMRState_L1(hAgent,MRFSMobj);
            MRFSMobj.m_hPreviousMRState = 0;
            MRFSMobj.m_hGlobalMRState = 0;
        end
        
        function MRFSMobj = SetCurrentMRState(MRFSMobj,hCurrentMRState)
            MRFSMobj.m_hCurrentMRState = hCurrentMRState;
        end
        
        function MRFSMobj = ChangeMRState(MRFSMobj,hNextMRState)
            MRFSMobj.m_hCurrentMRState = hNextMRState;
        end
    end
    
end