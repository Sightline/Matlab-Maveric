classdef Evade < AgentPkg.AI.IAIState
    %EVADE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Evade(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            %
            disp('Entered evade mode....');
        end
        
        function stateobj = Execute(stateobj)
            import HeliPkg.AI.AIL1.*
                stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected{end+1} = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1};
                % Remove the current target from the list
                [~,n] = size(stateobj.m_hAgent.m_hDataBus.m_hTargetQueue);
                if(n==1)
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                end
                if(n > 1)
                    tmpq = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue;
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                    for i=2:n
                        stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{i-1} = tmpq{i};
                    end
                end
                stateobj.m_hAIFSM.ChangeState(Search(stateobj.m_hAgent,stateobj.m_hAIFSM));
            %
        end
        
        function Exit(stateobj)
            % 
%             delete(stateobj);
        end
    end
    
end

