classdef Attack < AgentPkg.AI.IAIState
    %ATTACK Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Attack(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            %
            disp('Entered attack mode....');
        end
        
        function stateobj = Execute(stateobj)
            % Calculate the distance to current target
            d = Distance2Target(stateobj);
            % Get the handle to the current target agent object
            hTarget = stateobj.m_hAgent.m_hBB.GetAgent(...
                stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ID);
            % Simulate the firefight
            UpdateFirefight(stateobj,hTarget,d);
            % Test the health of target and helicopter
            if(hTarget.m_hDataBus.m_Health < 0)
                % Designate the target as dead.
                KillTarget(stateobj);
                % Move on to the next target
                import HeliPkg.AI.AIL1.*
                stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected{end+1} = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1};
                % Remove the current target from the list
                [~,n] = size(stateobj.m_hAgent.m_hDataBus.m_hTargetQueue);
                if(n==1)
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                end
                if(n > 1)
                    tmpq = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue;
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                    for i=2:n
                        stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{i-1} = tmpq{i};
                    end
                end
                stateobj.m_hAIFSM.ChangeState(Search(stateobj.m_hAgent,stateobj.m_hAIFSM));
                return;
            end
            %
            if(stateobj.m_hAgent.m_hDataBus.m_Health < 50)
                % Too much damage - return to base
                import HeliPkg.AI.AIL1.*
                disp('Taken too much damage - returning to base...');
                stateobj.m_hAIFSM.ChangeState(ReturnToBase(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
        end
        
        function Exit(stateobj)
            %
%             delete(stateobj);
        end
        
        function dist = Distance2Target(stateobj)
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.xpos;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ypos;
            % Test whether we have reached the current waypoint.
            xh = stateobj.m_hAgent.m_hDataBus.x(1,1);
            yh = stateobj.m_hAgent.m_hDataBus.x(2,1);
            xw = stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            dist = sqrt((xw-xh)^2+(yw-yh)^2);
        end
        
        function KillTarget(obj)
            %
            target = obj.m_hAgent.m_hBB.GetAgent(...
                obj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ID);
            target.m_hDataBus.m_Health = 0;
            disp('Target eliminated...');
        end
        
        function UpdateFirefight(stateobj,hTarget,d)
            %
            hHeliDB = stateobj.m_hAgent.m_hDataBus;
            hTargetDB = hTarget.m_hDataBus;
            Ah = hHeliDB.Area;
            Ai = hTargetDB.Area;
            % Loop over each weapon in each agents arsenal
            for iw = 1:length(hHeliDB.m_hWeaponsArray)
            sig = (hHeliDB.m_hWeaponsArray{iw}.CEP/1.177)*(d/100);
            Ph = 1 - exp(-Ai/(2*pi*(sig)^2));
            hitCounter = 0;
            for iround = 1:(hHeliDB.m_hWeaponsArray{iw}.RoF...
                    *hHeliDB.m_LocalTimeStep)
                if(abs(randn(1)) < Ph)
                    hitCounter = hitCounter + 1;
                end
            end
            % Update the target health (NOTE: this needs to be the real
            % target in the blackboard, not the alias).
            hTargetDB.m_Health = hTargetDB.m_Health - hitCounter...
                * hHeliDB.m_hWeaponsArray{iw}.RoundDamage;
            stateobj.m_hAgent.m_hBB.GetAgent(hTargetDB.m_AgID).m_hDataBus.m_Health = hTargetDB.m_Health;
            end
            % and the targets...
            for iw = 1:length(hTargetDB.m_hWeaponsArray)
            sig = (hTargetDB.m_hWeaponsArray{iw}.CEP/1.177)*(d/100);
            Ph = 1 - exp(-Ah/(2*pi*(sig)^2));
            hitCounter = 0;
            for iround = 1:(hTargetDB.m_hWeaponsArray{iw}.RoF...
                    *hHeliDB.m_LocalTimeStep)
                if(abs(randn(1)) < Ph)
                    hitCounter = hitCounter + 1;
                end
            end
            % Update the target health (NOTE: this needs to be the real
            % target in the blackboard, not the alias).
            hHeliDB.m_Health = hHeliDB.m_Health - hitCounter...
                * hTargetDB.m_hWeaponsArray{iw}.RoundDamage...
                * hTargetDB.m_hWeaponsArray{iw}.NumThreats;
            stateobj.m_hAgent.m_hDataBus.m_Health = hHeliDB.m_Health;
            end
            fprintf('Range = %4.0f, Helicopter Health = %3.0f%%, Infantry Health = %3.0f%%\n',d,hHeliDB.m_Health,hTargetDB.m_Health);
        end
        
    end
    
end

