classdef Inspect < AgentPkg.AI.IAIState
    %INSPECT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Inspect(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            % Set the current waypoint to the initial location of the
            % target (this can be updated in future iterations)
            disp('Entered Inspect mode....');
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.xpos;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ypos;           
        end
        
        function stateobj = Execute(stateobj)
            % Update the target queue
            UpdateTargetQueue(stateobj);
            % Calculate the distance to current target
            d = Distance2Target(stateobj);
            % Classify the target if close enough (2km)
            fd = 'blue';
            if (d<2000)
                fd = ClassifyTarget(stateobj);
            end
            % If the target is a threat, decide to attack or evade
            if (strcmp(fd,'red'))
                % Toss the coin,
                P_attack = 0.9;
                x = randn(1);
                import HeliPkg.AI.AIL1.*
                if(abs(x) <= P_attack)
                    stateobj.m_hAIFSM.ChangeState...
                        (Attack(stateobj.m_hAgent,stateobj.m_hAIFSM));
                else
                    stateobj.m_hAIFSM.ChangeState...
                        (Evade(stateobj.m_hAgent,stateobj.m_hAIFSM));
                end
            end
            % If the current target is friendly, continue inspection...
            if (d < 200)
                import HeliPkg.AI.AIL1.*
                stateobj.m_hAgent.m_hDataBus.m_hTargetsInspected{end+1} = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1};
                % Remove the current target from the list
                [~,n] = size(stateobj.m_hAgent.m_hDataBus.m_hTargetQueue);
                if(n==1)
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                end
                if(n > 1)
                    tmpq = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue;
                    stateobj.m_hAgent.m_hDataBus.m_hTargetQueue = [];
                    for i=2:n
                        stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{i-1} = tmpq{i};
                    end
                end
                stateobj.m_hAIFSM.ChangeState(Search(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
            %
        end
        
        function Exit(stateobj)
            % 
%             delete(stateobj);
        end
        
        function UpdateTargetQueue(stateobj)
            % Extract the current track data.
            hDataBus = stateobj.m_hAgent.m_hDataBus;
            [~,n] = size(hDataBus.m_hTrackDB);
            tmp = cell(1,n);
            for i=1:n
                % Store the tracks locally
                tmp{i} = hDataBus.m_hTrackDB{1,i};
            end
            % Now, compare the ID's in the track database with those in the
            % target queue.
            for i=1:n
                [~,m] = size(hDataBus.m_hTargetQueue);
                newtargetflag = zeros(1,m);
                for j=1:m
                    % Need to manually update the track data in the target
                    % queue as MATLAB doesn't have pointers.
                    tmpID = hDataBus.m_hTargetQueue{j}.ID;
                    tmpag = stateobj.m_hAgent.m_hBB.GetAgent(tmpID);
                    hDataBus.m_hTargetQueue{j}.xpos = tmpag.m_hDataBus.x(1,1);
                    hDataBus.m_hTargetQueue{j}.ypos = tmpag.m_hDataBus.x(2,1);
                    % In a L1 queue, only the ID's are used
                    if(strcmp(tmp{i}.ID,hDataBus.m_hTargetQueue{j}.ID))
                        newtargetflag(j) = 0;
                    else
                        newtargetflag(j) = 1;
                    end
                end
                % If the track is a new target, and it hasn't already been
                % inspected, add to the queue
                if(all(newtargetflag))
                    [~,w] = size(hDataBus.m_hTargetsInspected);
                    visitedflag = zeros(1,w);
                    if(~isempty(hDataBus.m_hTargetsInspected))
                        for j=1:w
                            %
                            if(strcmp(tmp{i}.ID,hDataBus.m_hTargetsInspected{j}.ID))
                                visitedflag(j) = 1;
                            else
                                visitedflag(j) = 0;
                            end
                        end
                    end
                    if(~any(visitedflag))
                        hDataBus.m_hTargetQueue{end+1} = tmp{i};
                    end
                end
            end
        end
        
        function dist = Distance2Target(stateobj)
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.xpos;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ypos;
            % Test whether we have reached the current waypoint.
            xh = stateobj.m_hAgent.m_hDataBus.x(1,1);
            yh = stateobj.m_hAgent.m_hDataBus.x(2,1);
            xw = stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw;
            yw = stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw;
            dist = sqrt((xw-xh)^2+(yw-yh)^2);
        end
        
        function fd = ClassifyTarget(obj)
            target = obj.m_hAgent.m_hBB.GetAgent(...
                obj.m_hAgent.m_hDataBus.m_hTargetQueue{1}.ID);
            fd = target.m_hDataBus.ForceDesignation;
        end
    end
    
end

