classdef Search < handle
    %SEARCH Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = Search(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            %
            disp('Entered Search mode....');
        end
        
        function stateobj = Execute(stateobj)
            % Check if the sensor suite has flagged any new points of
            % interest.
            UpdateTargetQueue(stateobj);
            %
            if(~isempty(stateobj.m_hAgent.m_hDataBus.m_hTargetQueue))
                import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(Inspect(stateobj.m_hAgent,stateobj.m_hAIFSM));
                return;
            end
            % Test whether we have reached the current waypoint.
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xe = r(1,1); ye = r(2,1); ze = r(3,1);
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            nwp = stateobj.m_hAgent.m_hDataBus.NumWayPoints;
            xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            ze = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            d = sqrt((xw-xe)^2+(yw-ye)^2);
            if (d < 50 && wpind < nwp)
                wpind = wpind + 1;
            end
            stateobj.m_hAgent.m_hDataBus.WPindex = wpind;
            % Now, the code governing state transition to RTB.
            % Transition event will be when the helicopter on the final waypoint
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            nwp = stateobj.m_hAgent.m_hDataBus.NumWayPoints;
            xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            ze = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            d = sqrt((xw-xe)^2+(yw-ye)^2);
            if (wpind == nwp)
                import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(ReturnToBase(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
            %
        end
        
        function Exit(stateobj)
            % 
%             delete(stateobj);
        end
        
        function UpdateTargetQueue(stateobj)
            % Extract the current track data.
            hDataBus = stateobj.m_hAgent.m_hDataBus;
            [~,n] = size(hDataBus.m_hTrackDB);
            for i=1:n
                % Store the tracks locally
                tmp{i} = hDataBus.m_hTrackDB{1,i};
            end
            % Now, compare the ID's in the track database with those in the
            % target queue.
            for i=1:n
                [~,m] = size(hDataBus.m_hTargetQueue);
                newtargetflag = zeros(1,m);
                for j=1:m
                    % In a L1 queue, only the ID's are used
                    if(strcmp(tmp{i}.ID,hDataBus.m_hTargetQueue{j}.ID))
                        newtargetflag(j) = 0;
                    else
                        newtargetflag(j) = 1;
                    end
                end
                % If the track is a new target, and it hasn't already been
                % inspected, add to the queue
                if(all(newtargetflag))
                    [~,w] = size(hDataBus.m_hTargetsInspected);
                    visitedflag = zeros(1,w);
                    if(~isempty(hDataBus.m_hTargetsInspected))
                        for j=1:w
                            %
                            if(strcmp(tmp{i}.ID,hDataBus.m_hTargetsInspected{j}.ID))
                                visitedflag(j) = 1;
                            else
                                visitedflag(j) = 0;
                            end
                        end
                    end
                    if(~any(visitedflag))
                        hDataBus.m_hTargetQueue{end+1} = tmp{i};
                    end
                end
            end
        end
    end
    
end

