classdef ReturnToBase < handle
    %RETURNTOBASE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_hAgent
        m_hAIFSM
    end
    
    methods
        function stateobj = ReturnToBase(hAgent,hFSM)
            stateobj.m_hAgent = hAgent;
            stateobj.m_hAIFSM = hFSM;
        end
        
        function stateobj = Enter(stateobj)
            %
            disp('Entered ReturnToBase mode....');
        end
        
        function stateobj = Execute(stateobj)
            % Test whether we have reached the base.
            r = stateobj.m_hAgent.m_hDataBus.getPositionVec();
            xe = r(1,1); ye = r(2,1);
            wpind = stateobj.m_hAgent.m_hDataBus.WPindex;
            xw = stateobj.m_hAgent.m_hDataBus.WayPoints.xe(wpind);
            yw = stateobj.m_hAgent.m_hDataBus.WayPoints.ye(wpind);
            zw = stateobj.m_hAgent.m_hDataBus.WayPoints.ze(wpind);
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.xw = xw;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.yw = yw;
            stateobj.m_hAgent.m_hDataBus.m_CurrentWP.zw = zw;
            d = sqrt((xw-xe)^2+(yw-ye)^2);
            if (d < 50)
                import MAVERIC_SE.RotorcraftPkg.AI.AI_L1.*
                stateobj.m_hAIFSM.ChangeState(Land(stateobj.m_hAgent,stateobj.m_hAIFSM));
            end
            %
        end
        
        function Exit(stateobj)
            % 
            delete(stateobj);
        end
        
    end
    
end

