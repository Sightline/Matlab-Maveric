classdef Atmosphere < handle
    %ATMOSPHERE Class to provide atmospheric properties for a given
    %spatio-temporal location.
    %   
    
    properties
        T           % Ambient temperature (K)
        L           % Lapse rate (degK/m)
        rho         % Air density (kg/m3)
        xg          % Inertial x-position of gust
        yg          % Inertial y-position of gust
        zg          % Inertial z-position of gust
        ug          % Inertial x-velocity of gust
        vg          % Inertial y-velocity of gust
        wg          % Inertial z-velocity of gust
        t           % Current time
        LUT         % Look-up-table of spatio-temporal gust field
        active      % Flag for determining if the gust field is active
    end
    
    methods
        function this  = Atmosphere()
            % Initialise the properties
            this.T = 273;
            this.L = 1;
            this.rho = 1.225;
            this.xg = 0;
            this.yg = 0.0;
            this.zg = 0.0;
            this.ug = 0.0;
            this.vg = 0.0;
            this.wg = 0.0;
            this.LUT = [];
            this.active = false;
        end
        
        function ugv = getGustVelocity(this,x,y,z,t)
            %
            if(this.active)
                % Interpolate tables
            else
                ugv = [0;0;0];
            end
        end
        
        function rho = getDensity(this,h)
            % The local air density is a function of the ambient
            % temperature at altitude, h.
            rho = this.rho;
        end
        
        function attachTurbulenceField(this,filename)
            % Need to unpack the data stored in file 'filename' and sort it
            % into a 4-D loook-up table (x,y,z,t).
            this.LUT = filename;
        end
    end
    
end

