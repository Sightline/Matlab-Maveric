function ResetEAM(obj)
%RESETEAM Summary of this function goes here
%   Detailed explanation goes here
%% First, clear the existing EAM
obj.m_EntityAM = [];
obj.m_EntityAM = cell(2);
%% Now, re-create the EAM
ne = obj.m_NumEntities;
for ii = 1:ne
    ID = obj.m_EntityIDList{ii};
    r = ii+1; c = ii+1;
    obj.m_EntityAM{r,r,1} = 0;
    obj.m_EntityAM{r,1,1} = ID;
    obj.m_EntityAM{1,c,1} = obj.m_EntityAM{r,1,1};
    obj.m_EntityAM{r,r,2} = 0;
    obj.m_EntityAM{r,1,2} = ID;
    obj.m_EntityAM{1,c,2} = obj.m_EntityAM{r,1,2};
end
%% and re-populate the data
r = ne+1; c = ne+1;
% First, loop over the rows (from direction in the digraph)
for ii = 2:r
    % Now, the columns. Only need to examine the upper triangle as the
    % matrix is symmetric.
    for jj = ii+1:c
        % Now we need to calculate the distance from the current entity to
        % all other entities in the simulation. First we need to determine
        % if the current entity is an agent or scenery object.
        % Check for Agent
        agfrom = obj.GetEntity(obj.m_EntityAM{ii,1,1});
        agfrompose = agfrom.m_hDataBus.getPositionVec();
        agto = obj.GetEntity(obj.m_EntityAM{1,jj,1});
        agtopose = agto.m_hDataBus.getPositionVec();
        % Now calculate the range between entities
        obj.m_EntityAM{ii,jj,1} = sqrt((agtopose-agfrompose)'*...
            (agtopose-agfrompose));
        % Complete using symmetry
        obj.m_EntityAM{jj,ii,1} = obj.m_EntityAM{ii,jj,1};
        %
        % Question: What about using the relative position vector as the
        % entry to the Entity Adjacency Matrix cell array?
        obj.m_EntityAM{ii,jj,2} = agtopose-agfrompose;
        % Complete using symmetry
        obj.m_EntityAM{jj,ii,2} = agfrompose-agtopose;
    end
end


end

