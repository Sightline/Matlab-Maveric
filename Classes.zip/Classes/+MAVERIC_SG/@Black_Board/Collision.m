function Collision(this)
%COLLISION Summary of this function goes here
%   Detailed explanation goes here


end

