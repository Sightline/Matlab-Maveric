classdef (Sealed) Black_Board < handle
    %BLACKBOARD This object is used to store, manipulate and present all of
    %the data in the simulation.
    %   Detailed explanation goes here
    
    methods
        function obj = Black_Board
            % Agent Database properties
            obj.m_AgentList = [];
            obj.m_AgentPlatformList = [];
            obj.m_AgentGraph = [];
            obj.m_AgentIDList = [];
            obj.m_NumAgents = 0;
            % Scenery Object Database properties
            obj.m_SceneryObjList = [];
            obj.m_SceneryObjGraph = [];
            obj.m_SceneryObjIDList = [];
            obj.m_NumSceneryObjects = 0;
            % Terrain Object Database properties
            obj.m_TerrainObjList = [];
            obj.m_TerrainObjGraph = [];
            obj.m_TerrainObjIDList = [];
            obj.m_NumTerrainObjects = 0;
            % Default timing parameters
            obj.m_GlobalTimeStep = 0.1;
            obj.m_GlobalTime = 0;
            % Entity-Level ADT's
            obj.m_EntityAM = [];
            obj.m_EntityList = [];
            obj.m_EntityIDList = [];
            obj.m_NumEntities = 0;
        end
        %
        Collision(obj);
        UpdateEAM(obj);
        AddToEAM(obj,ag);
        ResetEAM(obj);
    end
    
    properties
        m_AgentList
        m_AgentPlatformList
        m_AgentGraph
        m_AgentIDList
        m_NumAgents
        m_NumPlatformAgents
        %
        m_SceneryObjList
        m_SceneryObjGraph
        m_SceneryObjIDList
        m_NumSceneryObjects
        %
        m_TerrainObjList
        m_TerrainObjGraph
        m_TerrainObjIDList
        m_NumTerrainObjects
        %
        m_GlobalTimeStep
        m_GlobalTime
        %
        m_EntityAM
        m_EntityList
        m_EntityIDList
        m_NumEntities
    end
    
    events
        ChangeDT
    end
    
    methods
        %
        function WriteContext(obj,ag)
            % first, get he agent ID
            ID = ag.m_hDataBus.m_AgID;
            [n,~] = size(obj.m_AgentIDList);
            if(n > 0)
                for i=1:n
                    if(strcmp(ID,obj.m_AgentIDList{i,1}))
                        obj.m_AgentIDList{i,2} = ag.m_hDataBus.x;
                    end
                end
            end
        end
        
        function delete(this)
            this.WipeBlackboard();
        end
        
        function AddSceneryObject(obj,SceneryObj)
            % Increment the number of scenery objects
            obj.m_NumSceneryObjects = obj.m_NumSceneryObjects + 1;
            obj.m_NumEntities = obj.m_NumEntities + 1;
            % Add sdcenery object to scenery object list
            obj.m_SceneryObjList{obj.m_NumSceneryObjects} = SceneryObj;
            % Update the Entity List
            obj.m_EntityList{obj.m_NumEntities} = SceneryObj;
            % Create internal scene object ID
            ID = sprintf('SO%d',obj.m_NumSceneryObjects);
            % Assign internal scene object ID to scene object databus
            % parameter
            obj.m_SceneryObjList{obj.m_NumSceneryObjects}.m_hDataBus.m_MRObjectID = ID;
            obj.m_SceneryObjIDList{obj.m_NumSceneryObjects,1} =...
                SceneryObj.m_hDataBus.m_MRObjectID;
            obj.m_EntityIDList{obj.m_NumEntities} = ...
                SceneryObj.m_hDataBus.m_MRObjectID;
            % Add the object ID to the EAM
            obj.AddToEAM(ID);
        end
        
        function AddAgent(obj,ag)
            % Increment the agent counter
            obj.m_NumAgents = obj.m_NumAgents + 1;
            % Add agent to the Agent List
            obj.m_AgentList{obj.m_NumAgents} = ag;
            % Create internal agent ID
            num = 1;
            if(isequal(obj.m_NumAgents,1))
                ID = sprintf('AG%d',obj.m_NumAgents);
            else
                while(num <= obj.m_NumAgents)
                    ID = sprintf('AG%d',num);
                    % Check this ID is not already assigned
                    assignedflag = false;
                    for ii = 1:obj.m_NumAgents-1
                        if(strcmp(ID,obj.m_AgentIDList{ii}))
                            assignedflag = true;
                            break;
                        end
                    end
                    if(assignedflag)
                        num=num+1;
                    else
                        break;
                    end
                end
            end
            % Assign internal agent ID to agent databus parameter
            obj.m_AgentList{obj.m_NumAgents}.m_hDataBus.m_AgID = ID;
            % Assign internal agent ID to agent pose database
            obj.m_AgentIDList{obj.m_NumAgents,1} = ag.m_hDataBus.m_AgID;
            % Check that this agent is a platform
            if(strcmp(ag.m_hDataBus.m_AgentType,'Platform'))
                % Increment the entity counter
                obj.m_NumEntities = obj.m_NumEntities + 1;
                % Update the Entity List
                obj.m_EntityList{obj.m_NumEntities} = ag;
                obj.m_EntityIDList{obj.m_NumEntities} = ag.m_hDataBus.m_AgID;
                % Update the platform list
                obj.m_AgentPlatformList{end+1,1} = ag.m_hDataBus.m_AgID;
                % Update the number of platform agents
                obj.m_NumPlatformAgents = obj.m_NumPlatformAgents + 1;
                % Add the agent ID to the EAM
                obj.AddToEAM(ID);
            end
        end
        
        function AddTerrainObject(obj,TerrainObj)
            obj.m_NumTerrainObjects = obj.m_NumTerrainObjects + 1;
            obj.m_TerrainObjList{obj.m_NumTerrainObjects} = TerrainObj;
            obj.m_TerrainObjIDList{obj.m_NumTerrainObjects,1} = ...
                TerrainObj.m_hDataBus.m_AgID;
        end
        
        function UpdateInterconnections(obj)
            % Perform the MR network update
        end
        
        
        function FoVTest(obj)
            % Test each entity in the database to determine which are
            % within the IFoV of each sensor in the arrays.
            for ag = 1:obj.m_NumAgents
                for sns = 1:obj.m_AgentList{ag}.m_hDataBus.m_NumSensors
                    % Calculate the sightline vector in inertial axes
                    xsv = obj.m_AgentList{ag}.m_hDataBus.m_hSensorArray{sns}.m_hCurrentSensDynMRState.xs;
                    az = xsv(1,1);
                    Caz = [cos(az) -sin(az) 0;sin(az) cos(az) 0; 0 0 1];
                    xh = obj.m_AgentList{ag}.m_hDataBus.x;
                    psi = xh(5,1);
                    Euler = [cos(psi) -sin(psi) 0;sin(psi) cos(psi) 0;0 0 1];
                    SL = Caz*Euler*[1 0 0]';
                    % Now that we have the sightline for this sensor, need
                    % to calculate the normalised vector to each entity in
                    % the simulation database
                    obj.m_AgentList{ag}.m_hDataBus.m_hSensorArray{sns}.m_hIFoVIndex = [];
                    i=1;
                    for agi = 1:obj.m_NumAgents
                        if(~strcmp(obj.m_AgentList{agi}.m_hDataBus.m_AgID,obj.m_AgentList{ag}.m_hDataBus.m_AgID))
                            xhi = obj.m_AgentList{agi}.m_hDataBus.x;
                            % The normalised true sightline between agents
                            % is then,
                            tsl = [xhi(1,1)-xh(1,1),xhi(2,1)-xh(2,1),1]'/...
                                sqrt((xhi(1,1)-xh(1,1))^2+(xhi(2,1)-xh(2,1))^2);
                            % To determine if the agent under test is in the
                            % IFoV of this sensor, find the scalar product
                            % of the true sightline and sightline vector
                            sp = tsl(1,1)*SL(1,1) + tsl(2,1)*SL(2,1);
                            tht = acos(sp); %unit vectors...
                            % Now, compare this angle with the beamwidth of
                            % the sensor.
                            if(abs(tht) < obj.m_AgentList{ag}.m_hDataBus.m_hSensorArray{sns}.BW*(pi/180)/2)
                                obj.m_AgentList{ag}.m_hDataBus.m_hSensorArray{sns}.m_hIFoVIndex{i} = ...
                                    obj.m_AgentList{agi}.m_hDataBus.m_AgID;
                            end
                            i=i+1;
                        end
                    end
                end
            end
        end
        
        function UpdateTimeStep(obj,dt)
            % The update time step function is called when the global DT has
            % changed. It then notifies all the agents.
            obj.m_GlobalTimeStep = dt;
            notify(obj,'ChangeDT');
        end
        
        function ResetClocks(obj,newClock,newTimeStep)
            % Set all the local clocks for all agents and objects in the
            % scene to the value contained in newClock. First the agents
            for ii = 1:obj.m_NumAgents
                obj.m_AgentList{ii}.m_hDataBus.m_GlobalTime = newClock;
            end
            % now the scene objects
            for jj = 1:obj.m_NumSceneryObjects
                obj.m_SceneryObjList{jj}.m_hDataBus.m_GlobalTime = newClock;
            end
            % Finally, the blackboard clock
            obj.m_GlobalTime = newClock;
            obj.m_GlobalTimeStep = newTimeStep;
        end
        
        function DT = GetGlobalDT(obj)
            % The purpose of this method is to retrieve the minimum
            % timestep currently active for all entities in the simulation.
            % Set default timestep (large)
            DT = 1000;  % 1000s
            % Loop over all entities in the scene
            for ii = 1:obj.m_NumEntities
                if(strcmp(obj.m_EntityList{ii}.m_hDataBus.m_SimStatus,'Active'))
                    % Each entity has a maximum of nine elements that can have
                    % individual timesteps. Each one needs to be checked.
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasDynamic)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_DynamicMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_DynamicResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasAI)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_AIMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_AIResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasControl)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_ControlMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_ControlResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasNavigation)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_NavigationMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_NavigationResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasGuidance)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_GuidanceMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_GuidanceResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasDetection)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_DetectionMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_DetectionResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasTracking)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_TrackingMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_TrackingResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasSightline)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_SightlineMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_SightlineResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                    %
                    if(obj.m_EntityList{ii}.m_hDataBus.m_HasGeometry)
                        dt = obj.m_EntityList{ii}.m_hDataBus...
                            .m_GeometryMRStatesTimeSteps(obj.m_EntityList{ii}...
                            .m_hDataBus.m_GeometryResolution);
                        if(dt < DT)
                            DT = dt;
                        end
                    end
                end
            end
        end
        
        function ag = GetAgent(obj,agID)
            % This method should return the agent handle corresponding to
            % the agent ID.
            [~,i] = max(strcmp(obj.m_AgentIDList,agID));
            ag = obj.m_AgentList{i};
        end
        
        function ag = GetEntity(obj,ID)
            % This method should return the entity handle corresponding to
            % the entity ID.
            [~,i] = max(strcmp(obj.m_EntityIDList,ID));
            ag = obj.m_EntityList{i};
        end
        
        function hen = RequestEntityHandle(obj,entID)
            % This method should return the object handle corresponding to
            % the object ID.
            [~,i] = max(strcmp(obj.m_EntityIDList,entID));
            hen = obj.m_EntityList{i};
        end
        
        function so = GetScenery(obj,soID)
            % This method should return the object handle corresponding to
            % the object ID.
            [~,i] = max(strcmp(obj.m_SceneryObjIDList,soID));
            so = obj.m_SceneryObjList{i};
        end
        
        function WipeBlackboard(obj)
            for ii = 1:obj.m_NumAgents
                delete(obj.m_AgentList{ii});
            end
            % now the scene objects
            for jj = 1:obj.m_NumSceneryObjects
                delete(obj.m_SceneryObjList{jj});
            end
            obj.m_NumAgents = 0;
            obj.m_AgentList = [];
            obj.m_NumSceneryObjects = 0;
            obj.m_SceneryObjList = [];
            obj.m_GlobalTime = 0;
        end
    end
end

