function AddToEAM(obj,ID)
%ADDTOEAM - A BlackBoard class method to augment the Entity Adjacency
%Matrix 
% Description
%           The Entity Adjacency Matrix represents the relative locations
%           between every entity in the simulation. 
%
%
% Author - Dr David Anderson
% Date - 29/04/2014
%
%% 
% If this is the first call, initialise the AM
ne = obj.m_NumEntities;
if(ne == 1)
    obj.m_EntityAM = cell(2);
    obj.m_EntityAM{2,2,1} = 0;
    obj.m_EntityAM{2,1,1} = ID;
    obj.m_EntityAM{1,2,1} = obj.m_EntityAM{2,1,1};
    obj.m_EntityAM{2,2,2} = 0;
    obj.m_EntityAM{2,1,2} = ID;
    obj.m_EntityAM{1,2,2} = obj.m_EntityAM{2,1,2};
end
% Subsequent calls will extend the EAM
if(ne > 1)
    r = ne+1; c = ne+1;
    obj.m_EntityAM{r,r,1} = 0;
    obj.m_EntityAM{r,1,1} = ID;
    obj.m_EntityAM{1,c,1} = obj.m_EntityAM{r,1,1};
    obj.m_EntityAM{r,r,2} = 0;
    obj.m_EntityAM{r,1,2} = ID;
    obj.m_EntityAM{1,c,2} = obj.m_EntityAM{r,1,2};
end

end
