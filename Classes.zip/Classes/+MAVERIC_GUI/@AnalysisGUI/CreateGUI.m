function hGUIobj = CreateGUI( hGUIobj )
%CREATEGUI Method used to create the main GUI window
%   ---------------------------------------------
%% Create the main figure window
hGUIobj.m_hmainGUI.handles.hAnalysisFig = figure(...
                'Name', 'Analysis Figure', ...
                'NumberTitle', 'off', ...
                'HandleVisibility', 'on',...
                'Color','w',...
                'CloseRequestFcn',@AnalysisFigCloseRequest);


 d2r = pi/180;
        % get the selected agent
        ii = get(hObject,'Value');
        pfig = get(0,'CurrentFigure');
        set(0,'CurrentFigure',hGUIobj.theSIM.m_hGUI.handles.hAnalysisFig);
        subplot(2,3,1)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        xe = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(1,:);
        plot(t,xe); xlabel('time (s)');ylabel('xe (m/s)');
        grid;
        %
        subplot(2,3,2)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        ye = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(2,:);
        plot(t,ye); xlabel('time (s)');ylabel('ye (m/s)');
        grid;
        %
        subplot(2,3,3)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        ze = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(3,:);
        plot(t,ze); xlabel('time (s)');ylabel('ze (m/s)');
        grid;
        %
        subplot(2,3,4)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        Vf = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(4,:);
        plot(t,Vf); xlabel('time (s)');ylabel('Vf (m/s)');
        grid;
        %
        subplot(2,3,5)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        psi = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(5,:)/d2r;
        plot(t,psi); xlabel('time (s)');ylabel('psi (deg)');
        grid;
        %
        subplot(2,3,6)
        t = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(7,:);
        gamma = hGUIobj.theSIM.m_hScene.m_DataCube{1,ii,1}(6,:)/d2r;
        plot(t,gamma); xlabel('time (s)');ylabel('gamma (deg)');
        grid;
        %
        shg;
        set(0,'CurrentFigure',pfig);




%-------------------------------------------------------------------------%
    function AnalysisFigCloseRequest(~,~)
        try
            delete(hGUIobj.m_hmainGUI.handles.hAnalysisFig);
            hGUIobj.m_hmainGUI.handles.hAnalysisFig = [];
        catch Exception
            errordlg({'Analysis figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%


end