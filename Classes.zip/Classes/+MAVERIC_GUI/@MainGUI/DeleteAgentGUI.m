function DeleteAgentGUI(hGUIobj)
%DeleteAgentGUI Summary of hGUIobj.theSIM.m_hScene function goes here
%   Detailed explanation goes here
%% Create the main figure window
sz = get(0,'ScreenSize');
hGUIobj.handles.hDeleteAgentGUI.Window = figure(...
    'Name', 'Delete Agent from Scene', ...
    'NumberTitle', 'off', ...
    'MenuBar', 'none', ...
    'Toolbar', 'none', ...
    'HandleVisibility', 'on',...
    'Color','w',...
    'OuterPosition',[(sz(3)/2-200),...
    (sz(4)/2),...
    400,130],...
    'CloseRequestFcn',@DeleteAgentGUICloseRequest);
% Set default panel colors
csc = 1/256;
backColor = 'w';
borderColor = csc*[10 70 130];
%
%  Create Controls
%
hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainPanel = uiextras.Panel(...
    'Parent',hGUIobj.handles.hDeleteAgentGUI.Window,...
    'Padding',10,...
    'BackgroundColor',backColor);
hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainVBox = uiextras.VBox(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainPanel,...
    'Spacing',5,...
    'BackgroundColor',backColor);
hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainHBox = uiextras.HBox(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainVBox,...
    'Spacing',10,...
    'BackgroundColor',backColor);
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainHBox),...
    'Style','text',...
    'String','Select Agent',...
    'HorizontalAlignment','left',...
    'BackgroundColor',backColor,...
    'FontWeight','bold',...
    'FontSize',10);
hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.AgentPopup = uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainHBox),...
    'Style','popupmenu',...
    'String','   ',...
    'HorizontalAlignment','left',...
    'Callback',@AgentPopup_Callback,...
    'BackgroundColor','w');
%
%
% Buttons
%
hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1 = uiextras.Grid(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainVBox,...
    'Spacing',30,...
    'Padding',5,...
    'BackgroundColor',backColor);
uiextras.Empty(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1,...
    'BackgroundColor',backColor);
hRadio = uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1),...
    'Style','radio',...
    'String',' ',...
    'HorizontalAlignment','right',...
    'Value',0,...
    'BackgroundColor','w',...
    'ForegroundColor','w');
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1),...
    'String','DELETE',...
    'HorizontalAlignment','center',...
    'BackgroundColor',borderColor,...
    'ForegroundColor','w',...
    'FontWeight','bold',...
    'Callback',@DeleteButton_Callback);
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1),...
    'String','CANCEL',...
    'HorizontalAlignment','center',...
    'BackgroundColor',borderColor,...
    'ForegroundColor','w',...
    'FontWeight','bold',...
    'Callback',@CancelButton_Callback);
uiextras.Empty(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1,...
    'BackgroundColor',backColor);
%
% Set the layout sizes
%
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainVBox,'Sizes',[-1,35]);
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.MainHBox,'Sizes',[-1,-2]);
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.Grid1,'ColumnSizes',[-1,25,60,60,-1]);
%
%
% Need to populate the agent popup
str = cell(1,1);
indx = [];
% Update the scene listbox (Name,Type,Class).
kk = 1;
for ii=1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
    indx(ii) = 0;
    parent = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_hParent;
    if(isempty(parent))
        name = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.Tag;
        agtype = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_AgentType;
        agclass = class(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii});
        str{kk} = sprintf('%-s \t %-s \t %-s',name,agtype,agclass);
        indx(ii) = kk;
        kk = kk+1;
    end
end
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.AgentPopup,'String',str);
hGUIobj.handles.hDeleteAgentGUI.PopupCallback = false;
%*************************************************************************%
% CALLBACK FUNCTIONS
%*************************************************************************%
%
%-------------------------------------------------------------------------%
    function DeleteAgentGUICloseRequest(~,~)
        try
            delete(hGUIobj.handles.hDeleteAgentGUI.Window);
        catch Exception
            errordlg({'Add Agent figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%
    function AgentPopup_Callback(~,~)
        %
        hGUIobj.handles.hDeleteAgentGUI.PopupCallback = true;
        set(hRadio,'Value',1);
    end
%-------------------------------------------------------------------------%
    function CancelButton_Callback(~,~)
        %
        try
            delete(hGUIobj.handles.hDeleteAgentGUI.Window);
        catch Exception
            errordlg({'Add Agent figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%
    function DeleteButton_Callback(~,~)
        % First, get the selected agent from the popup. Ensure that the
        % popup callback has been activated.
        if(~hGUIobj.handles.hDeleteAgentGUI.PopupCallback)
            warndlg('Caution - No Agents have been selected');
            return;
        end
        %
        % Now get the selected agent.
        pv = get(hGUIobj.theSIM.m_hGUI.handles.hDeleteAgentGUI.AgentPopup,'Value');
        val = find(indx==pv);
        id = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{val}.m_hDataBus.m_AgID;
        % need to find the location of the entity in the main entity list
        % using the agent ID.
        valEnt = 0;
        for jj=1:length(hGUIobj.theSIM.m_hScene.m_hBB.m_EntityList)
            if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_EntityIDList{jj},id))
                valEnt = jj;
                break;
            end
        end
        % If hGUIobj.theSIM.m_hScene is a parent object, also need to delete and remove the
        % child objects.
        
        if(isempty(parent))
            deleteAgent(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{val});
            % The last operation is to call the EAMatrix Reset method.
            hGUIobj.theSIM.m_hScene.m_hBB.ResetEAM();
        elseif(~isempty(parent))
            warndlg({'Only PLATFORM-Level Agents may be deleted from',...
                'a Scene. To alter the sensor array, edit the object datafile'});
        end
        %
        % Almost there - now update the main GUI
        hGUIobj.theSIM.m_hGUI.UpdateGUI();
        %
        % Finally, close the GUI
        try
            delete(hGUIobj.handles.hDeleteAgentGUI.Window);
        catch Exception
            errordlg({'Add Agent figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%

end

function deleteAgent(Agent)
% We should delete entities from the leaf nodes in the system tree.
% Find if the agent has any children
[~,n] = size(Agent.m_hDataBus.m_hChildrenArray);
for ii = 1:n
    deleteAgent(Agent.m_hDataBus.m_hChildrenArray{ii});
end
% If we have reached here, we are at a leaf node. First remove any attached
% geometry.
if(isfield(Agent.m_hDataBus.ParameterData,'GeomHGTransform'))
    if(isfield(Agent.m_hDataBus.ParameterData,'GeomPatchHandles'))
    [n,m] = size(Agent.m_hDataBus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Agent.m_hDataBus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Agent.m_hDataBus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Agent.m_hDataBus.ParameterData.GeomPatchHandles = [];
    end
    [n,m] = size(Agent.m_hDataBus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Agent.m_hDataBus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
end
%
% Remove the waypoints plot if they exist
if(~isempty(Agent.m_hDataBus.WayPoints))
    wp = Agent.m_hDataBus.WayPoints;
    nwp = length(wp.xe);
    if(isfield(Agent.m_hDataBus.ParameterData,'WaypointHandles'))
        if(iscell(Agent.m_hDataBus.ParameterData.WaypointHandles))
            for ii=1:nwp
                if(ishghandle(Agent.m_hDataBus.ParameterData.WaypointHandles{ii}))
                    delete(Agent.m_hDataBus.ParameterData.WaypointHandles{ii});
                end
            end
            Agent.m_hDataBus.ParameterData.WaypointHandles = [];
        end
    end
    if(isfield(Agent.m_hDataBus.ParameterData,'WaypointTrajHandle'))
        if(ishghandle(Agent.m_hDataBus.ParameterData.WaypointTrajHandle))
            delete(Agent.m_hDataBus.ParameterData...
                .WaypointTrajHandle);
            Agent.m_hDataBus.ParameterData...
                .WaypointTrajHandle = [];
        end
    end
end
%
% Finally, delete the agent from the agent lists. As this is a recursive
% function, we need to find the position of the agent in both agent and
% entity lists.
id = Agent.m_hDataBus.m_AgID;
val = 0;
for jj=1:length(Agent.m_hBB.m_AgentList)
    if(strcmp(Agent.m_hBB.m_AgentIDList{jj},id))
        val = jj;
        break;
    end
end
Agent.m_hBB.m_AgentList(val) = [];
Agent.m_hBB.m_AgentIDList(val,:) = [];
Agent.m_hBB.m_NumAgents = Agent.m_hBB.m_NumAgents - 1;
%
% Now remove from the entity list. Recall, only platforms are attached to
% this list.
if(strcmp(Agent.m_hDataBus.m_AgentType,'Platform'))
    valEnt = 0;
    for jj=1:length(Agent.m_hBB.m_EntityList)
        if(strcmp(Agent.m_hBB.m_EntityIDList{jj},id))
            valEnt = jj;
            break;
        end
    end
    % and lastly from the entity lists
    Agent.m_hBB.m_EntityList(valEnt) = [];
    Agent.m_hBB.m_EntityIDList(valEnt) = [];
    Agent.m_hBB.m_NumEntities = Agent.m_hBB.m_NumEntities - 1;
end
%
% Finally, delete the agent object...
delete(Agent);
end