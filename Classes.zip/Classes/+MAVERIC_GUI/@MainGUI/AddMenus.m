function AddMenus(hGUIobj)
%ADDMENUS Summary of this function goes here
%   Detailed explanation goes here

%% Create the menus
% + File menu
hGUIobj.theSIM.m_hGUI.handles.FileMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'File' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'New           ', 'Callback', @onNewScene, 'Accelerator','N' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Clear         ', 'Callback', @onClearScene );
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Open          ', 'Callback', @onLoadScene );
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Save Scene    ', 'Callback', @onSaveScene,...
    'Separator','on',...
    'Accelerator','S');
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'New Base Class', 'Callback', @onNewBaseClass,...
    'Separator','on');
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'New Class     ', 'Callback', @onNewClass);
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Browse Class  ', 'Callback', @onBrowseClass);
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Export...     ', 'Callback', @onExport,...
    'Separator','on');
uimenu( hGUIobj.theSIM.m_hGUI.handles.FileMenu, 'Label', 'Quit', 'Callback', @onExit,...
    'Separator','on',...
    'Accelerator','Q');
% + Scene menu
hGUIobj.theSIM.m_hGUI.handles.SceneMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'Scene' );
% hAdd = hGUIobj.theSIM.m_hGUI.handles.SceneMenu;
hAgent = uimenu(hGUIobj.theSIM.m_hGUI.handles.SceneMenu,'Label', 'Add...         ');
uimenu( hAgent,'Label', 'Agent...            ',...
    'Callback', @onAddAgent,...
    'Accelerator','A');
uimenu( hAgent,'Label', 'Scenery Object...   ',...
    'Callback', @onAddScenery);
uimenu( hAgent,'Label', 'Terrain...          ',...
    'Callback', @onAddTerrain);
hObject = uimenu(hGUIobj.theSIM.m_hGUI.handles.SceneMenu,'Label', 'Move/Scale...       ');
uimenu( hObject,'Label', 'Agent...           ',...
    'Callback', @onEditAgent,...
    'Separator','on',...
    'Accelerator','E');
uimenu( hObject,'Label', 'Scenery Object...  ',...
    'Callback', @onEditScenery);
uimenu( hObject,'Label', 'Terrain...         ',...
    'Callback', @onEditTerrain);
uimenu( hObject,'Label', 'All Entities...    ',...
    'Callback', @onEditAllEntities,...
    'Separator','on');
hTerrain = uimenu(hGUIobj.theSIM.m_hGUI.handles.SceneMenu,'Label', 'Delete...      ');
uimenu( hTerrain,'Label', 'Agent...          ',...
    'Callback', @onDeleteAgent,...
    'Separator','on',...
    'Accelerator','T');
uimenu( hTerrain,'Label', 'Scenery Object... ',...
    'Callback', @onDeleteScenery);
uimenu( hTerrain,'Label', 'Terrain...        ',...
    'Callback', @onDeleteTerrain);
%
uimenu( hGUIobj.theSIM.m_hGUI.handles.SceneMenu,'Label', 'Refresh Entity          ',...
    'Callback', @onRefreshEntity,...
    'Separator','on');
%
uimenu( hGUIobj.theSIM.m_hGUI.handles.SceneMenu,'Label', 'Refresh All          ',...
    'Callback', @onRefreshAll);

% + Vignette menu
hGUIobj.theSIM.m_hGUI.handles.VignetteMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'Vignette' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'Cargo Delivery         ',...
    'Callback', @onTempVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'Flyout                 ',...
    'Callback', @onTempVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'ISR                    ',...
    'Callback', @onTempVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'mUAS Circle            ',...
    'Callback', @onTempVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'mUAS Figure-of-Eight   ',...
    'Callback', @onmUASFigofEight);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'Search                 ',...
    'Callback', @onTempVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'Search & Destroy       ',...
    'Callback', @onSearchDestroyVignette);
uimenu( hGUIobj.theSIM.m_hGUI.handles.VignetteMenu, 'Label',...
    'Search & Rescue        ',...
    'Callback', @onTempVignette);

% + Simulation menu
hGUIobj.theSIM.m_hGUI.handles.SimulationMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'Simulation' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.SimulationMenu, 'Label',...
    'Single Run       ',...
    'Callback', @onRunVignette,...
    'Accelerator','R');
uimenu( hGUIobj.theSIM.m_hGUI.handles.SimulationMenu, 'Label',...
    'Monte-Carlo Run       ',...
    'Callback', @onRunMonteCarlo,...
    'Accelerator','R');
uimenu( hGUIobj.theSIM.m_hGUI.handles.SimulationMenu, 'Label',...
    'Modify Termination Criteria',...
    'Separator','on',...
    'Callback', @onEditAgent );

% + View menu
hGUIobj.theSIM.m_hGUI.handles.ViewMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'View' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.ViewMenu, 'Label', 'Default', 'Callback', @onDefaultView );
uimenu( hGUIobj.theSIM.m_hGUI.handles.ViewMenu, 'Label', 'Chase Camera', 'Callback', @onChaseCam );
uimenu( hGUIobj.theSIM.m_hGUI.handles.ViewMenu,...
    'Label', 'Background Colour      ',...
    'Callback', @onBackgroundColour ,...
    'Separator','on');
hAxisLimits = uimenu( hGUIobj.theSIM.m_hGUI.handles.ViewMenu,'Label', 'Axis Limits...          ');
uimenu( hAxisLimits,'Label', 'Edit Manually...          ',...
    'Callback', @onEditSceneExtent);
uimenu( hAxisLimits,'Label', 'Use Scene Extent...          ',...
    'Callback', @onDefaultSceneExtent);
uimenu( hGUIobj.theSIM.m_hGUI.handles.ViewMenu,'Label', 'Clear Console...          ',...
    'Callback', @onClearConsole);

% + Options menu
hGUIobj.theSIM.m_hGUI.handles.OptionsMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'Options' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.OptionsMenu, 'Label', 'Use Wizard', 'Callback', @onWizard );

% + Help menu
hGUIobj.theSIM.m_hGUI.handles.HelpMenu = uimenu( hGUIobj.theSIM.m_hGUI.handles.Window, 'Label', 'Help' );
uimenu( hGUIobj.theSIM.m_hGUI.handles.HelpMenu, 'Label', 'About', 'Callback',@onAbout );

%*************************************************************************%
% CALLBACK FUNCTIONS
%*************************************************************************%
%-------------------------------------------------------------------------%
    function onExit( ~, ~ )
        % User wants to quit out of the application
        try
            set(hGUIobj.theSIM.m_hGUI.handles.jTextArea,'CaretUpdateCallback',[]);
            if(~isempty(hGUIobj.theSIM.m_hGUI.handles.hAnalysisFig))
                delete(hGUIobj.theSIM.m_hGUI.handles.hAnalysisFig);
            end
            delete(hGUIobj.theSIM.m_hGUI.handles.Window);
        catch ME
            errordlg(ME.message);
        end
        
    end % onExit
%-------------------------------------------------------------------------%
    function onExport( ~, ~ )
        % User wants to serialise data in bespoke format
        
    end % onExport
%-------------------------------------------------------------------------%
    function onNewBaseClass(src,event)
        % Create a new base class.
        % Need to launch a GUI to get the name of the base class
        hGUIobj = hGUIobj.NewBaseClassGUI();
        
    end % onNewBaseClass
%-------------------------------------------------------------------------%
    function onNewClass(src,event)
        % Create a new base class.
        % Need to launch a GUI to get the name of the base class
        hGUIobj = hGUIobj.NewClassGUI();
        
    end % onNewClass
%-------------------------------------------------------------------------%
    function onBrowseClass(src,event)
        % Browse the class library.
        %         hGUIobj = hGUIobj.BrowseClassGUI();
        
    end % onBrowseClass
%-------------------------------------------------------------------------%
    function onNewScene( ~, ~)
        % Create a new scene.
        % First, test is there is a scene object loaded and prompt the user
        % if they wish to save the current scene.
        if(~isempty(hGUIobj.theSIM.m_hScene))
            % Do cleanup stuff here
        end
        % Launch the NewScene GUI. First, instansiate a NewSceneGUI object
        % and call the CreateGUI method.
        import MAVERIC_GUI.*
        hGUIobj.Children.hNewScene = NewSceneGUI(hGUIobj.theSIM);
        hGUIobj.Children.hNewScene.CreateGUI();
    end % onNewScene
%-------------------------------------------------------------------------%
    function onClearScene( ~, ~)
        % Clear the current scene.
        % First, test is there is a scene object loaded and prompt the user
        % if they wish to save the current scene.
        if(~isempty(hGUIobj.theSIM.m_hScene))
            % Do cleanup stuff here
        end
        proceedyn = questdlg('If you continue, the current scene will be deleted. Do you wish to proceed?',...
            'Delete Scene?','YES','NO','NO');
        switch proceedyn
            case 'YES'
                delete(hGUIobj.theSIM.m_hScene);
                import MAVERIC_SG.*
                hGUIobj.theSIM.m_hScene = Scene(hGUIobj.theSIM);
                % Now, clear the main axes.
                cla(hGUIobj.theSIM.m_hGUI.handles.ViewAxes);
                axis auto;
                % Additional cleanup
                hGUIobj.theSIM.m_hGUI.handles.Lightsource = [];
                hGUIobj.theSIM.m_hScene.m_Background = [0.1 0.1 0.1];
                set(hGUIobj.theSIM.m_hGUI.handles.ViewPanel,...
                    'BackgroundColor',[0.1 0.1 0.1]);
                set(hGUIobj.theSIM.m_hGUI.handles.ViewAxes,...
                    'XColor','w',...
                    'YColor','w',...
                    'ZColor','w');
                xlabel(hGUIobj.theSIM.m_hGUI.handles.ViewAxes,'East','color','w');
                ylabel(hGUIobj.theSIM.m_hGUI.handles.ViewAxes,'North','color','w');
                zlabel(hGUIobj.theSIM.m_hGUI.handles.ViewAxes,'Altitude','color','w');
                hGUIobj.UpdateGUI();
                filename = 'MAVERIC';
                hGUIobj.theSIM.m_hScene.m_Name = filename;
                titlestr = sprintf('%s - View',filename);
                set(hGUIobj.theSIM.m_hGUI.handles.ViewPanel,'Title',titlestr);
                titlestr = sprintf('%s - Structure',filename);
                set(hGUIobj.theSIM.m_hGUI.handles.TreePanel,'Title',titlestr);
            case 'NO'
                return;
        end
    end % onClearScene
%-------------------------------------------------------------------------%
    function onEditScene( ~, ~ )
        % Edit the existing scene
        % First, test is there is a scene object loaded.
        
    end % onEditScene
%-------------------------------------------------------------------------%
    function onLoadScene( ~, ~)
        % Load a new scene.
        % First, test is there is a scene object loaded and prompt the user
        % if they wish to save the current scene.
        %         proceedyn = questdlg({'If you continue, the current scene will',...
        %             'be deleted. Do you wish to save the current scene?'},...
        %             'Save Scene?','YES','NO','YES');
        %         switch proceedyn
        %             case 'YES'
        % First need to make a copy of the scene object as uisave
        % does not accept class notation
        %                 Scene = hGUIobj.theSIM.m_hScene;
        % Clear the reference to the simulation object (to prevent
        % circular serialisation and problems with GUI Layout) and
        % launch the uisave GUI.
        %                 Scene.m_htheSIM = [];
        %                 uisave('Scene','myScene');
        %             case 'NO'
        %                 % Continue
        %         end
        %
        % Clear the current view axes
        cla(hGUIobj.handles.ViewAxes);
        % Now load the new scene data
        fn = uigetfile();
        try
            tmpdata = load(fn);
        catch err
            %             errordlg({'Failed to load the scene file: ',err.message});
            return;
        end
        %
        % The new scene data object is now in the workspace under
        % tmpdata.Scene. We need to attach this object to the m_hScene
        % handle in the simulation object.
        theSIM =  MAVERIC_SE.SimEngine.Simulation.getInstance();
        theSIM.m_hScene = tmpdata.Scene;
        % and reconnect the handle from Scene object to theSIM
        theSIM.m_hScene.m_htheSIM = theSIM;
        %
        % All of the objects in the blackboard database attached to the new
        % scene object have inactive links to the main view and therefore
        % the simulation entities cannot be rendered. Need to restore those
        % links.
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumAgents
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_AgentList{ii}.m_hDataBus);
                % Finally, plot the agent in the view axes
                drawnow;
            end
        end
        %
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumSceneryObjects
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_SceneryObjList{ii}.m_hDataBus);
            end
        end
        %
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumTerrainObjects
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_TerrainObjList{ii}.m_hDataBus);
            end
        end
        %
        % Now set the background colour
        set(hGUIobj.theSIM.m_hGUI.handles.ViewPanel,'BackgroundColor',...
            theSIM.m_hScene.m_Background);
        
        %
        % Vignette - if the loaded sceen has a current vignette, run the
        % appropriate GUI creation method.
        if(~isempty(theSIM.m_hScene.m_CurrentVignette))
            switch theSIM.m_hScene.m_CurrentVignette
                case 'Search&Destroy'
                    onSearchDestroyVignette();
                case 'mUASFigureofEight'
                    onmUASFigofEight();
            end
        end
        %
        % Finally, update the GUI
        hGUIobj.UpdateGUI();
        % and reset the lightsource in the scene to the centre of the
        % terrain.
        onDefaultSceneExtent();
        xr = get(hGUIobj.handles.ViewAxes,'XLim');
        yr = get(hGUIobj.handles.ViewAxes,'YLim');
        lpos = [(xr(2)-xr(1))/2 (yr(2)-yr(1))/2 xr(2)];
        hGUIobj.handles.Lightsource = light('Parent',hGUIobj.handles.ViewAxes,...
            'Position',lpos,...
            'HandleVisibility','on',...
            'Style','local');
        set(hGUIobj.handles.ViewTabLightsourceEdit,'String',num2str(lpos));
    end % onLoadScene
%-------------------------------------------------------------------------%
    function onSaveScene( ~, ~ )
        % Save the current scene.
        % First, test is there is a scene object loaded and prompt the user
        % if they wish to save the current scene.
        
        % Need to copy the scene object to a temporary variable as uisave
        % will not accept dot notation
        Scene = hGUIobj.theSIM.m_hScene;
        % Need to remove the handle to theSIM object or a circular
        % reference will occur, causing issues in saving GUI elements.
        Scene.m_htheSIM = [];
        % Save ONLY the scene data
        %         uisave('Scene','myScene');
        [filename,pn] = uiputfile('MyScene.mat',num2str(Scene.m_Name));
        fn = fullfile(pn,filename);
        save(fn,'Scene');
        filename = strrep(filename,'.mat','');
        % Now need to re-attach the handle to theSIM object
        hGUIobj.theSIM.m_hScene.m_htheSIM = hGUIobj.theSIM;
        hGUIobj.theSIM.m_hScene.m_Name = filename;
        titlestr = sprintf('%s - View',filename);
        set(hGUIobj.theSIM.m_hGUI.handles.ViewPanel,'Title',titlestr);
        titlestr = sprintf('%s - Structure',filename);
        set(hGUIobj.theSIM.m_hGUI.handles.TreePanel,'Title',titlestr);
    end % onSaveScene
%-------------------------------------------------------------------------%
    function onSaveSceneVignette( ~, ~  )
        % Save the current scene plus vignette.
        % First, test is there is a scene object loaded and prompt the user
        % if they wish to save the current scene.
        
    end % onSaveSceneVignette
%-------------------------------------------------------------------------%
    function onEditSceneExtent( ~, ~ )
        %
        hGUIobj.ChangeAxisLimGUI();
    end % onEditSceneExtent

%-------------------------------------------------------------------------%
    function onDefaultSceneExtent( ~, ~ )
        % Get the scene extent from the current terrain
        if(~isempty(hGUIobj.theSIM.m_hScene.m_hBB.m_TerrainObjList))
            xrange = hGUIobj.theSIM.m_hScene.m_hBB.m_TerrainObjList{1}...
                .m_hDataBus.ParameterData.xrange;
            yrange = hGUIobj.theSIM.m_hScene.m_hBB.m_TerrainObjList{1}...
                .m_hDataBus.ParameterData.yrange;
            xmin = min(xrange); xmax = max(xrange);
            ymin = min(yrange); ymax = max(yrange);
            % Set the limits on the view axes
            set(hGUIobj.handles.ViewAxes,'XLim',[xmin, xmax]);
            set(hGUIobj.handles.ViewAxes,'YLim',[ymin, ymax]);
            % Set the default altitude to the same value as the x-axis limit.
            set(hGUIobj.handles.ViewAxes,'ZLim',[1, xmax]);
        else
            set(hGUIobj.handles.Window,'CurrentAxes',hGUIobj.handles.ViewAxes);
            ch = [];
            % Get the axes children.
            for i=1:length(hGUIobj.handles.ViewAxes)
                newCh = findobj(hGUIobj.handles.ViewAxes);
                ch = [ch;newCh(2:end)]; %#ok<AGROW>
            end
            %
            h = findall(ch);
            for i = 1:length(h)
                if ishghandle(h(i), 'patch')
                    v = get(h(i), 'vertices');
                    validtype = ~isempty(v) && any(isfinite(v(:)));
                    if validtype
                        f = get(h(i), 'faces');
                        v = v(f(isfinite(f)),:);
                        xd = v(:,1);
                        yd = v(:,2);
                        if size(v,2)==2
                            zd = 0;
                        else
                            zd = v(:,3);
                        end
                    end
                end
            end
            %
            xmin = min(xd(:));
            xmax = max(xd(:));
            ymin = min(yd(:));
            ymax = max(yd(:));
            zmin = min(zd(:));
            zmax = max(zd(:));
            limits = [xmin xmax ymin ymax zmin zmax];
            hasdepth = limits(5) ~= limits(6);
            if all(isfinite(limits(1:4))),
                set(hGUIobj.handles.ViewAxes,...
                    'xlim',limits(1:2),...
                    'ylim',limits(3:4))
            end
            if hasdepth
                set(hGUIobj.handles.ViewAxes,'zlim',limits(5:6))
            end
            drawnow;
        end
    end % onDefaultSceneExtent
%-------------------------------------------------------------------------%
    function onAddAgent( ~, ~ )
        % Add an Agent object.
        % First, select the class, perform validity tests and launch the
        % properties GUI.
        hGUIobj.AddAgentGUI();
        
    end % onAddAgent
%-------------------------------------------------------------------------%
    function onEditAgent( ~, ~  )
        % Edit an agent (move/scale).
        % First, select the Agent, perform validity tests and launch the
        % properties GUI.
        hGUIobj.EditAgentGUI();
        
    end % onEditAgent
%-------------------------------------------------------------------------%
    function onDeleteAgent( ~, ~  )
        % Delete an agent.
        % First, select the Agent.
        hGUIobj.DeleteAgentGUI();
    end % onDeleteAgent
%-------------------------------------------------------------------------%
    function onAddScenery( ~, ~  )
        % Add a scenery object
        % First, select the Scenery class, perform validity tests and launch the
        % properties GUI.
        hGUIobj.AddSceneObjectGUI();
    end % onAddScenery
%-------------------------------------------------------------------------%
    function onEditScenery( ~, ~  )
        % Edit a scenery object
        %
        hGUIobj.EditSceneryGUI();
    end % onEditScenery
%-------------------------------------------------------------------------%
    function onDeleteScenery( ~, ~  )
        % Delete a Scenery Object.
        % First, select the Object.
        hGUIobj.DeleteSceneryGUI();
    end % onDeleteScenery
%-------------------------------------------------------------------------%
    function onAddTerrain( ~, ~  )
        % Add a Terrain object
        % First, select the Scenery class, perform validity tests and launch the
        % properties GUI.
        hGUIobj.AddTerrainGUI();
    end % onAddTerrain
%-------------------------------------------------------------------------%
    function onEditTerrain( ~, ~  )
        % Edit a Terrain object
        %
        hGUIobj.EditTerrainGUI();
    end % onEditTerrain
%-------------------------------------------------------------------------%
    function onEditAllEntities( ~, ~  )
        % Edit all objects
        hGUIobj.ScaleAllAgentsGUI();
    end % onEditAllEntities

%-------------------------------------------------------------------------%
    function onDeleteTerrain( ~, ~  )
        % Delete the Terrain.
        % First, select the Terrain.
        hGUIobj.DeleteTerrainGUI();
    end % onDeleteTerrain
%-------------------------------------------------------------------------%
    function onRefreshEntity( ~, ~  )
        theSIM =  MAVERIC_SE.SimEngine.Simulation.getInstance();
        % Refresh the geometry. First the agents
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumAgents
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_AgentList{ii}.m_hDataBus);
                % Finally, plot the agent in the view axes
                theSIM.m_hScene.DrawAgent(ii);
            end
        end
        %
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumSceneryObjects
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_SceneryObjList{ii}.m_hDataBus);
            end
        end
        %
        for ii = 1:theSIM.m_hScene.m_hBB.m_NumTerrainObjects
            % First, check that the agent has a geometry module attached
            if(theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus.m_HasGeometry)
                % Get the entity datafile
                df = theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus.m_DataFile;
                str = sprintf('%sAttachGeometry',df);
                % Now convert to function handle
                fh = str2func(str);
                % and attach the geometry to the object
                theSIM.m_hScene.m_hBB.m_TerrainObjList{ii}.m_hDataBus = fh(theSIM.m_hScene...
                    .m_hBB.m_TerrainObjList{ii}.m_hDataBus);
            end
        end
        %
        % Finally, update the view.
        theSIM.m_hScene.DrawScene_ver2();
    end % onRefreshEntity
%-------------------------------------------------------------------------%
    function onDefaultView( ~, ~  )
        % Reset the current view to default
        %
        
    end % onDefaultView
%-------------------------------------------------------------------------%
    function onChaseCam( ~, ~  )
        % Set the current view to chase cam
        % First, select the Agent and then configure the chase cam.
        
    end % onChaseCam
%-------------------------------------------------------------------------%
    function onBackgroundColour( ~, ~  )
        % Set the background colour of the current view.
        % Draw the GUI
        hGUIobj.ChangeBackgroundGUI();
    end % onBackgroundColour
%-------------------------------------------------------------------------%
    function onTempVignette( ~, ~  )
        % First, ensure that all the vignette panels are removed.
        try
            delete(hGUIobj.handles.SimTabSelectedVignettePanel);
            delete(hGUIobj.handles.ViewTabSelectedVignettePanel);
        catch err
        end
        % Next, reset them to the dummy form
        backColor = hGUIobj.handles.backColor;
        % Set the CurrrentVignette valiable
        hGUIobj.theSIM.m_hScene.m_CurrentVignette = 'default';
        % Create the vignette object
        hGUIobj.theSIM.m_hScene.m_hCurrentVignetteObject = [];
        hGUIobj.handles.SimTabSelectedVignettePanel = uiextras.Panel(...
            'Parent',hGUIobj.handles.SimTabMainVignettePanel,...
            'Padding',3,...
            'BackgroundColor',backColor,...
            'Visible','off');
        hGUIobj.theSIM.m_hGUI.handles.ViewTabSelectedVignettePanel = uiextras.Panel(...
            'Parent',hGUIobj.theSIM.m_hGUI.handles.ViewTabVignettePanel,...
            'Padding',10,...
            'BackgroundColor',backColor,...
            'Visible','off');
    end % onTempVignette
%-------------------------------------------------------------------------%
    function onSearchDestroyVignette( ~, ~  )
        % Search & Destroy Vignette callback. First, ensure that all the
        % vignette panels are removed.
        try
            delete(hGUIobj.handles.SimTabSelectedVignettePanel);
            delete(hGUIobj.handles.ViewTabSelectedVignettePanel);
        catch err
        end
        % Set the CurrentVignette variable
        hGUIobj.theSIM.m_hScene.m_CurrentVignette = 'Search&Destroy';
        % Create the vignette object
        hGUIobj.theSIM.m_hScene.m_hCurrentVignetteObject = MAVERIC_SG.Vignettes.SearchandDestroy();
        % Create the Simulation vignette panel
        hGUIobj.theSIM.m_hScene.m_hCurrentVignetteObject.DrawGUIControls();
        %         hGUIobj.AddRunSimVignetteControls(hGUIobj.handles.backColor);
        % Create the View vignette panel
        hGUIobj.AddViewVignetteControls(hGUIobj.handles.backColor);
    end % onSearchDestroyVignette
%-------------------------------------------------------------------------%
    function onmUASFigofEight( ~, ~  )
        % mUAS Figure of Eight Vignette callback. First, ensure that all the
        % vignette panels are removed.
        try
            delete(hGUIobj.handles.SimTabSelectedVignettePanel);
            delete(hGUIobj.handles.ViewTabSelectedVignettePanel);
        catch err
        end
        % Set the CurrrentVignette variable
        hGUIobj.theSIM.m_hScene.m_CurrentVignette = 'mUASFigureofEight';
        % Create the Simulation vignette panel
        hGUIobj.AddRunSimVignetteControls(hGUIobj.handles.backColor);
        % Create the View vignette panel
        hGUIobj.AddViewVignetteControls(hGUIobj.handles.backColor);
    end % onmUASFigofEight

%-------------------------------------------------------------------------%
    function onWizard( ~, ~ )
        % Have no idea....
        
    end % onWizard
%-------------------------------------------------------------------------%
    function onAbout( ~, ~)
        % Launch the GUI with application information
        
    end % onAbout
%-------------------------------------------------------------------------%
    function onClearConsole( ~, ~)
        % Clear the console
        clc;
    end % onClearConsole
%-------------------------------------------------------------------------%
    function onRefreshAll( ~, ~)
        % Re-attach the data bus for all agents/objects
        AL = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList;
        for ii = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
            if(isempty(AL{ii}.m_hDataBus.m_hParent))
                datahandle = str2func(AL{ii}.m_hDataBus.m_DataFile);
                try
                    AL{ii} = datahandle(AL{ii},'update');
                catch err
                    errordlg(err.identifier,err.message);
                end
            end
        end
        hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList = AL;
        % And objects
        OB = hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList;
        for ii = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumSceneryObjects
            if(isempty(OB{ii}.m_hDataBus.m_hParent))
                datahandle = str2func(OB{ii}.m_hDataBus.m_DataFile);
                try
                    OB{ii} = datahandle(OB{ii},'update');
                catch err
                    errordlg(err.identifier,err.message);
                end
            end
        end
        hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList = OB;
        % Update the GUI
        hGUIobj.UpdateGUI();
    end % onRefreshAll
end

