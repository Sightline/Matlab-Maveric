function DrawSceneTree(hGUIobj)
set(0,'CurrentFigure',hGUIobj.theSIM.m_hGUI.handles.Window);
import javax.swing.*
import javax.swing.tree.*;
[tree,container] = uitree('v0','SelectionChangeFcn', @NodeSelected);
set(container, 'Parent', hGUIobj.theSIM.m_hGUI.handles.TreePanelContainer);
set(container, 'Units','normalized', 'Position',[0 0 1 1]);
%
% Define the base (root) structure.
%
iconpath = fullfile(matlabroot,'/toolbox/matlab/icons/');
icon = [iconpath 'matlabicon.gif'];
sn = hGUIobj.theSIM.m_hScene.m_Name;
root = uitreenode('v0','root',sn,icon,false);
icon = [iconpath 'HDF_object02.gif'];
TerrainNode = uitreenode('v0','TerrainNodes','Terrain',icon,false);
icon = [iconpath 'HDF_object01.gif'];
ObjectNode = uitreenode('v0','ObjectNodes','Scenery Objects',icon,false);
icon = './Utilities/Icons/HDF_object03.png';
AgentNode = uitreenode('v0','AgentNodes','Agent Objects',icon,false);
root.add(TerrainNode);
root.add(ObjectNode);
root.add(AgentNode);
%
% Now Search the Blackboard databases for entities
% First the Agents
for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
    if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_AgentType,'Platform'))
        if(isempty(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hParent))
            AddAgentNode(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj},AgentNode);
        end
    end
end
% Now the Scenery Objects
for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumSceneryObjects
    AddObjectNode(hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{jj},ObjectNode);
end
% Finally the Terrain Objects
for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumTerrainObjects
    name = sprintf('TerrainNode_%d',jj);
    icon = './Utilities/Icons/earth.png';
    newnode = uitreenode('v0',name,...
        hGUIobj.theSIM.m_hScene.m_hBB.m_TerrainObjList{jj}.Tag,icon,true);
    TerrainNode.add(newnode)
end

treeModel = DefaultTreeModel(root);
tree.setModel(treeModel);
if(AgentNode.isLeaf)
    tree.setSelectedNode(AgentNode);
else
    tree.setSelectedNode(AgentNode.getFirstChild);
end
tree.expand(AgentNode);
tree.expand(ObjectNode);
tree.expand(TerrainNode);
hGUIobj.theSIM.m_hGUI.handles.Tree = tree;
hGUIobj.theSIM.m_hGUI.handles.TreeContainer = container;
%
%
end
%
%*************************************************************
% SUPPORT FUNCTIONS
%*************************************************************
%
function AddAgentNode(Ag,baseNode)
% Create and add the treenode for the current agent.
% First, get the agent ID
AgID = Ag.m_hDataBus.m_AgID;
% Now colate the data necessary to populate the description field
classtmp = class(Ag);
n = max(regexp(classtmp,'\.'));
classname = classtmp(n+1:end);
nodeName = sprintf('%s - %s',classname,Ag.Tag);
% Before creating the node, need to determine if this is a leaf node
% i.e. check whether the agent has any children.
agch = [];
if(~isempty(Ag.m_hDataBus.m_hChildren))
    agch = fieldnames(Ag.m_hDataBus.m_hChildren);
end
isleaf = false;
if(isempty(agch))
    isleaf = true;
end
% Get the appropriate icon
icon = getIcon(nodeName);
% Create the new UITreeNode
agnewnode = uitreenode('v0',AgID,nodeName,icon,isleaf);
% Add to teh parent UITreeNode
baseNode.add(agnewnode)
% Now need to attach the child agents, if any
if(~isleaf)
    % If yes, go to each child in turn
    for ich = 1:length(Ag.m_hDataBus.m_hChildrenArray)
        AddAgentNode(Ag.m_hDataBus.m_hChildrenArray{ich},agnewnode);
    end
end
end

function AddObjectNode(Obj,baseNode)
% Create and add the treenode for the current agent.
% First, get the agent ID
ObjID = Obj.m_hDataBus.m_MRObjectID;
% Now colate the data necessary to populate the description field
classtmp = class(Obj);
n = max(regexp(classtmp,'\.'));
classname = classtmp(n+1:end);
nodeName = sprintf('%s - %s',classname,Obj.Tag);
% Before creating the node, need to determine if this is a leaf node
% i.e. check whether the agent has any children.
agch = [];
if(~isempty(Obj.m_hDataBus.m_hChildren))
    agch = fieldnames(Obj.m_hDataBus.m_hChildren);
end
isleaf = false;
if(isempty(agch))
    isleaf = true;
end
% Get the appropriate icon
icon = getIcon(nodeName);
% Create the new UITreeNode
agnewnode = uitreenode('v0',ObjID,nodeName,icon,isleaf);
% Add to teh parent UITreeNode
baseNode.add(agnewnode)
% Now need to attach the child agents, if any
if(~isleaf)
    % If yes, go to each child in turn
    for ich = 1:length(Obj.m_hDataBus.m_hChildrenArray)
        AddObjectNode(Obj.m_hDataBus.m_hChildrenArray{ich},agnewnode);
    end
end
end

function NodeSelected(tree,~)
% This is the callback fired when a user changes the selected node on the 
% tree. First, get the selected node.
selectedNodes = tree.getSelectedNodes;
% Extract the ID
nodeID = selectedNodes(1).getValue;
% and the baseline type (to know which Blackboard list to use)
type = findRootNode(selectedNodes(1));
% Now update the entity information panel...
MAVERIC_GUI.EntityInfo(type,nodeID);
end

function icon = getIcon(nodeName)
% Return the appropriate icon path for the node type.
iconpath = fullfile(matlabroot,'/toolbox/matlab/icons/');
if(regexp(nodeName,'INS'))
    icon = [iconpath 'boardicon.gif'];
    return;
end
if(regexp(nodeName,'Radar'))
    icon = [iconpath 'boardicon.gif'];
    return;
end
if(regexp(nodeName,'EOSystem'))
    icon = [iconpath 'boardicon.gif'];
    return
end
if(regexp(nodeName,'Missile'))
    icon = './Utilities/Icons/missile_icon.png';
    return;
end
if(regexp(nodeName,'Building'))
    icon = './Utilities/Icons/home3.png';
    return;
end
% Default icon
icon = [iconpath 'help_gs.png'];
end

function type = findRootNode(node)
value = node.getValue;
if(strcmp(value,'TerrainNodes') || strcmp(value,'ObjectNodes')...
        || strcmp(value,'AgentNodes'))
    switch value
        case 'TerrainNodes'
            type = 'Terrain';
        case 'ObjectNodes'
            type = 'Object';
        case 'AgentNodes'
            type = 'Agent';
    end
    return;
end
parent = node.getParent;
type = findRootNode(parent);
end
