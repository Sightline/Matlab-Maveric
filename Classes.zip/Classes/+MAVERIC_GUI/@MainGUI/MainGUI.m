classdef MainGUI < handle
    %MAINGUI This class draws and maintains the principle MAVERIC GUI.
    %   The MainGUI class is used by MAVERIC to draw the principle user
    %   interface. 
    
    properties
        theSIM            % handle to the main scene object
        handles           % structure containing the GUI handles
        Children          % handles to the children GUIs of the main 
                          % MAVERIC GUI
    end
    
    methods
        function this  =  MainGUI(theSIM)
            % A MainGUI object cannot exist without being associated with a
            % sim object.
            this.theSIM = theSIM;
        end
    end
    
    methods
        this = CreateGUI(this);
        this = UpdateGUI(this);
        this = NewBaseClassGUI(this);
        AddMenus(this);
        AddAnalysisControls(this,backColor,borderColor);
        AddAnimControls(this,backColor,borderColor);
        AddRunSimControls(this,backColor,borderColor);
        AddViewControls(this,backColor,borderColor);
        AddRunSimVignetteControls(this,backColor,borderColor);
    end
    
end

