function hGUIobj = UpdateGUI(hGUIobj)
%UPDATEGUI This method is called when the GUI requires updating
%   Detailed explanation goes here
hGUIobj.theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
% Update the scene popup in the analysis tab
popstring = cell(1,1);
kk = 1;
for ii = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
    if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus...
            .m_AgentType,'Platform'));
        popstring{kk,1} = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.Tag;
        kk = kk+1;
    end
end
set(hGUIobj.theSIM.m_hGUI.handles.AnalysisTabAgPopup,'String',popstring);
set(hGUIobj.theSIM.m_hGUI.handles.AnalysisTabAgPopup,'Value',1);
% Now draw the scene. 
hGUIobj.theSIM.m_hScene = hGUIobj.theSIM.m_hScene.DrawScene_ver2();
% Update the Vignette-Specific Panels
hGUIobj.UpdateViewVignetteControls(hGUIobj.handles.backColor,hGUIobj.handles.borderColor);
hGUIobj.UpdateRunSimVignetteControls(hGUIobj.handles.backColor,hGUIobj.handles.borderColor);
% + Create the tree
DrawSceneTree(hGUIobj);

% Flush the queue
drawnow();
%-------------------------------------------------------------------------%
%     function sceneTree(hGUIobj)
%         set(0,'CurrentFigure',hGUIobj.theSIM.m_hGUI.handles.Window);
%         import javax.swing.*
%         import javax.swing.tree.*;
%         [tree,container] = uitree('v0');
%         set(container, 'Parent', hGUIobj.theSIM.m_hGUI.handles.TreePanelContainer);
%         set(container, 'Units','normalized', 'Position',[0 0 1 1]);
%         %
%         % Define the base (root) structure.
%         %
%         iconpath = fullfile(matlabroot,'/toolbox/matlab/icons/');
%         icon = [iconpath 'matlabicon.gif'];
%         sn = hGUIobj.theSIM.m_hScene.m_Name;
%         root = uitreenode('v0','root',sn,icon,false);
%         icon = [iconpath 'HDF_object02.gif'];
%         TerrainNode = uitreenode('v0','Node1','Terrain',icon,false);
%         icon = [iconpath 'HDF_object01.gif'];
%         ObjectNode = uitreenode('v0','Node2','Scenery Objects',icon,false);
%         icon = './Utilities/Icons/HDF_object03.png';
%         AgentNode = uitreenode('v0','Node3','Agent Objects',icon,false);
%         root.add(TerrainNode);
%         root.add(ObjectNode);
%         root.add(AgentNode);
%         %
%         % Now Search the Blackboard databases for entities
%         % First the Agents
%         for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
%             % List only those agents that are active
%             if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_SimStatus,'Active'))
%             if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_AgentType,'Platform'))
%                 nname = sprintf('AgentNode_%d',jj);
%                 agch = [];
%                 if(~isempty(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren))
%                 agch = fieldnames(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren);
%                 end
%                 isleaf = false;
%                 if(isempty(agch))
%                     isleaf = true;
%                 end
%                 classtmp = class(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj});
%                 n = max(regexp(classtmp,'\.'));
%                 classname = classtmp(n+1:end);
%                 name = sprintf('%s - %s',hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.Tag,classname);
%                 icon = [iconpath 'help_gs.png'];
%                 newnode = uitreenode('v0',nname,name,icon,isleaf);
%                 AgentNode.add(newnode)
%                 % Now the children of that agent (sensor array, weapons etc).
%                 for ich = 1:length(agch)
%                     switch agch{ich}
%                         case 'INS'
%                             name = sprintf('INS - %s',hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren.INS.Tag);
%                             isleaf = false;
%                             icon = [iconpath 'boardicon.gif'];
%                             INSnode = uitreenode('v0','INS_Node',...
%                             name,icon,isleaf);
%                             newnode.add(INSnode);
%                         case 'Radar'
%                             name = sprintf('Radar - %s',hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren.Radar.Tag);
%                             isleaf = false;
%                             icon = [iconpath 'boardicon.gif'];
%                             INSnode = uitreenode('v0','Radar_Node',...
%                             name,icon,isleaf);
%                             newnode.add(INSnode);
%                         case 'EOSystem'
%                             name = sprintf('INS - %s',hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren.INS.Tag);
%                             isleaf = false;
%                             icon = [iconpath 'boardicon.gif'];
%                             INSnode = uitreenode('v0','EOSystem_Node',...
%                                 name,icon,isleaf);
%                             newnode.add(INSnode);
%                         case 'Missiles'
%                             for nm = 1:length(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren.Missiles)
%                                 name = sprintf('%s - Missile',hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{jj}.m_hDataBus.m_hChildren.Missiles{nm}.Tag);
%                                 isleaf = false;
%                                 icon = './Utilities/Icons/missile_icon.png';
%                                 INSnode = uitreenode('v0','Missile_Node',...
%                                     name,icon,isleaf);
%                                 newnode.add(INSnode);
%                             end
%                     end
%                 end
%             end
%             end
%         end
%         % Now the Scenery Objects
%         for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumSceneryObjects
%                 name = sprintf('ObjectNode_%d',jj);
%                 icon = './Utilities/Icons/home3.png';
%                 newnode = uitreenode('v0',name,...
%                 hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{jj}.Tag,icon,true);
%                 ObjectNode.add(newnode)
%         end  
%         % Finally the Terrain Objects
%         for jj = 1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumTerrainObjects
%                 name = sprintf('TerrainNode_%d',jj);
%                 icon = './Utilities/Icons/earth.png';
%                 newnode = uitreenode('v0',name,...
%                 hGUIobj.theSIM.m_hScene.m_hBB.m_TerrainObjList{jj}.Tag,icon,true);
%                 TerrainNode.add(newnode)
%         end 
%         
%         treeModel = DefaultTreeModel(root);
%         tree.setModel(treeModel);
%         tree.setSelectedNode(AgentNode);
%         hGUIobj.theSIM.m_hGUI.handles.Tree = tree;
%         hGUIobj.theSIM.m_hGUI.handles.TreeContainer = container;
%     end
%-------------------------------------------------------------------------%


end

