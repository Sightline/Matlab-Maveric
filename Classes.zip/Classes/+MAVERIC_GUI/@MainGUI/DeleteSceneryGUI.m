function DeleteSceneryGUI(hGUIobj)
%DeleteSceneryGUI Summary of this function goes here
%   Detailed explanation goes here
%% Create the main figure window
sz = get(0,'ScreenSize');
hGUIobj.handles.hDeleteSceneryGUI.Window = figure(...
    'Name', 'Delete Scenery from Scene', ...
    'NumberTitle', 'off', ...
    'MenuBar', 'none', ...
    'Toolbar', 'none', ...
    'HandleVisibility', 'on',...
    'Color','w',...
    'OuterPosition',[(sz(3)/2-200),...
    (sz(4)/2),...
    400,130],...
    'CloseRequestFcn',@DeleteSceneryGUICloseRequest);
% Set default panel colors
csc = 1/256;
backColor = 'w';
borderColor = csc*[10 70 130];
%
%  Create Controls
%
hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainPanel = uiextras.Panel(...
    'Parent',hGUIobj.handles.hDeleteSceneryGUI.Window,...
    'Padding',10,...
    'BackgroundColor',backColor);
hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainVBox = uiextras.VBox(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainPanel,...
    'Spacing',5,...
    'BackgroundColor',backColor);
hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainHBox = uiextras.HBox(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainVBox,...
    'Spacing',10,...
    'BackgroundColor',backColor);
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainHBox),...
    'Style','text',...
    'String','Select Scenery',...
    'HorizontalAlignment','left',...
    'BackgroundColor',backColor,...
    'FontWeight','bold',...
    'FontSize',10);
hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.SceneryPopup = uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainHBox),...
    'Style','popupmenu',...
    'String','   ',...
    'HorizontalAlignment','left',...
    'Callback',@SceneryPopup_Callback,...
    'BackgroundColor','w');
%
%
% Buttons
%
hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1 = uiextras.Grid(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainVBox,...
    'Spacing',30,...
    'Padding',5,...
    'BackgroundColor',backColor);
uiextras.Empty(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1,...
    'BackgroundColor',backColor);
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1),...
    'String','DELETE',...
    'HorizontalAlignment','center',...
    'BackgroundColor',borderColor,...
    'ForegroundColor','w',...
    'FontWeight','bold',...
    'Callback',@DeleteButton_Callback);
uicontrol(...
    'Parent',double(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1),...
    'String','CANCEL',...
    'HorizontalAlignment','center',...
    'BackgroundColor',borderColor,...
    'ForegroundColor','w',...
    'FontWeight','bold',...
    'Callback',@CancelButton_Callback);
uiextras.Empty(...
    'Parent',hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1,...
    'BackgroundColor',backColor);
%
% Set the layout sizes
%
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainVBox,'Sizes',[-1,35]);
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.MainHBox,'Sizes',[-1,-2]);
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.Grid1,'ColumnSizes',[-1,60,60,-1]);
%
%
% Need to populate the Scenery popup
str = cell(1,1);
indx = [];
% Update the scene listbox (Name,Type,Class).
kk = 1;
for ii=1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumSceneryObjects
    indx(ii) = 0;
    parent = hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_hParent;
    if(isempty(parent))
        name = hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.Tag;
        agtype = hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{ii}.m_hDataBus.m_MRObjectType;
        agclass = class(hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{ii});
        str{kk} = sprintf('%-s \t %-s \t %-s',name,agtype,agclass);
        indx(ii) = kk;
        kk = kk+1;
    end
end
set(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.SceneryPopup,'String',str);
hGUIobj.handles.hDeleteSceneryGUI.PopupCallback = false;
%*************************************************************************%
% CALLBACK FUNCTIONS
%*************************************************************************%
%
%-------------------------------------------------------------------------%
    function DeleteSceneryGUICloseRequest(~,~)
        try
            delete(hGUIobj.handles.hDeleteSceneryGUI.Window);
        catch Exception
            errordlg({'Add Scenery figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%
    function SceneryPopup_Callback(~,~)
        %
        hGUIobj.handles.hDeleteSceneryGUI.PopupCallback = true;
    end
%-------------------------------------------------------------------------%
    function CancelButton_Callback(~,~)
        %
        try
            delete(hGUIobj.handles.hDeleteSceneryGUI.Window);
        catch Exception
            errordlg({'Add Scenery figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%
    function DeleteButton_Callback(~,~)
        % First, get the selected Scenery from the popup. Ensure that the
        % popup callback has been activated.
        if(~hGUIobj.handles.hDeleteSceneryGUI.PopupCallback)
            warndlg('Caution - No Scenerys have been selected');
            return;
        end
        %
        % Now get the selected Scenery.
        pv = get(hGUIobj.theSIM.m_hGUI.handles.hDeleteSceneryGUI.SceneryPopup,'Value');
        id = find(indx==pv);
        val = id;
        % need to find the location of the entity in the main entity list
        % using the SceneObj ID.
        valEnt = 0;
        for jj=1:length(hGUIobj.theSIM.m_hScene.m_hBB.m_EntityList)
            if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_EntityIDList{jj},id))
                valEnt = jj;
                break;
            end
        end
        % If hGUIobj.theSIM.m_hScene is a parent object, also need to delete and remove the
        % child objects.
        
        if(isempty(parent))
            deleteSceneObj(hGUIobj.theSIM.m_hScene.m_hBB.m_SceneryObjList{val});
            % The last operation is to call the EAMatrix Reset method.
            hGUIobj.theSIM.m_hScene.m_hBB.ResetEAM();
        elseif(~isempty(parent))
            warndlg({'Only PLATFORM-Level SceneObjs may be deleted from',...
                'a Scene. To alter the sensor array, edit the object datafile'});
        end
        %       
        % Almost there - now update the main GUI
        hGUIobj.theSIM.m_hGUI.UpdateGUI();
        %
        % Finally, close the GUI
        try
            delete(hGUIobj.handles.hDeleteSceneryGUI.Window);
        catch Exception
            errordlg({'Add Scenery figure has failed to close with '...
                'error message  ',Exception.message});
        end
    end
%-------------------------------------------------------------------------%

end

function deleteSceneObj(SceneObj)
% We should delete entities from the leaf nodes in the system tree.
% Find if the SceneObj has any children
if(isfield(SceneObj.m_hDataBus,'m_hChildrenArray'))
    [~,n] = size(SceneObj.m_hDataBus.m_hChildrenArray);
    for ii = 1:n
        deleteSceneObj(SceneObj.m_hDataBus.m_hChildrenArray{ii});
    end
end
% If we have reached here, we are at a leaf node. First remove any attached
% geometry.
if(isfield(SceneObj.m_hDataBus.ParameterData,'GeomHGTransform'))
    if(isfield(SceneObj.m_hDataBus.ParameterData,'GeomPatchHandles'))
    [n,m] = size(SceneObj.m_hDataBus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(SceneObj.m_hDataBus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(SceneObj.m_hDataBus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    SceneObj.m_hDataBus.ParameterData.GeomPatchHandles = [];
    end
    [n,m] = size(SceneObj.m_hDataBus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(SceneObj.m_hDataBus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
end
%
% Remove the waypoints plot if they exist
if(isfield(SceneObj.m_hDataBus,'Waypoints'))
    wp = SceneObj.m_hDataBus.WayPoints;
    nwp = length(wp.xe);
    if(isfield(SceneObj.m_hDataBus.ParameterData,'WaypointHandles'))
        if(iscell(SceneObj.m_hDataBus.ParameterData.WaypointHandles))
            for ii=1:nwp
                if(ishghandle(SceneObj.m_hDataBus.ParameterData.WaypointHandles{ii}))
                    delete(SceneObj.m_hDataBus.ParameterData.WaypointHandles{ii});
                end
            end
            SceneObj.m_hDataBus.ParameterData.WaypointHandles = [];
        end
    end
    if(isfield(SceneObj.m_hDataBus.ParameterData,'WaypointTrajHandle'))
        if(ishghandle(SceneObj.m_hDataBus.ParameterData.WaypointTrajHandle))
            delete(SceneObj.m_hDataBus.ParameterData...
                .WaypointTrajHandle);
            SceneObj.m_hDataBus.ParameterData...
                .WaypointTrajHandle = [];
        end
    end
end
%
% Finally, delete the SceneObj from the SceneObj lists. As this is a recursive
% function, we need to find the position of the SceneObj in both SceneObj and
% entity lists.
id = SceneObj.m_hDataBus.m_MRObjectID;
val = 0;
for jj=1:length(SceneObj.m_hBB.m_SceneryObjList)
    if(strcmp(SceneObj.m_hBB.m_SceneryObjIDList{jj},id))
        val = jj;
        break;
    end
end
SceneObj.m_hBB.m_SceneryObjList(val) = [];
SceneObj.m_hBB.m_SceneryObjIDList(val,:) = [];
SceneObj.m_hBB.m_NumSceneryObjects = SceneObj.m_hBB.m_NumSceneryObjects - 1;
%
% Now remove from the entity list. Recall, only platforms are attached to
% this list.
if(strcmp(SceneObj.m_hDataBus.m_MRObjectType,'Platform'))
    valEnt = 0;
    for jj=1:length(SceneObj.m_hBB.m_EntityList)
        if(strcmp(SceneObj.m_hBB.m_EntityIDList{jj},id))
            valEnt = jj;
            break;
        end
    end
    % and lastly from the entity lists
    SceneObj.m_hBB.m_EntityList(valEnt) = [];
    SceneObj.m_hBB.m_EntityIDList(valEnt) = [];
    SceneObj.m_hBB.m_NumEntities = SceneObj.m_hBB.m_NumEntities - 1;
end
%
% Finally, delete the SceneObj object...
delete(SceneObj);
end
