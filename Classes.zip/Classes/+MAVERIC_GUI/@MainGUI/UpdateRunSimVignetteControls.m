function UpdateRunSimVignetteControls(hGUIobj,backColor,borderColor)
%UpdateRunSimVignetteControls Summary of this function goes here
%   Detailed explanation goes here
%
%
%
% Get the current vignette
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
CurrentVignette = theSIM.m_hScene.m_CurrentVignette;
% Now, create the appropriate controls
switch CurrentVignette
    case 'Search&Destroy'
        % Search & Destroy Vignette
        %
        % Populate Agent popup
        str = cell(1,1);
        indx = [];
        % Update the agent listbox (Name,Type,Class).
        kk = 1;
        for ii=1:hGUIobj.theSIM.m_hScene.m_hBB.m_NumAgents
            indx(ii) = 0;
            if(strcmp(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_AgentType,'Platform'))
                name = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.Tag;
                agtype = hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii}.m_hDataBus.m_AgentType;
                agclass = class(hGUIobj.theSIM.m_hScene.m_hBB.m_AgentList{ii});
                str{kk} = sprintf('%-s \t %-s \t %-s',name,agtype,agclass);
                indx(ii) = kk;
                kk = kk+1;
            end
        end
        set(hGUIobj.handles.SimTabVignetteAgentPopup,'String',str);
    case 'mUASFigureofEight'
        % mUAS Figure-of_Eight
    case 'default'
        %
end
end

