classdef NewSceneGUI < handle
    %NEWSCENEGUI Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        theSIM            % handle to the main scene object
        m_hmainGUI        % handle of the main GUI
        handles           % structure containing the GUI handles
    end
    
    methods
        function this  =  NewSceneGUI(theSIM)
            % A MainGUI object cannot exist without being associated with a
            % scene object.
            this.theSIM = theSIM;
            this.m_hmainGUI = theSIM.m_hGUI;
        end
    end
    
    methods
        this = CreateGUI(this);
        this = UpdateGUI(this);
        AddAgentGUI(this);
        AddObjectGUI(this);
        AddTerrainGUI(this);
    end
    
end

