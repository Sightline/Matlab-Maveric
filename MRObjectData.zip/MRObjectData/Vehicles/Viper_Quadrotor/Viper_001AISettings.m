function Bus = Viper_001AISettings(Bus)
%UH60_001AISETTINGS Summary of this function goes here
%   Detailed explanation goes here
%
%
%% Waypoint Settings
% Define the Waypoint vector and store in the agent databus.
r = Bus.getPositionVec();
x0 = r(1,1); y0 = r(2,1); z0 = r(3,1);
Bus.m_hInitialConditions.xe = x0;
Bus.m_hInitialConditions.ye = y0;
Bus.m_hInitialConditions.ye = z0;
Bus.WayPoints.ye = [0 0 0 x0];
Bus.WayPoints.xe = [1 1.5 -1.5 y0];
Bus.WayPoints.ze = [-1.5 -1.5 -1.5 z0];
Bus.NumWayPoints = 4;
Bus.WPindex = 1;
Bus.m_CurrentWP.xw = Bus.WayPoints.xe(1);
Bus.m_CurrentWP.yw = Bus.WayPoints.ye(1);
Bus.m_CurrentWP.zw = Bus.WayPoints.ze(1);
Bus.m_hTargetsInspected = [];
Bus.m_hTargetQueue = [];
Bus.IsLanded = 'n';

end

