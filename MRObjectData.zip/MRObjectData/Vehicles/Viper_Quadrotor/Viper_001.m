function obj = Viper_001(obj,status)
%% Viper_001 Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform';
Bus.m_ClassName = 'Multirotor';
Bus.m_DataFile = 'Viper_001';
Bus.m_SimStatus = 'Active';
Bus.m_ForceDesignation = 'blue';
Bus.m_IsDocked = false;
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
    Bus.ParameterData.UserDefinedPos = [0;0;0];
    Bus.ParameterData.MountingOffset = [0;0;0];
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [0.01;0.01;0.001];
Bus.m_GuidanceMRStatesTimeSteps = [0.01;0.01;0.001];
Bus.m_ControlMRStatesTimeSteps = [0.01;0.01;0.001];
Bus.m_GeometryMRStatesTimeSteps = [0.01;1];
Bus.m_AIMRStatesTimeSteps = [0.01;0.01;0.001];
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentControlMRState = Bus.m_hCurrentControlMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_hCurrentAIMRState = Bus.m_hCurrentAIMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters
Bus.InertialData.mass = 1.512;    % mass (kg)
Bus.InertialData.Ixx = 0.032;     % moment-of-Inertia around body x-axis
Bus.InertialData.Iyy = 0.033;     % moment-of-Inertia around body y-axis
Bus.InertialData.Izz = 0.041;     % moment-of-Inertia around body z-axis
%% Aerodynamic Parameters
Bus.AerodynamicData.rho = 1.225;        % density
Bus.AerodynamicData.Kt = 120;           % Propeller thrust gain
Bus.AerodynamicData.Kq = 2;             % Propeller torque gain
Bus.AerodynamicData.tauKt = 0.1;        % Propeller thrust time constant
Bus.AerodynamicData.tauKq = 0.1;        % Propeller torque time constant
% Propeller hub position (body axes)
L = 0.2; h = 0.015;
Bus.AerodynamicData.PropPosn{1} = [L;0;-h];
Bus.AerodynamicData.PropPosn{2} = [0;L;-h];
Bus.AerodynamicData.PropPosn{3} = [-L;0;-h];
Bus.AerodynamicData.PropPosn{4} = [0;-L;-h];
% Propeller hub tilt angles [roll;pitch]
Bus.AerodynamicData.PropTilt{1} = [0;0];
Bus.AerodynamicData.PropTilt{2} = [0;0];
Bus.AerodynamicData.PropTilt{3} = [0;0];
Bus.AerodynamicData.PropTilt{4} = [0;0];
% Controller distribution matrix
Bus.AerodynamicData.ConDistMatrix = [1 1 1 1;1 0 -1 0;0 -1 0 1;1 -1 1 -1];
%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 0.5;
Bus.ParameterData.L1Dyn.psi_tau = 0.2;
Bus.ParameterData.L1Dyn.gamma_tau = 0.2;
Bus.ParameterData.L1Dyn.Vf_max = 10;            % m/s
Bus.ParameterData.L1Dyn.Vf_cruise = 0.1;        % m/s
Bus.ParameterData.L1Dyn.Vf_min = 0;             % m/s
Bus.ParameterData.L1Dyn.psid_max = 100;          % deg/s
Bus.ParameterData.L1Dyn.gammad_max = 100;        % deg/s
%% Sensor Array
% Check if the INS sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'INS')))
%     error('The supplied class name is not valid....');
% end
% if(strcmp(status,'create'))
%     Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Sparkfun','INS',@SimpleINS);
%     Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
%     Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
%     Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
% end
% if(strcmp(status,'update'))
%     Bus.m_hSensorArray{1} = SimpleINS(Bus.m_hSensorArray{1},'update');
%     Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
%     Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
%     Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
% end
%% Assign AI parameters
if(strcmp(status,'create'))
    Bus = Viper_001AISettings(Bus);
end
if(strcmp(status,'update'))
    Bus = Viper_001AISettings(Bus);
end
%% Geometric Parameters
if(strcmp(status,'create'))
    Bus = Viper_001AttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = Viper_001AttachGeometry(Bus);
end
if(strcmp(status,'create'))
    Bus.ParameterData.ScaleFactor = 1;
end
%% Update Bus object
obj.m_hDataBus = Bus;
end