function obj = Reaper_001(obj,status)
%% Reaper_001 Data file population function
%
%  Author: David Anderson
%  Date: 1/8/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform';
Bus.m_DataFile = 'Reaper_001';
Bus.m_SimStatus = 'Active';
Bus.m_IsDocked = false;
Bus.m_ForceDesignation = 'blue';
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
    Bus.ParameterData.UserDefinedPos = [0;0;0];
    Bus.ParameterData.MountingOffset = [0;0;0];
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [0.1;0.1;0.0001];
Bus.m_GuidanceMRStatesTimeSteps = [0.1;0.1;0.0001];
Bus.m_ControlMRStatesTimeSteps = [0.1;0.1;0.0001];
Bus.m_GeometryMRStatesTimeSteps = [1;0.1;0.0001];
Bus.m_AIMRStatesTimeSteps = [1;0.1;0.0001];
% Initialise the modules
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentControlMRState = Bus.m_hCurrentControlMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_hCurrentAIMRState = Bus.m_hCurrentAIMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters
Bus.InertialData.mass = 1.2;    % mass (kg)
Bus.InertialData.Ixx = 10.0;    % moment-of-Inertia around body x-axis
Bus.InertialData.Iyy = 10.0;    % moment-of-Inertia around body y-axis
Bus.InertialData.Izz = 5.0;     % moment-of-Inertia around body z-axis

%% Aerodynamic Parameters

%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 10;
Bus.ParameterData.L1Dyn.Vf_max = 100;            % m/s
Bus.ParameterData.L1Dyn.Vf_cruise = 72;          % m/s
Bus.ParameterData.L1Dyn.Vf_min = 30;             % m/s
Bus.ParameterData.L1Dyn.psi_max = 50;            % deg/s
Bus.ParameterData.L1Dyn.gamma_max = 20;          % deg/s
%% Sensor Array
% The Reaper will have an INS, Radar and EO suite of sensors
%-------------- INS ---------------------
% Check if the INS sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'INS')))
    error('The supplied class name is not valid....');
end
if(strcmp(status,'create'))
    Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{1} = SimpleINS(Bus.m_hSensorArray{1},'update');
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
%-------------- Radar ---------------------
% Check if the Radar sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'Radar')))
%     error('The supplied class name is not valid....');
% end
% if(strcmp(status,'create'))
%     Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('Captor','Radar',@Radar_001);
%     Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
%     Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
%     Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
% end
% if(strcmp(status,'update'))
%     Bus.m_hSensorArray{2} = Radar_001(Bus.m_hSensorArray{2},'update');
%     Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
%     Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
%     Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
% end
% %-------------- EO Sensor ---------------------
% % Check if the EO Sensor sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'EOSystem')))
    error('The supplied class name is not valid....');
end
if(strcmp(status,'create'))
    Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('TIALD','EOSystem',@Seeker_001);
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{2} = Seeker_001(Bus.m_hSensorArray{2},'update');
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
%% Weapons
% The Reaper has at least one Hellfire missile attached
% ----------------------- Hellfire ------------------------------
% Check if the missile class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'Missile')))
    error('The supplied class name is not valid....');
end
% Create the weapons array
nmissiles = 2; str = [];
for ii = 1:nmissiles
    str = sprintf('PavewayIV_%d',ii);
if(strcmp(status,'create'))
    Bus.m_hWeaponsArray{ii} = MAVERIC_SE.SimEngine.CreateObject(str,'Missile',@GBU12_001);
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hParent = obj;
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hCurrentDynMRState.m_NextTime = Bus.m_hCurrentDynMRState.m_NextTime;
    Bus.m_hChildrenArray{ii+1} = Bus.m_hWeaponsArray{ii};
end
if(strcmp(status,'update'))
    Bus.m_hWeaponsArray{ii} = GBU12_001(Bus.m_hWeaponsArray{ii},'update');
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hParent = obj;
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hCurrentDynMRState.m_NextTime = Bus.m_hCurrentDynMRState.m_NextTime;
    Bus.m_hChildrenArray{ii+1} = Bus.m_hWeaponsArray{ii};
end

end
Bus.ParameterData.m_CurrentMissile = 1;
Bus.m_hWeaponsArray{1}.m_hDataBus.ParameterData.MountingOffset = [0;-3;0.35];
Bus.m_hWeaponsArray{2}.m_hDataBus.ParameterData.MountingOffset = [0;3;0.35];
Bus.m_hChildrenArray{2} = Bus.m_hWeaponsArray{1};
Bus.m_hChildrenArray{3} = Bus.m_hWeaponsArray{2};
Bus.m_hChildren.Missiles = Bus.m_hWeaponsArray; % Legacy, TBR
%% Assign AI parameters
% Bus = Reaper_001AISettings(Bus);
if(strcmp(status,'create'))
    Bus = Reaper_001AISettings(Bus);
end
if(strcmp(status,'update'))
    Bus = Reaper_001AISettings(Bus);
end
%% Geometric Parameters
% Bus = Reaper_001AttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = Reaper_001AttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = Reaper_001AttachGeometry(Bus);
end
if(strcmp(status,'create'))
    Bus.ParameterData.ScaleFactor = 1;
end
%% Update Bus object
obj.m_hDataBus = Bus;
end