function Bus = MH60_001AISettings(Bus)
%MH60_001AISETTINGS Summary of this function goes here
%   Detailed explanation goes here
%
%
%% Waypoint Settings
% Define the Waypoint vector and store in the agent databus.
r = Bus.getPositionVec();
x0 = r(1,1); y0 = r(2,1); z0 = r(3,1);
Bus.m_hInitialConditions.xe = x0;
Bus.m_hInitialConditions.ye = y0;
Bus.m_hInitialConditions.ye = z0;
% Bus.WayPoints.xe = 10000*[2 4 x0/10000];
% Bus.WayPoints.ye = 10000*[3 3 y0/10000];
% Bus.WayPoints.ze = -1000*[1 1 z0/10000];
% Bus.NumWayPoints = 3;
Bus.WayPoints.xe = 10000*[8 8 4 4 8];
Bus.WayPoints.ye = 10000*[5 8 8 11 11];
Bus.WayPoints.ze = -1000*[1 1 1 1 1];
Bus.NumWayPoints = 5;
Bus.WPindex = 1;
Bus.m_CurrentWP.xw = Bus.WayPoints.xe(1);
Bus.m_CurrentWP.yw = Bus.WayPoints.ye(1);
Bus.m_CurrentWP.zw = Bus.WayPoints.ze(1);
Bus.m_hTargetsInspected = [];
Bus.m_hTargetQueue = [];
Bus.IsLanded = 'n';
Bus.m_hCurrentAIMRState.m_hAIFSM.m_hTargetDB.m_hPlatformWeapons = Bus.m_hWeaponsArray;
end

