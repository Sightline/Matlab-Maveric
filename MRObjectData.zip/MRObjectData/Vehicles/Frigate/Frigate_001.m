function obj = Frigate_001(obj,status)
%% Frigate_001 Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform';
Bus.m_DataFile = 'Frigate_001';
Bus.m_SimStatus = 'Active';
Bus.m_ForceDesignation = 'blue';
Bus.m_IsDocked = false;
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = true;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
    Bus.ParameterData.UserDefinedPos = [0;0;0];
    Bus.ParameterData.MountingOffset = [0;0;0];
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_GuidanceMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_ControlMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_GeometryMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_AIMRStatesTimeSteps = [1;0.001;0.0001];
% Initialise the modules
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_hCurrentAIMRState = Bus.m_hCurrentAIMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters
Bus.InertialData.mass = 50000;    % mass (kg)
Bus.InertialData.Ixx = 10000;    % moment-of-Inertia around body x-axis
Bus.InertialData.Iyy = 100000;    % moment-of-Inertia around body y-axis
Bus.InertialData.Izz = 100000;     % moment-of-Inertia around body z-axis

%% Aerodynamic Parameters

%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 60;
Bus.ParameterData.L1Dyn.Vf_max = 10;            % m/s
Bus.ParameterData.L1Dyn.Vf_cruise = 5+5*rand(1);         % m/s
Bus.ParameterData.L1Dyn.Vf_min = 0;             % m/s
Bus.ParameterData.L1Dyn.psi_max = 10;           % deg/s
Bus.ParameterData.L1Dyn.gamma_max = 10;         % deg/s
%% Link to the Blackboard
% obj = obj.LinkToBB;
%% Sensor Array
% The Frigate will have an INS, Radar and EO suite of sensors
%-------------- INS ---------------------
% Check if the INS sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'INS')))
    error('The supplied class name is not valid....');
end
% Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
% Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
if(strcmp(status,'create'))
    Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{1} = SimpleINS(Bus.m_hSensorArray{1},'update');
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
%-------------- Radar ---------------------
% Check if the Radar sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'Radar')))
    error('The supplied class name is not valid....');
end
% Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('BaseRadar','Radar',@Radar_002);
% Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
if(strcmp(status,'create'))
    Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('BaseRadar','Radar',@Radar_002);
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{2} = Radar_002(Bus.m_hSensorArray{2},'update');
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
% %-------------- EO Sensor ---------------------
% % Check if the EO Sensor sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'EOSystem')))
%     error('The supplied class name is not valid....');
% end
% Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('DIRCM','EOSystem',@NemesisDIRCM_001);
% Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.INS = Bus.m_hSensorArray{3};
%% Assign AI parameters
% Bus = Frigate_001AISettings(Bus);
if(strcmp(status,'create'))
    Bus = Frigate_001AISettings(Bus);
end
if(strcmp(status,'update'))
    Bus = Frigate_001AISettings(Bus);
end
%% Geometric Parameters
% Bus = Frigate_001AttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = Frigate_001AttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = Frigate_001AttachGeometry(Bus);
end
if(strcmp(status,'create'))
    Bus.ParameterData.ScaleFactor = 1;
end
%% Update Bus object
obj.m_hDataBus = Bus;

end