function obj = UH60_001(obj,status)
%% UH60_001 Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform';
Bus.m_DataFile = 'UH60_001';
Bus.m_SimStatus = 'Active';
Bus.m_IsDocked = false;
Bus.m_ForceDesignation = 'blue';
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
    Bus.ParameterData.UserDefinedPos = [0;0;0];
    Bus.ParameterData.MountingOffset = [0;0;0];
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [1;0.1;0.0001];
Bus.m_GuidanceMRStatesTimeSteps = [1;0.1;0.0001];
Bus.m_ControlMRStatesTimeSteps = [1;0.1;0.0001];
Bus.m_GeometryMRStatesTimeSteps = [1;0.1;0.0001];
Bus.m_AIMRStatesTimeSteps = [1;0.1;0.0001];
% Initialise the modules
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentControlMRState = Bus.m_hCurrentControlMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_hCurrentAIMRState = Bus.m_hCurrentAIMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters
Bus.InertialData.mass = 1.2;    % mass (kg)
Bus.InertialData.Ixx = 10.0;    % moment-of-Inertia around body x-axis
Bus.InertialData.Iyy = 10.0;    % moment-of-Inertia around body y-axis
Bus.InertialData.Izz = 5.0;     % moment-of-Inertia around body z-axis

%% Aerodynamic Parameters

%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 10;
Bus.ParameterData.L1Dyn.psi_tau = 5;
Bus.ParameterData.L1Dyn.gamma_tau = 5;
Bus.ParameterData.L1Dyn.Vf_max = 10;            % m/s
Bus.ParameterData.L1Dyn.Vf_cruise = 72;         % m/s
Bus.ParameterData.L1Dyn.Vf_min = 0;             % m/s
Bus.ParameterData.L1Dyn.psi_max = 100;          % deg/s
Bus.ParameterData.L1Dyn.gamma_max = 100;        % deg/s
%% Link to the Blackboard
% obj = obj.LinkToBB;
%% Sensor Array
% The MH60 will have an INS, Radar and EO suite of sensors
%-------------- INS ---------------------
% Check if the INS sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'INS')))
    error('The supplied class name is not valid....');
end
% Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
% Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
% Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
if(strcmp(status,'create'))
    Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{1} = SimpleINS(Bus.m_hSensorArray{1},'update');
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
%-------------- Radar ---------------------
% Check if the Radar sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'Radar')))
    error('The supplied class name is not valid....');
end
% Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('Captor','Radar',@Radar_001);
% Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
% Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
if(strcmp(status,'create'))
    Bus.m_hSensorArray{2} = MAVERIC_SE.SimEngine.CreateObject('Captor','Radar',@Radar_001);
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{2} = Radar_001(Bus.m_hSensorArray{2},'update');
    Bus.m_hSensorArray{2}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.Radar = Bus.m_hSensorArray{2};
    Bus.m_hChildrenArray{2} = Bus.m_hSensorArray{2};
end
% %-------------- EO Sensor ---------------------
% % Check if the EO Sensor sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'EOSystem')))
%     error('The supplied class name is not valid....');
% end
% Bus.m_hSensorArray{3} = MAVERIC_SE.SimEngine.CreateObject('DIRCM','EOSystem',@NemesisDIRCM_001);
% Bus.m_hSensorArray{3}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.EOSys = Bus.m_hSensorArray{3};
%% Weapons
% The MH60 has at least one Hellfire missile attached
% ----------------------- Hellfire ------------------------------
% Check if the missile class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'Missile')))
    error('The supplied class name is not valid....');
end
% Create the weapons array
nmissiles = 1; str = [];
for ii = 1:nmissiles
    str = sprintf('Hellfire_%d',ii);
% Bus.m_hWeaponsArray{ii} = MAVERIC_SE.SimEngine.CreateObject(str,'Missile',@Hellfire_001);
% Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hParent = obj;
% Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hCurrentDynMRState.m_NextTime = Bus.m_hCurrentDynMRState.m_NextTime;
% Bus.m_hChildrenArray{ii+2} = Bus.m_hWeaponsArray{ii};
if(strcmp(status,'create'))
    Bus.m_hWeaponsArray{ii} = MAVERIC_SE.SimEngine.CreateObject('str','Missile',@Hellfire_001);
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hParent = obj;
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hCurrentDynMRState.m_NextTime = Bus.m_hCurrentDynMRState.m_NextTime;
    Bus.m_hChildrenArray{ii+2} = Bus.m_hWeaponsArray{ii};
end
if(strcmp(status,'update'))
    Bus.m_hWeaponsArray{ii} = Hellfire_001(Bus.m_hSensorArray{2},'update');
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hParent = obj;
    Bus.m_hWeaponsArray{ii}.m_hDataBus.m_hCurrentDynMRState.m_NextTime = Bus.m_hCurrentDynMRState.m_NextTime;
    Bus.m_hChildrenArray{ii+2} = Bus.m_hWeaponsArray{ii};
end
end
Bus.m_hChildren.Missiles = Bus.m_hWeaponsArray;
%% Assign AI parameters
% Bus = UH60_001AISettings(Bus);
if(strcmp(status,'create'))
    Bus = UH60_001AISettings(Bus);
end
if(strcmp(status,'update'))
    Bus = UH60_001AISettings(Bus);
end
%% Geometric Parameters
Bus = UH60_001AttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = UH60_001AttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = UH60_001AttachGeometry(Bus);
end
Bus.ParameterData.ScaleFactor = 1;
%% Update Bus object
obj.m_hDataBus = Bus;
end