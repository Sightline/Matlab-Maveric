function Bus = UH60_001AISettings(Bus)
%UH60_001AISETTINGS Summary of this function goes here
%   Detailed explanation goes here
%
%
%% Waypoint Settings
% Define the Waypoint vector and store in the agent databus.
r = Bus.getPositionVec();
x0 = r(1,1); y0 = r(2,1); z0 = r(3,1);
Bus.m_hInitialConditions.xe = x0;
Bus.m_hInitialConditions.ye = y0;
Bus.m_hInitialConditions.ye = z0;
Bus.WayPoints.xe = 10000*[1 3 4 x0/10000];
Bus.WayPoints.ye = 10000*[3 4 2.5 y0/10000];
Bus.WayPoints.ze = -10000*[1 1 1 -z0/10000];
Bus.NumWayPoints = 4;
Bus.WPindex = 1;
Bus.m_CurrentWP.xw = Bus.WayPoints.xe(1);
Bus.m_CurrentWP.yw = Bus.WayPoints.ye(1);
Bus.m_CurrentWP.zw = Bus.WayPoints.ze(1);
Bus.m_hTargetsInspected = [];
Bus.m_hTargetQueue = [];
Bus.IsLanded = 'n';

end

