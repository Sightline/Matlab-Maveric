function obj = Template(obj,status)
%% Template Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform'; % or 'Sensor' for agent objects
Bus.m_MRObjectType = 'Building'; % For scenery and terrain objects
Bus.m_DataFile = 'Template';
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = true;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_GuidanceMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_GeometryMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters
Bus.InertialData.mass = 1.2;    % mass (kg)
Bus.InertialData.Ixx = 10.0;    % moment-of-Inertia around body x-axis
Bus.InertialData.Iyy = 10.0;    % moment-of-Inertia around body y-axis
Bus.InertialData.Izz = 5.0;     % moment-of-Inertia around body z-axis
%% Aerodynamic Parameters
rho = 1.225;        % density
%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 0.2;
Bus.ParameterData.L1Dyn.psi_tau = 0.2;
Bus.ParameterData.L1Dyn.gamma_tau = 0.2;
%% Link to the Blackboard
% Enough information about the core agent has now beed defined to allow
% insertion into the blackboard.
obj = obj.LinkToBB;
%% Sensor Array
% Check if the INS sensor class type exists.
basechk = dir('./Classes/+MAVERIC_SE/');
[n,~] = size(basechk); str = ' ';
for ii=1:n
    str = [str,basechk(ii).name,' '];
end
if(isempty(strfind(str,'INS')))
    error('The supplied class name is not valid....');
end
if(strcmp(status,'create'))
    Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Litef','INS',@SimpleINS);
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
if(strcmp(status,'update'))
    Bus.m_hSensorArray{1} = SimpleINS(Bus.m_hSensorArray{1},'update');
    Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
    Bus.m_hChildren.INS = Bus.m_hSensorArray{1};
    Bus.m_hChildrenArray{1} = Bus.m_hSensorArray{1};
end
%% Geometric Parameters
Bus = TemplateAttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = TemplateAttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = TemplateAttachGeometry(Bus);
end
Bus.ParameterData.ScaleFactor = 1;
%% Update Bus object
obj.m_hDataBus = Bus;
end

