function obj = ShippingLane(obj,status)
%% Template Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_MRObjectType = 'Map'; % Class type
Bus.m_DataFile = 'ShippingLane';
% Define the module structure
Bus.m_HasDynamic = false;
Bus.m_HasAI = false;
Bus.m_HasControl = false;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = false;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states
% N/A
% define the timesteps for each module
Bus.m_GeometryMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
%
%% Inertial Parameters
% N/A
%% Aerodynamic Parameters
% N/A
%% L1 models dynamic time constants
% N/A
%% Sensor Array
% N/A
%% Geometric Parameters
% Bus = ShippingLaneAttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = ShippingLaneAttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = ShippingLaneAttachGeometry(Bus);
end
% Assign the lighting to the middle of the scene.
xmin = min(Bus.ParameterData.xrange); xmax = max(Bus.ParameterData.xrange); xmid = (xmax+xmin)/2;
ymin = min(Bus.ParameterData.yrange); ymax = max(Bus.ParameterData.yrange); ymid = (ymax+ymin)/2;
lpos = [xmid ymid 2*(xmax-xmin)];
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
set(theSIM.m_hGUI.handles.ViewTabLightsourceEdit,'String',num2str(lpos));
%% Update Bus object
obj.m_hDataBus = Bus;
end
