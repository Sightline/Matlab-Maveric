function Bus = ShippingLaneAttachGeometry(Bus)
%TemplateATTACHGEOMETRY Summary of this function goes here
%   Detailed explanation goes here

Bus.ParameterData.GeomHGTransform = cell(1,2);
Bus.ParameterData.ScaleFactor = 1;
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
%% L1 Model
% First, create the HGGroup. 
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Now load the terrain image
xrange = linspace(-25000,100000,100);
yrange = linspace(-25000,100000,100);
Bus.ParameterData.xrange = xrange;
Bus.ParameterData.yrange = yrange;
[X,Y] = meshgrid(xrange,yrange);
cdat(:,:,1) = 0.5*ones(100);
cdat(:,:,2) = 0.75*ones(100);
cdat(:,:,3) = ones(100);
%
Bus.ParameterData.GeomSurfaceHandle{2} = surface(X,Y,zeros(100),cdat,...
    'Parent',Bus.ParameterData.GeomHGTransform{1},...
    'EdgeColor','none',...
    'BackFaceLighting','unlit');
% Store the extent of the geometry

%% L2 Model
Bus.ParameterData.GeomHGTransform{2} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Sim to L1....
% Bus.ParameterData.GeomHGTransform{2} = Bus.ParameterData.GeomHGTransform{1};
%% Have the correct geometry visible
set(Bus.ParameterData.GeomHGTransform{1},'Visible','off');
set(Bus.ParameterData.GeomHGTransform{2},'Visible','off');
%
set(Bus.ParameterData.GeomHGTransform{Bus.m_GeometryResolution},'Visible','on');
end
