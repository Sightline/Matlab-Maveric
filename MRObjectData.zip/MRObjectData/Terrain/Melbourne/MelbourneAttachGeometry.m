function Bus = MelbourneAttachGeometry(Bus)
%TemplateATTACHGEOMETRY Summary of this function goes here
%   Detailed explanation goes here

Bus.ParameterData.GeomHGTransform = cell(1,2);
Bus.ParameterData.ScaleFactor = 1;
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
%% L1 Model
% First, create the HGGroup. 
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Now load the terrain image
C = imread('./SceneData/Images/Melbourne001.jpg','jpeg');
xrange = linspace(0,135000,135);
yrange = linspace(0,80000,135);
Bus.ParameterData.xrange = xrange;
Bus.ParameterData.yrange = yrange;
[X,Y] = meshgrid(xrange,yrange);
% Now load the STL files of the geometry (if required)
[model.v, model.f, model.n, model.c, model.stltitle] = stlread(...
    './SceneData/STLFiles/MelbourneAltitude_1kmLon.stl');
[model.v, model.f]=patchslim(model.v, model.f);
Z = reshape(model.v(:,3),135,135);
Z = Z.*50;
for ii = 1:3
    Cf(:,:,ii) = flipud(C(:,:,ii));
end
% Now put a skirt around the terrain to hide remote sensing images
xmin = min(xrange); xmax = max(xrange); xmid = (xmax+xmin)/2;
ymin = min(yrange); ymax = max(yrange); ymid = (ymax+ymin)/2;
skirt = 1.5;
xsmin = xmid - skirt*(xmax-xmin); xsmax = xmid + skirt*(xmax-xmin);
ysmin = ymid - skirt*(ymax-ymin); ysmax = ymid + skirt*(ymax-ymin);
xsrange = linspace(xsmin,xsmax,10);
ysrange = linspace(ysmin,ysmax,10);
[Xs,Ys] = meshgrid(xsrange,ysrange);
cdat(:,:,1) = zeros(10);
cdat(:,:,2) = zeros(10);
cdat(:,:,3) = zeros(10);
%
Bus.ParameterData.GeomSurfaceHandle{1} = surface(X,Y,Z,Cf,...
    'Parent',Bus.ParameterData.GeomHGTransform{1},...
    'FaceColor','texturemap',...
    'EdgeColor','none',...
    'CDataMapping','scaled');
% Bus.ParameterData.GeomSurfaceHandle{2} = surface(Xs,Ys,-10*ones(10),cdat,...
%     'Parent',Bus.ParameterData.GeomHGTransform{1},...
%     'EdgeColor','none',...
%     'BackFaceLighting','unlit');
% Store the extent of the geometry

%% L2 Model
Bus.ParameterData.GeomHGTransform{2} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Sim to L1....
% Bus.ParameterData.GeomHGTransform{2} = Bus.ParameterData.GeomHGTransform{1};
%% Have the correct geometry visible
set(Bus.ParameterData.GeomHGTransform{1},'Visible','off');
set(Bus.ParameterData.GeomHGTransform{2},'Visible','off');
%
set(Bus.ParameterData.GeomHGTransform{Bus.m_GeometryResolution},'Visible','on');
end
