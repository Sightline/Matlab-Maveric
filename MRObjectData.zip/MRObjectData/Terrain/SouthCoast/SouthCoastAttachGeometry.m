function Bus = SouthCoastAttachGeometry(Bus)
%TemplateATTACHGEOMETRY Summary of this function goes here
%   Detailed explanation goes here

Bus.ParameterData.GeomHGTransform = cell(1,2);
Bus.ParameterData.ScaleFactor = 1;
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
%% L1 Model
% First, create the HGGroup. 
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Now load the terrain image
C = imread('./SceneData/Images/SouthCoast.jpg','jpeg');
xrange = linspace(0,185000,185);
yrange = linspace(0,120000,185);
Bus.ParameterData.xrange = xrange;
Bus.ParameterData.yrange = yrange;
[X,Y] = meshgrid(xrange,yrange);
for ii = 1:3
    Cf(:,:,ii) = flipud(C(:,:,ii));
end
%
Bus.ParameterData.GeomSurfaceHandle{1} = surface(X,Y,-zeros(185),Cf,...
    'Parent',Bus.ParameterData.GeomHGTransform{1},...
    'FaceColor','texturemap',...
    'EdgeColor','none',...
    'CDataMapping','scaled');
%% L2 Model
% Bus.ParameterData.GeomHGTransform{2} = hgtransform(...
%     'Parent',theSIM.m_hGUI.handles.ViewAxes,...
%     'Selection','on',...
%     'SelectionHighlight','on');
% Sim to L1....
% Bus.ParameterData.GeomHGTransform{2} = Bus.ParameterData.GeomHGTransform{1};
%% Have the correct geometry visible
set(Bus.ParameterData.GeomHGTransform{1},'Visible','off');
% set(Bus.ParameterData.GeomHGTransform{2},'Visible','off');
%
set(Bus.ParameterData.GeomHGTransform{Bus.m_GeometryResolution},'Visible','on');
end
