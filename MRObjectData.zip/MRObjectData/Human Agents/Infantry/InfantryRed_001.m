function obj = InfantryRed_001(obj,status)
%% InfantryRed_001 Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Platform';
Bus.m_DataFile = 'InfantryRed_001';
Bus.m_SimStatus = 'Active';
Bus.m_ForceDesignation = 'red';
% Define the module structure
Bus.m_HasDynamic = true;
Bus.m_HasAI = true;
Bus.m_HasControl = true;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = true;
Bus.m_HasGuidance = true;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.setDynStates([0;0;0;0;0;0],1);
    Bus.setDynStateDot([0;0;0;0;0;0],1);
    Bus.setControls([0;0;0],1);
    Bus.ParameterData.UserDefinedPos = [0;0;0];
end
% define the timesteps for each module
Bus.m_DynamicMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_GuidanceMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_GeometryMRStatesTimeSteps = [0.1;0.001;0.0001];
Bus.m_AIMRStatesTimeSteps = [0.1;0.001;0.0001];
% Initialise the modules
Bus.m_hCurrentDynMRState = Bus.m_hCurrentDynMRState.Enter();
Bus.m_hCurrentGuidanceMRState = Bus.m_hCurrentGuidanceMRState.Enter();
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_hCurrentAIMRState = Bus.m_hCurrentAIMRState.Enter();
%
Bus.m_hCurrentGuidanceMRState.m_LocalVariables.GuidanceOffset = 0;
%% Inertial Parameters

%% Aerodynamic Parameters

%% L1 models dynamic time constants
Bus.ParameterData.L1Dyn.Vf_tau = 1;
%% Link to the Blackboard
% obj = obj.LinkToBB;
%% Sensor Array
% The InfantryRed will have a Radar and EO suite of sensors
%-------------- Radar ---------------------
% Check if the Radar sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'Radar')))
%     error('The supplied class name is not valid....');
% end
% Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('Ground_Radar','Radar',@Radar_002);
% Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.Radar = Bus.m_hSensorArray{1};
% %-------------- EO Sensor ---------------------
% % Check if the EO Sensor sensor class type exists.
% basechk = dir('./Classes/+MAVERIC_SE/');
% [n,~] = size(basechk); str = ' ';
% for ii=1:n
%     str = [str,basechk(ii).name,' '];
% end
% if(isempty(strfind(str,'EOSystem')))
%     error('The supplied class name is not valid....');
% end
% Bus.m_hSensorArray{1} = MAVERIC_SE.SimEngine.CreateObject('DIRCM','EOSystem',@NemesisDIRCM_001);
% Bus.m_hSensorArray{1}.m_hDataBus.m_hParent = obj;
% Bus.m_hChildren.INS = Bus.m_hSensorArray{3};
%% Assign AI parameters
% Bus = InfantryRed_001AISettings(Bus);
if(strcmp(status,'create'))
    Bus = InfantryRed_001AISettings(Bus);
end
if(strcmp(status,'update'))
    Bus = InfantryRed_001AISettings(Bus);
end
%% Geometric Parameters
Bus = InfantryRed_001AttachGeometry(Bus);
if(strcmp(status,'create'))
    Bus = InfantryRed_001AttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = InfantryRed_001AttachGeometry(Bus);
end
Bus.ParameterData.ScaleFactor = 1;
%% Update Bus object
obj.m_hDataBus = Bus;
end