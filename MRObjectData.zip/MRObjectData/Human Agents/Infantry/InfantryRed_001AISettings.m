function Bus = InfantryRed_001AISettings(Bus)
%InfantryRed_001AISETTINGS Summary of this function goes here
%   Detailed explanation goes here
%
%
%% Waypoint Settings
% Define the Waypoint vector and store in the agent databus.
r = Bus.getPositionVec();
x0 = r(1,1); y0 = r(2,1); z0 = r(3,1);
Bus.m_hInitialConditions.xe = x0;
Bus.m_hInitialConditions.ye = y0;
Bus.m_hInitialConditions.ze = z0;
Bus.WayPoints.xe = x0;
Bus.WayPoints.ye = y0;
Bus.WayPoints.ze = z0;
Bus.NumWayPoints = 1;
Bus.WPindex = 1;
Bus.m_CurrentWP.xw = Bus.WayPoints.xe(1);
Bus.m_CurrentWP.yw = Bus.WayPoints.ye(1);
Bus.m_hTargetsInspected = [];
Bus.m_hTargetQueue = [];
Bus.IsLanded = 'n';
end

