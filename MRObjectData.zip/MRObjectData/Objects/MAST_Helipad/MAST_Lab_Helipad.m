function obj = MAST_Lab_Helipad(obj,status)
%MAST_LAB_HELIPAD Summary of this function goes here
%   Detailed explanation goes here
%% MAST_Lab_Helipad Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
Bus = obj.m_hDataBus;
Bus.m_MRObjectType = 'SceneObject';
Bus.m_DataFile = 'MAST_Lab_Helipad';
Bus.m_SimStatus = 'Active';
Bus.m_ForceDesignation = 'green';
% Define the module structure
Bus.m_HasDynamic = false;
Bus.m_HasAI = false;
Bus.m_HasControl = false;
Bus.m_HasDetection = false;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = false;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = true;
%
% define the timesteps for each module
Bus.m_GeometryMRStatesTimeSteps = [1.0;0.001;0.0001];
Bus.m_hCurrentGeoMRState = Bus.m_hCurrentGeoMRState.Enter();
Bus.m_GeometryResolution = 1;
%% Geometric Parameters
if(strcmp(status,'create'))
    Bus = MAST_Lab_HelipadAttachGeometry(Bus);
end
if(strcmp(status,'update'))
    % Remove the existing geometry
    [n,m] = size(Bus.ParameterData.GeomPatchHandles);
    for ii = 1:n
        for jj = 1:m
            if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
                delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
            end
        end
    end
    Bus.ParameterData.GeomPatchHandles = [];
    [n,m] = size(Bus.ParameterData.GeomHGTransform);
    for ii = 1:n
        for jj = 1:m
            delete(Bus.ParameterData.GeomHGTransform{ii,jj});
        end
    end
    Bus.ParameterData.GeomHGTransform = [];
    % Re-attach existing geometry
    Bus = MAST_Lab_HelipadAttachGeometry(Bus);
end
if(strcmp(status,'create'))
    Bus.ParameterData.ScaleFactor = 1;
end
end

