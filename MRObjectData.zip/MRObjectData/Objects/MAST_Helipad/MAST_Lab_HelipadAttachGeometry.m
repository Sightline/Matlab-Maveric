function Bus = MAST_Lab_HelipadAttachGeometry(Bus)
%MAST_LAB_HELIPADATTACHGEOMETRY Summary of this function goes here
%   Detailed explanation goes here
%% Physical model
Bus.ParameterData.GeomHGTransform = cell(1);
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
                'Parent',theSIM.m_hGUI.handles.ViewAxes);
csc = 1/256; vsc = 1/120;
[model.v, model.f, model.n, model.c, model.stltitle] = stlread(...
                './SceneData/STLFiles/MASTLab_Helipad.stl');
[model.v, model.f]=patchslim(model.v, model.f);
model.v = model.v.*vsc;
model.c = repmat(csc*[200,200,200],[size(model.v,1),1]);
Bus.ParameterData.GeomPatchHandles{1,1} = patch(...
                'Parent',Bus.ParameterData.GeomHGTransform{1},...
                'Faces',model.f,...
                'Vertices',model.v,...
                'FaceVertexCData',model.c);
%% Radar reflectance parameters
Bus.ParameterData.RCS_Mean = 10;
Bus.ParameterData.RCS_Var = 1;
end

