function obj = Optitrack_001(obj,status)
%% Optitrack_001 Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Sensor';
Bus.m_DataFile = 'Optitrack_001';
Bus.m_SimStatus = 'Dormant';
Bus.m_IsDocked = true;
% Define the module structure
Bus.m_HasDynamic = false;
Bus.m_HasAI = false;
Bus.m_HasControl = false;
Bus.m_HasDetection = true;
Bus.m_HasNavigation = false;
Bus.m_HasGuidance = false;
Bus.m_HasSightline = true;
Bus.m_HasTracking = true;
Bus.m_HasGeometry = true;
% Set initial states
% Set initial states (if in create mode)
if(strcmp(status,'create'))
    Bus.ParameterData.UserDefinedPos = [0;0;0];
    Bus.ParameterData.SensorPosBody = [3;0;0];
end
% define the timesteps for each module
Bus.m_DetectionMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_SightlineMRStatesTimeSteps = [1;0.001;0.0001];
Bus.m_TrackingMRStatesTimeSteps = [1;0.001;0.0001];
% Initialise the modules
Bus.m_hCurrentDetectionMRState = Bus.m_hCurrentDetectionMRState.Enter();
Bus.m_hCurrentSightlineMRState = Bus.m_hCurrentSightlineMRState.Enter();
Bus.m_hCurrentTrackingMRState = Bus.m_hCurrentTrackingMRState.Enter();
%% Optitrack performance parameters
% Constants...
Bus.ParameterData.c = 3e8;          % Speed of light in a vaccum (m/s)
Bus.ParameterData.k = 1.38e-23;     % Boltzman's constant (Joules/K)
Bus.ParameterData.T  = 290;         % reference temperature (K)
% Common parameters
Bus.ParameterData.AzBeamwidth = 5*(pi/180);
Bus.ParameterData.ElBeamwidth = 5*(pi/180);
Bus.ParameterData.LookDownAngle = 0*(pi/180);
Bus.ParameterData.tht_s = 0; % Initial antenna bearing
                                          % angle
Bus.ParameterData.tht_sd = 0;   % Antenna scan rate (deg/s)
% L1 Parameters
Bus.ParameterData.RDetection = 5000;
% Bus.ParameterData.RMaxUnamL1 = 15000;
Bus.ParameterData.RMinDetection = 10;
Bus.ParameterData.RCSMinDetection = 1;
Bus.ParameterData.RCSDetection = 100;
% L2 Parameters
Bus.ParameterData.Pt = 1e3;         % Optitrack transmitter power (W)
Gdb = 20;                           % Antenna gain in Dbs
Bus.ParameterData.G = 10^(Gdb/10);  % Antenna gain
Bus.ParameterData.D = 0.5;          % Antenna diameter (m)
Bus.ParameterData.Ae = 0.9*(pi*Bus.ParameterData.D^2)/4;  % Antenna 
                                    % effective aperture area (m^2)
Bus.ParameterData.fc = 1.5e9;       % Carrier frequency (Hz)
Bus.ParameterData.lambda = Bus.ParameterData.c/Bus.ParameterData.fc;% Optitrack 
                                    % wavelength (m)
Bus.ParameterData.fp = 2500;        % Optitrack PRF (Hz)
Bus.ParameterData.tprf = 1/Bus.ParameterData.fp; % Optitrack pulse interval (s)
Bus.ParameterData.tscan = (360-Bus.ParameterData.tht_sd)/Bus.ParameterData.tht_sd;      
                                    % Time between scans (s)
Bus.ParameterData.np = 30.0;        % number of pulses used for coherent integration
Bus.ParameterData.En = 0.7;         % integration efficiency
Bus.ParameterData.tau = 1e-6;       % pulse width (s)
Bus.ParameterData.SNmin = 20.0;     % minimum detectable signal to noise ratio
Bus.ParameterData.beta = 1/Bus.ParameterData.tau;  % reciever bandwidth (assumes matched filter) (Hz)
Bus.ParameterData.BW = 65*Bus.ParameterData.lambda/Bus.ParameterData.D;  
                                    % Optitrack beamwidth (deg)
Bus.ParameterData.R_un = Bus.ParameterData.RDetection;       % maximumm unambiguous range (max range) (m)
Bus.ParameterData.Rmin = 0.0;       % minimum Optitrack detection range (m)
Bus.ParameterData.Rres = 0.0;       % Range resolution (m)
Bus.ParameterData.RMaxUnamL1 = Bus.ParameterData.RDetection;
%% Geometric Parameters
Bus.m_GeometryResolution = 1;
% 
% if(strcmp(status,'create'))
%     Bus = Optitrack_001AttachGeometry(Bus);
% end
% if(strcmp(status,'update'))
%     % Remove the existing geometry
%     [n,m] = size(Bus.ParameterData.GeomPatchHandles);
%     for ii = 1:n
%         for jj = 1:m
%             if(~isempty(Bus.ParameterData.GeomPatchHandles{ii,jj}))
%                 delete(Bus.ParameterData.GeomPatchHandles{ii,jj});
%             end
%         end
%     end
%     Bus.ParameterData.GeomPatchHandles = [];
%     [n,m] = size(Bus.ParameterData.GeomHGTransform);
%     for ii = 1:n
%         for jj = 1:m
%             delete(Bus.ParameterData.GeomHGTransform{ii,jj});
%         end
%     end
%     Bus.ParameterData.GeomHGTransform = [];
%     % Re-attach existing geometry
%     Bus = Optitrack_001AttachGeometry(Bus);
% end
Bus.ParameterData.GeomHGTransform = cell(1,2);
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
%% L1 Model
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
Bus.ParameterData.GeomHGTransform{2} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Bus.ParameterData.ScaleFactor = 1;
%% Update Bus object
obj.m_hDataBus = Bus;
end