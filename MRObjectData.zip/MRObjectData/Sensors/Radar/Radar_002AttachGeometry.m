function Bus = Radar_002AttachGeometry(Bus)
%Radar_002AttachGeometry Summary of this function goes here
%   Detailed explanation goes here

Bus.ParameterData.GeomHGTransform = cell(1,2);
theSIM = MAVERIC_SE.SimEngine.Simulation.getInstance();
%% L1 Model
Bus.ParameterData.GeomHGTransform{1} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
% Set the transparency value (alpha)
alpha = 0.1;
% Detection
[x,y,z] = sphere(20);
R = 1;
x = x.*R; y = y.*R; z = z.*R;
[m,n] = size(z);
c = ones(m,n,3);
c(:,:,1) = 1;
c(:,:,2) = 0;
c(:,:,3) = 0;
Bus.ParameterData.GeomSurfaceHandles{1,1} = surface(x,y,z,c,...
    'Parent',Bus.ParameterData.GeomHGTransform{1},...
    'EdgeColor','g',...
    'FaceAlpha',alpha,...
    'EdgeAlpha',alpha);
%% L2 Model
Bus.ParameterData.GeomHGTransform{2} = hgtransform(...
    'Parent',theSIM.m_hGUI.handles.ViewAxes,...
    'Selection','on',...
    'SelectionHighlight','on');
alpha = 0.25;
% Detection --------------------------------------
AzBeamwidth = Bus.ParameterData.AzBeamwidth;
ElBeamwidth = Bus.ParameterData.ElBeamwidth;
RDetection = 1;
% generate patch vertices. First, load the solid angle STL file
[model.v, model.f, model.n, model.c, model.stltitle] = stlread(...
    './SceneData/STLFiles/UnitSolidAngle.stl');
[model.v, model.f]=patchslim(model.v, model.f);
% Now scale the elevation
model.v(:,3) = model.v(:,3)*sin(ElBeamwidth/2);
% and the azimuth
model.v(:,2) = model.v(:,2)*sin(AzBeamwidth/2);
% finally scale the range...
for ii = 2:size(model.v,1)
    [th,phi,~] = cart2sph(model.v(ii,1),model.v(ii,2),model.v(ii,3));
    [model.v(ii,1),model.v(ii,2),model.v(ii,3)] = sph2cart(th,phi,RDetection);
end
model.c = repmat([1.0,0.0,0.0],[size(model.v,1),1]);
% 
Bus.ParameterData.GeomPatchHandles{2,1} = patch(...
    'Parent',Bus.ParameterData.GeomHGTransform{2},...
    'Faces',model.f,...
    'Vertices',model.v,...
    'FaceColor',[1.0,0.0,0.0],...
    'EdgeColor',[1.0,0.0,0.0],...
    'FaceAlpha',alpha,...
    'EdgeAlpha',alpha,...
    'FaceVertexCData',model.c);
%%
set(Bus.ParameterData.GeomHGTransform{1},'Visible','off');
set(Bus.ParameterData.GeomHGTransform{2},'Visible','off');
%
set(Bus.ParameterData.GeomHGTransform{Bus.m_GeometryResolution},'Visible','on');
end

