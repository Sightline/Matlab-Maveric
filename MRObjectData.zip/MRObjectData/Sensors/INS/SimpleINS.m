function obj = SimpleINS(obj,status)
%% SimpleINS Data file population function
%
%  Author: David Anderson
%  Date: 4/2/2014
%--------------------------------------------------------------------------
%
%  Modification Record........................
%
%
%--------------------------------------------------------------------------
%
%% Load Core parameters
% Define type and assign ID
Bus = obj.m_hDataBus;
Bus.m_AgentType = 'Sensor';
Bus.m_SimStatus = 'Active';
Bus.m_DataFile = 'SimpleINS';
% Define the module structure
Bus.m_HasDynamic = false;
Bus.m_HasAI = false;
Bus.m_HasControl = false;
Bus.m_HasDetection = true;
Bus.m_HasNavigation = true;
Bus.m_HasGuidance = false;
Bus.m_HasSightline = false;
Bus.m_HasTracking = false;
Bus.m_HasGeometry = false;
% Set initial states
Bus.setPosition([0,0,0]');
%% Aerodynamic Parameters
Bus.ParameterData.ScaleFactor = 1;
%% Update Bus object
obj.m_hDataBus = Bus;
%% Link to the Blackboard
% obj = obj.LinkToBB;
end


