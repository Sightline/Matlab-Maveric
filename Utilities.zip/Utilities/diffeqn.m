classdef diffeqn < handle
    %DIFFEQN Class to solve difference equations.
    %   Detailed explanation goes here
    
    properties
        num
        den
        type
        num_memory
        den_memory
        Ts
    end
    
    methods
        function obj = diffeqn(num,den,Ts,type)
            % Initialise the filter object data
            obj.num = num;
            obj.den = den;
            if(length(den)>length(num))
                obj.num = [zeros(1:(length(den)-length(num))) obj.num];
            end
            obj.Ts = Ts;
            obj.type = type;
            % Initialise the filter memory
            obj.num_memory = zeros(1,length(num));
            if(~isempty(den))
                obj.den_memory = zeros(1,length(den));
                obj.num_memory = zeros(1,length(den));
            end
        end
        
        function y = Update(obj,u)
            % Update the filter using the new scalar input u
            switch obj.type
                case 'FIR'
                    y = 0; 
                    n = length(obj.num);
                    % Insert the new input to the memory bank
                    for ii = n:-1:2
                        obj.num_memory(ii) = obj.num_memory(ii-1);
                    end
                    obj.num_memory(1) = u;
                    % Now compute the filter output. First, multiply the
                    % filter coefficients by the past inputs.
                    for jj = 1:n-1
                        y = y + obj.num(jj)*obj.num_memory(jj);
                    end
                    % Finally, add in the filter bias term (a0).
                    y = y + obj.num(n);
                case 'IIR'
                    % Initialise local variables
                    y = 0;
                    n = length(obj.num);
                    m = length(obj.den);
                    % Insert the new input into the memory bank
                    for ii = n:-1:2
                        obj.num_memory(ii) = obj.num_memory(ii-1);
                    end
                    obj.num_memory(1) = u;
                    % Shift the output memory bank
                    for ii = m:-1:2
                        obj.den_memory(ii) = obj.den_memory(ii-1);
                    end
                    % Now compute the filter output. First the numerator
                    % terms,
                    for jj = 1:n
                        y = y + obj.num(jj)*obj.num_memory(jj);
                    end
                    % Now the denominator,
                    for jj = 2:m
                        y = y - obj.den(jj)*obj.den_memory(jj);
                    end
                    y = y/obj.den(1);
                    % Finally, insert the new output into the memory bank
                    obj.den_memory(1) = y;
                case 'TF'
                    % Initialise local variables
                    y = 0;
                    m = length(obj.den);
                    % Insert the new input into the memory bank
                    for ii = m:-1:2
                        obj.num_memory(ii) = obj.num_memory(ii-1);
                    end
                    obj.num_memory(1) = u;
                    % Shift the output memory bank
                    for ii = m:-1:2
                        obj.den_memory(ii) = obj.den_memory(ii-1);
                    end
                    % Now compute the filter output. First the numerator
                    % terms,
                    for jj = 1:m
                        y = y + obj.num(jj)*obj.num_memory(jj);
                    end
                    % Now the denominator,
                    for jj = 2:m
                        y = y - obj.den(jj)*obj.den_memory(jj);
                    end
                    y = y/obj.den(1);
                    % Finally, insert the new output into the memory bank
                    obj.den_memory(1) = y;
            end
        end
        
        function step(obj,Tf)
            %
        end
        
        function wipe(obj)
            % Wipe the memory clear
            n = length(obj.num);
            d = length(obj.den);
            obj.num_memory = zeros(1,n);
            if(~isempty(obj.den))
                obj.den_memory = zeros(1,d);
            end
        end
            
    end
    
end

