classdef latency < handle
    %LATENCY class to provide latency
    %   
    
    properties
        input_memory    % data memory store
        ncycles         % maximum number of cycles
    end
    
    methods
        function obj = latency(nc)
            % Initialise the input memory
            obj.ncycles = nc; % This is the maximum number of cycles of the 
                              % fundamental timestep that the latency
                              % object can handle. For example, if you add
                              % data to the latency object every 1msec, the
                              % maximum latency injected would be nc msec.
            obj.input_memory = zeros(1,nc);
        end
        
        function Add(obj,u)
            % Insert the new input to the memory bank
            tmp = obj.input_memory(1:obj.ncycles-1);
            obj.input_memory = [u tmp];
            % 
        end
        
        function y = Get(obj,uLat)
            % Get the delayed variable corresponding to a latency of uLat
            % cycles.
            y = obj.input_memory(uLat);
        end
        
        function Wipe(obj)
            % Wipe the memory clear
            obj.ncycles = 0;
            obj.input_memory = zeros(1,obj.ncycles);
        end
            
    end
    
end

